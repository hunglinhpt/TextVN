# Changelog

Tất cả thay đổi đáng chú ý của dự án TextVN sẽ được ghi lại ở đây.

Định dạng dựa trên [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
và dự án này tuân thủ [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.2.36] — 2026-10-23

### Fixed
- **Trợ lý ngữ pháp: FPR 0 % trên tập sạch 981 câu** (audit vòng 23 "như
  Grammarly" — 3 lượt rà từng dòng toàn bộ tính năng): bỏ 5 cặp trong bảng
  typo mà **từ "sai" là từ hợp lệ** (vi phạm chính sách Fassist-96 của chính
  repo) — trước đây Mode 2 **tự sửa chữ đúng thành chữ sai**: "quyến rũ"→
  "quyển", "thuở xưa"→"thướ", "đả thông"→"đã", "áy náy"→"ấy", "ngôi điếm"→
  "điểm" (chứng minh 5/5 câu đúng bị bêu + auto-fix sai). Đổi Recall câu
  87,8 % → 83,7 % (2 ca mơ hồ chuyển về nhóm cần ngữ cảnh — đánh đổi một
  chiều, không bao giờ lấy FPR đổi recall).
- Bổ sung 4 từ lặp hợp lệ vào whitelist (hết báo nhầm "năm năm trước", "ở
  đâu đâu", "chộp chộp, bum bum") — 4/5 FP còn lại trên tập sạch sạch hết.
- Gate nhận diện tiếng Việt (L0) giờ nhận **chữ hoa có dấu** — câu VIẾT HOA
  TOÀN BỘ không còn bị bỏ qua kiểm tra.
- Hồi quy mới: `khong_beu_tu_hop_le_tung_o_bang_typos`,
  `cau_viet_hoa_toan_bo_van_la_tieng_viet`; corpus dòng mềm `~` hóa cứng.
  Số đo đầy đủ: `docs/50-assist/P4-12-RECALL-REAL.md` §11.

## [0.2.35] — 2026-10-23

### Added
- **Kênh Debian/Ubuntu: PPA + lộ trình kho chính thức** — `debian/` hoàn chỉnh
  (control/rules multiarch `/usr/lib/<triplet>/fcitx5/`, changelog, copyright
  dep5, quilt; IBus engine đặt `/usr/libexec/` với component XML sinh đường
  dẫn cuối) + QA gate `ci-deb.yml`: **dpkg-buildpackage thật** trong container
  `debian:trixie` qua đúng đường Launchpad (cargo vendor → build `--offline`
  → kiểm 9 file bắt buộc + addon đúng triplet + XML không placeholder +
  lintian). `tools/release/prepare-ppa.sh` chuẩn bị + upload source package
  lên `ppa:hunglinhpt/textvn` (vendored — Launchpad build không Internet,
  R2-119). Lộ trình Debian chính thức (ITP/mentors/sponsor + email Debian
  Input Method Team) + audit deps: cây Linux chỉ cần serde/serde_json (đã có
  `librust-*-dev`). Checklist thêm B7f; `debian/changelog` = site 15 của
  check-version-sync.
- **Trợ lý ngữ pháp rà lại sâu sau D19 (audit 3 vòng, `W1…W5`/`R-7`)**:
  logic kế hoạch tự sửa gộp về **một nguồn duy nhất** (`textvn_ffi::plan_issues_from_raw`)
  dùng chung cho cả 3 nền tảng; FFI chỉ trả kế hoạch khi `delete_glyphs` == số
  char Unicode của đuôi xoá (bảng mã VNI/TCVN3 không thể xoá lệch trên
  Linux/macOS); `assist.per_app` nay có hiệu lực trên **Windows** như macOS.

### Fixed
- **Recall corpus thật 57,1% → 87,8%** (D19 · `a557d3a`): luật `diacritic_typo`
  nâng 12,5% → **75%** với FPR giữ **0,5%** (⇐/≥ chuẩn D19: recall ≥ 80%,
  FPR ≤ 2%) — thêm bảng cặp từ-sai-KHÔNG-phải-từ-hợp-lệ (chính sách
  Fassist-96) + đường tổng quát qua biến thể E1/E2/E3 giới hạn ngân sách
  ≤8 từ lạ/câu.
- **macOS (W1)**: xác minh `glyph == grapheme` trước khi xoá trong cả auto-fix
  lẫn undo — bảng mã xuất ≠ Unicode/NFD ⇒ từ chối sửa (fail-safe, ngang
  `verify_delete_range` của Windows) thay vì xoá thừa/thiếu ký tự.
- **Windows (W3)**: nhánh undo bất đồng bộ không xoá state sớm nữa — session
  tự xoá khi hoàn tác **thành công**; `Ctrl+Z` hiếm khi fail không còn nuốt
  phím đồng thời mất khả năng hoàn tác.
- CI: `cargo fmt` cho bảng TYPOS mới (`1e52a99`).

> **Bản release candidate** — ký GPG + Sigstore như các bản trước, kèm chữ ký
> git trên commit/tag (huy hiệu "Verified" — R6). **Chưa** Authenticode
> (Windows — chờ SignPath Foundation) và **chưa** Developer ID + notarization
> (macOS) — vẫn là candidate, không phải production.

## [0.2.34] — 2026-10-18

### Added
- **Kênh phân phối Linux cho distro store** — AUR chuẩn bị xong
  (`packaging/arch/PKGBUILD` + `.SRCINFO` build từ mã nguồn tag; QA gate
  `ci-aur.yml` chạy **makepkg thật** trong container `archlinux:base-devel`:
  build, test engine, `.SRCINFO` diff, đủ file, version khớp Cargo.toml);
  `tools/release/publish-aur.sh` đẩy lên AUR (từ chối lệch version; SSH key
  cục bộ hoặc secret `AUR_SSH_KEY`). Flathub/Snap/AppImage bị loại **có căn
  cứ** (IME hệ thống cần nạp bởi ibus-daemon/fcitx5 trên host — sandbox của
  các format đó không cho phép; phân tích đầy đủ:
  `docs/release/linux-distribution.md` kèm ma trận auto-update từng kênh).
  Checklist phát hành thêm bước B7e; README hàng Linux trỏ AUR + doc.

### Fixed
- **Fcitx5 addon nâng chuẩn C++20** (R2-117): header Fcitx5 6.x (distro
  rolling như Arch) dùng `std::ranges`/`std::span`/`starts_with` trong template
  body — C++17 không biên dịch được (bắt được bởi chính gate `ci-aur`); Ubuntu
  không ảnh hưởng (libstdc++ 11+ đủ). Kèm theo: `publish-aur.sh` từ chối push
  khi `sha256sums` lệch archive tag thật (R2-118).

- **Homebrew tap chính thức cho macOS** — `brew install --cask
  hunglinhpt/tap/textvn` ([hunglinhpt/homebrew-tap](https://github.com/hunglinhpt/homebrew-tap)):
  cask dùng stanza `input_method` để đặt `TextVN-IM.app` vào
  `~/Library/Input Methods` (per-user, không cần admin) và `app` cho
  `TextVN.app` vào `/Applications`; pin `sha256` của mac zip từ
  `SHA256SUMS.txt` đã verify GPG. Cask tự cập nhật theo release mới bằng
  workflow `sync-cask.yml` trong tap (mỗi 6 giờ hoặc chạy tay — verify GPG
  rồi mới ghi, không cần PAT); CI lint kiểm cú pháp Ruby + stanza bắt buộc.
  README/user-guide trỏ cài đặt macOS về tap (cách khuyên dùng, cạnh `.pkg`
  và bản nén); checklist phát hành thêm bước B7d (kiểm tap sau publish);
  `AGENTS.md` mới ở gốc repo buộc mọi agent đi theo workflow/checklist.

- **Tự động nộp bản cập nhật lên Microsoft Store** — workflow `store-publish`
  (`.github/workflows/store-publish.yml`): lấy asset `.msix` của một GitHub Release, kiểm chữ
  ký GPG + `SHA256SUMS.txt` + Sigstore (đúng `release.yml` trên đúng tag) + luật Partner
  Center/identity/Version (`tools/release/verify-store-package.sh`, `verify-msix.py
  --expect-name`), rồi nộp lên sản phẩm `9NV2R7JNNFGK` bằng Microsoft Store Developer CLI
  (`msstore`, ghim v0.4.3 + SHA-256). Chạy tay (`check` = chỉ đọc trạng thái Store, `draft`,
  `submit`) hoặc tự động sau mỗi lần phát hành khi đặt repo variable `STORE_AUTO_PUBLISH`;
  chặn sớm khi Store đang chứng nhận hoặc đã có version ≥ gói, không in JSON submission (có
  `FileUploadUrl`) ra log công khai. Cần chủ tài khoản cài app Entra + 4
  secret một lần — `docs/release/msix-submission.md` §7.

### Docs
- **TextVN đã có trên Microsoft Store** (gói MSIX, phát hành 2026-10-11):
  https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB — cài bằng
  `winget install --id 9NV2R7JNNFGK -s msstore`. README (badge + bảng tải về), hướng dẫn
  sử dụng, `HUONG_DAN_SU_DUNG.txt`, tài liệu nộp Store và ghi chú phát hành tự sinh của
  `release.yml` trỏ link này.

## [0.2.33] — 2026-10-18

### Changed
- **Mặc định sau cài = bật gõ tiếng Việt + dấu cũ, đủ 3 nền tảng** (0.2.33):
  `DiacriticStyle::Old` (`hòa`, `thủy`, `khỏe` — dấu trên `o`, `u`, `o` của vần mở
  `oa/oe/uy`) trở thành mặc định của `Config` (serde) và `EngineOptions` (core),
  default `ConfigModel.swift` (macOS), và fallback thiếu khoá `diacritic_style`
  của Linux settings. Người dùng cũ **giữ nguyên** lựa chọn của mình (chỉ thiếu
  khoá hoặc cài mới mới nhận mặc định). Spec P0-3 (bảng trường + ví dụ) đồng bộ.
  macOS SettingsView/menu và Windows tray hiển thị theo config, không đổi mã.
- Test cơ chế backspace/common-words ghim tường minh `DiacriticStyle::New` (danh
  sách từ viết theo dấu mới); kiểu cũ phủ riêng ở `telex_old_style`.

### Added
- **Ma trận 16 combo bảng mã × kiểu gõ** (`core/tests/charset_matrix.rs`): 4 bảng
  mã (`unicode_precomposed/unicode_decomposed/tcvn3/vni_windows`) × 4 kiểu gõ
  (`telex/vni/viqr/simple_telex`) gõ đúng toàn bộ ~200 từ thông dụng, chuỗi phím
  sinh từ bảng phím thật của từng kiểu gõ; anchor cứng TCVN3/VNI Windows
  (`đ`=0xAE/0xF1, `ò`=0xDF/0xF8…) chặn engine và encode lệch cùng một hướng.
- **Từ điển EN mở rộng lên top-3000 từ tần suất** (`data/en_common.txt` 31 → 104
  mục; nguồn google-10000-english MIT, lọc tự động bằng chính engine): gõ tiếng
  Anh tự trả lại đúng từ khi gõ dấu cách — `data/en_freq3000.txt` + test
  `top_3000_english_words_type_correctly` ghim toàn bộ top-3000. Cân bằng
  R2-56: 12 âm tiết Việt **không có cách gõ Telex nào khác** thắng tiếng Việt
  và vào `vn_common.txt` (`hair`→hải, `lee`→lê, `six`→sĩ, `own`→ơn, `las`→lá,
  `chair`→chải, `tax`→tã, `tree`→trê, `ups`→úp, `var`→vả, `wa`→ưa, `mar`→mả);
  các fold có cách gõ khác (`cá`="cas", `sét`="sest", `đền`="ddenf"…) nhường EN.
- Test hồi quy auto-restore EN (`core/tests/en_restore.rs`): từ EN phải tự
  correct tại dấu cách (user không phải xoá), cặp mơ hồ ghim giữ tiếng Việt.
- **Tab hoàn tất từ tiếng Việt** (`suggest.enabled` — 0.2.33, **tắt mặc định**):
  gõ dở một âm tiết + Tab → âm tiết tần suất cao nhất khớp tiền tố
  (`ngư` + Tab → `ngưng`, giữ hoa đầu từ), từ 3000 âm tiết tần suất cao
  (`data/vn_freq3000.txt` — nguồn hermitdave/FrequencyWords/OpenSubtitles qua
  OPUS, lọc bằng `is_valid_word`). Tab không khớp → đi qua app như cũ; bật qua
  `"suggest": { "enabled": true }` trong `config.v1.json` (schema P0-3 đồng bộ).

### Fixed
- Ghim hành vi gõ tiếp sau Backspace dưới mặc định dấu cũ: `hòa` + BS → `hò`
  (dấu còn trên `o`), gõ lại `a` → `hòa`; gõ tiếp `f` khi từ đã có huyền là phím
  undo (`ass` → `as`, chuẩn Telex/UniKey) — 2 hàng test mới khoá hành vi này.
- `test_settings_model.c`: 2 assertion cập nhật theo mặc định dấu cũ (thiếu khoá
  → `new_diacritic == 0`; reset mặc định → dấu cũ).

## [0.2.32] — 2026-10-12

> **Bản release candidate** — ký GPG + Sigstore như v0.2.31; từ bản này commit và tag phát
> hành còn mang chữ ký git (huy hiệu "Verified" — gate mới trong `release.yml`, R6). **Chưa**
> Authenticode (Windows — chờ SignPath Foundation) và **chưa** Developer ID + notarization
> (macOS) — vẫn là candidate, không phải production.

Rà soát toàn hệ thống sau 0.2.31: từng dòng thay đổi của vòng 16 + roadmap audit, kiểm bằng
chạy thật (chi tiết + bằng chứng: `docs/release/code-review-2026-10-09-round2.md` §3.8,
`docs/release/AUDIT-3PLATFORM-2026-10-07.md` mục F).

### Changed
- **Popup "Thông tin" giống nhau trên cả 3 nền tảng** (yêu cầu chủ repo): "Bộ gõ tiếng Việt
  thông minh, đa nền tảng (Windows, macOS, Linux)" + phiên bản + phát triển/giấy phép/URL —
  thay câu riêng "cho Windows/macOS/Linux" của từng bản; bản Linux trước đây không hiện số
  phiên bản (R2-113, test `about_text_matches_every_platform`).
- **macOS: bảng điều khiển về đúng đặc tả chung** — bảng mã và kiểu gõ cùng nhãn, cùng thứ tự
  với Windows/Linux ("Telex đơn giản" thay "4. Microsoft", bỏ số thứ tự), phím chuyển cố định
  "Ctrl + Shift (hoặc Ctrl + Shift + Space)". Bỏ hai lựa chọn chỉ có trên macOS (Alt + Z, Caps
  Lock): hai nền tảng kia không có, và trên macOS Caps Lock còn bật luôn chữ hoa của hệ thống.
  Cấu hình cũ đã chọn Alt + Z/Caps Lock tự dùng lại Ctrl + Shift (R2-106).

### Fixed

**Linux**
- **Đổi V/E rồi chuyển cửa sổ bị lật lại** (hồi quy từ 0.2.30): bấm Ctrl+Shift (hoặc menu)
  sang E, bấm sang cửa sổ khác là quay về V — IBus và Fcitx5 (R2-107; e2e mới "EN/VN giữ sau
  focus-out/in", đỏ trên bản cũ).
- Fcitx5 nhiều nhóm bộ gõ: TextVN được thêm vào nhóm ĐANG DÙNG (theo `GroupOrder`), không còn
  vào nhóm đầu file (R2-108).

**Windows**
- Tray không còn tự thoát khi Windows hỏi đăng xuất/khởi động lại mà lần đó bị huỷ (ví dụ
  Notepad hỏi lưu và bạn bấm Cancel) — chỉ thoát khi phiên kết thúc thật (R2-102).
- Nâng cấp: chỉ dừng tray chạy từ chính thư mục cài (bản portable/Store khác đang dùng được
  giữ nguyên), và dừng chắc chắn trước khi thay file (R2-105).
- Nâng cấp từ bản ≤ 0.2.30 mà chưa mở lại app: app đang mở (còn nạp bộ gõ cũ) vẫn nhận bật/tắt
  V/E từ khay và ngược lại (R2-109). Kèm theo các lỗi tên pipe của bản 0.2.31: `doctor` báo
  IPC "chưa kết nối" dù tray đang chạy, chế độ tương thích (hook) không liên lạc được với tray,
  `--stop` không gửi được lệnh thoát qua pipe.
- `TextVN.exe --status` khi tray không chạy báo `OFFLINE` thay vì panic (R2-101).
- Gỡ bản cài máy dọn TextVN khỏi danh sách bàn phím của mọi tài khoản đang đăng nhập, kể cả
  tài khoản gốc khi quản trị viên gỡ hộ — bản 0.2.30–0.2.31 có bước này nhưng chưa từng xoá
  được (đường dẫn registry sai) (R2-104).
- TSF: lỗi hiếm khi kết thúc composition không còn gây lặp chữ (R2-103).
- Kết nối tới tray chỉ nhận đúng `TextVN.exe` cùng phiên đăng nhập (R2-110); bộ cài build với
  tên sản phẩm khác (`/DMyAppName`) không còn bị từ chối đăng ký TSF (R2-111).
- Bản cài per-user gỡ không cần quyền quản trị vẫn hẹn xoá được file đang bị khoá (RunOnce;
  lệnh quá 260 ký tự được báo là không hẹn được thay vì báo thành công — R2-115).
- Tray chịu được lock bị "poison" ở mọi chỗ (menu khay, kết nối IPC) — gate tự động chặn
  `.lock()/.read()/.write().unwrap()` trong mã chạy thật (R2-114).

**macOS**
- Ứng dụng yêu cầu chốt chữ (commitComposition) nhận đúng chữ đang gõ; tuỳ chọn "Gõ không gạch
  chân" áp vào cả chiến lược của engine; app đang chạy nhận đúng tiến trình đang focus khi có
  nhiều tiến trình cùng bundle id.

### Known issues
- **Phần mềm diệt virus có thể cách ly nhầm** khi binary chưa có chữ ký Authenticode (chờ
  SignPath): 2026-10-11 Kaspersky cách ly `textvn-tsf.dll`/`TextVN.exe` của bản cài từ
  Microsoft Store khoảng 2 phút sau lần chạy đầu (gói cài vẫn thành công) — bằng chứng, hash
  để báo false positive và việc cần làm: `docs/specs/antivirus-false-positive.md` §10.

### Security / quy trình
- Preflight không còn cài/gỡ thật bộ cài trên máy dev (gate `store-validate`: bỏ qua khi
  artifact cũ hơn `Cargo.toml` hoặc chưa đặt `TEXTVN_STORE_VALIDATE=1`; CI vẫn chạy thật) (E18).
- Gate chữ ký git trong `release.yml`: commit và tag phát hành phải được GitHub xác nhận
  "Verified" (R6); tag phát hành ký bằng `git tag -s`.
- Quét rò rỉ private key/token (`check_no_secrets.py`, repo-hygiene + preflight), quét cả file
  mới chưa track (R2-112); `.gitignore` chặn các loại file khoá.

## [0.2.31] — 2026-10-11

> **Bản release candidate** — đã ký GPG (`.asc`, FPR
> `3921595ABC961199F15303B6C45B84D0C7F4A822`) + Sigstore keyless
> (`.cosign.sig`/`.cosign.cert`), `SHA256SUMS.txt` được clearsign — y như v0.2.29.
> **Chưa** Authenticode (Windows — chờ SignPath Foundation duyệt) và **chưa**
> Developer ID + notarization (macOS) — vẫn là candidate, không phải production.

### Fixed — hoàn tất roadmap audit 3 nền tảng (A6–A16, B6–B14, C1–C9)

Chi tiết từng finding + trạng thái: `docs/release/AUDIT-3PLATFORM-2026-10-07.md`.

**Windows**
- **A10**: `Activate`/`Deactivate`/`ActivateEx`/`OnSetFocus` bọc `catch_unwind` —
  panic thoát qua ABI COM không còn `abort` tiến trình host (Notepad/Chrome).
  Nhánh lấy `inner` thất bại nay trả `E_FAIL` thay vì `Ok(())` im lặng (trước đây
  `Advise` xong nhưng không lưu cookie → `Deactivate` không `Unadvise`, leak tới
  hết thread).

**macOS**
- **B7**: gather AX dedupe theo pid (`beginGather`/`endGather`) + `AXUIElementSetMessagingTimeout(0.3)`
  — app không phản hồi không còn treo gather, kết quả cũ không đè context mới.
- **B8**: `IpcServer` cap `app_id` ≤ 256 ký tự và tổng entry ≤ 256 — flood cùng-uid
  không còn phình RAM / làm Snapshot vượt 64KB (client thật không nhận được).
- **B9**: `clientPid` ưu tiên danh tính client từ `sender` (bundle id) thay vì
  `NSWorkspace.frontmostApplication` — panel phụ/XPC không còn làm preset sai.
- **B11**: xoá state chết `heldMods` + `noteFlagsChanged()`; `crashCount` lấy `max`
  thay vì `+= 1` (bỏ qua `count`).
- **B12**: `ipcClient(_:didReceive:)` ràng buộc `dispatchPrecondition(.onQueue(.main))`;
  `IpcClient.deinit` đồng bộ `tearDown()` đúng queue (không data race nguyên tắc).
- **B13**: `Diagnostics` log xoay ở 1 MiB (opt-in `TEXTVN_LOG=1`) — log debug không
  phình vô hạn.

**Linux**
- **C1**: xoá `lc_ipc_recv_frame` khỏi `linux_common.h` + `ipc_client.c` (API chết,
  mồi cho đúng lỗi CR-25 mất byte khi EAGAIN giữa frame).
- **C3**: thống nhất điểm poll IPC giữa IBus và Fcitx5 (focus/activate + word-start,
  không trên đường phím).
- **C7**: cửa sổ GTK settings ngắt handler `destroy` của cửa sổ con + huỷ cửa sổ con
  TRƯỚC khi free `TvWin` — hết UAF theo thứ tự destroy.
- **C8**: `tv_activate_fcitx5` đọc `DefaultIM` của nhóm đang dùng thay vì cứng
  `[Groups/0]`; deactivate đánh lại chỉ số cho MỌI nhóm (profile nhiều group nay
  thấy được bộ gõ).
- **C9**: `--config` không có `/` không còn ghi `state.json` lệch chỗ; `XDG_CONFIG_HOME`
  phải là đường dẫn tuyệt đối (`[0]=='/'`); `log.c` từ chối chuỗi bị cắt âm thầm +
  dùng `localtime_r` (an toàn thread) + `XDG_STATE_HOME` phải tuyệt đối; fcitx5
  destructor gọi `unregisterAction` (addon reload không còn con trỏ treo);
  `stage-linux.sh` chặn thư mục nguy hiểm (hệ thống, tổ tiên repo, HOME/ROOT/CWD)
  trước `rm -rf`; `field_detect.c` ghi rõ là stub chưa nối AT-SPI.

### Fixed — gate `clippy-linux` đỏ trên `main` (phát hiện khi chạy preflight)

`tray/src/main.rs`: `use std::io::{Read, Write}` và `PIPE_NAME` chỉ dùng trong hàm
`#[cfg(windows)]` nhưng import không gate → `cargo clippy --target x86_64-unknown-linux-gnu -D warnings`
đỏ (E11). Nay gate bằng `#[cfg(windows)]`.

## [0.2.30] — 2026-10-07

### Fixed (vòng 16 — audit 3 nền tảng: 19 fix, mỗi lỗi rà ≥2 lần theo view audit)

**Windows** — chi tiết từng lỗi: `docs/release/AUDIT-3PLATFORM-2026-10-07.md`
- **A1**: ILOT gỡ bàn phím Windows tự gắn thiếu tiền tố `0x` (R2-100 nửa vời) — chuẩn hoá spec.
- **A2/A8**: mirror WOW64 CTF cho HKCU là đường registry chết (HKCU\Software
  shared trừ Classes) — chỉ mirror CTF ở Machine; dọn mirror per-user cũ.
- **A3**: cài/nâng cấp khi tray đang chạy — installer dừng tray trước (`PrepareToInstall`),
  tray xử lý WM_QUERYENDSESSION/WM_ENDSESSION graceful cho RestartManager.
- **A4**: `--stop` dùng OpenMutexW(SYNCHRONIZE) — CreateMutexW(bInitialOwner=TRUE)
  khiến process dò trở thành chủ mutex → instance mới tưởng trùng và thoát.
- **A5**: ShellExecuteExW (UAC) trên thread không COM → CoInitializeEx đầu hàm.
- **A11**: RwLock poison trong svc không còn panic dây chuyền (into_inner).
- **A15**: marker notice ghi TRƯỚC hộp thoại (kill giữa chừng không hỏi lại vô hạn).

**macOS**
- **B1 (CAO)**: `preeditReplace`/`commitEarly` xoá chữ THẬT trước khi thu hồi
  marked — NSTextView xoá nguyên marked range thay vì ký tự thật → mất chữ.
  Đã retract-before-delete, nhất quán với backspaceType.
- **B2 (CAO)**: IPC client 3 đường offline vĩnh viễn (path dài / violation /
  không reconnect lúc focus) — giờ luôn retry + connect lại lúc focus.
- **B3**: `switch_key` (Alt+Z / Caps Lock) UI chết → IMK thực thi thật +
  Ctrl+Shift tap chỉ toggle khi đúng mode. 3 unit test mới.
- **B4**: crash-report pipeline đứt (không ai gửi) → engine lỗi gửi `.crashReport`.
- **B5**: "Mặc định" giữ macros/english_words/emoji/autostart (hết xoá âm thầm).
- **B6**: double-click app luôn báo awake (hết im lặng khi autostart bật).
- **B10/B13**: underline `.single` thật; xoá macro case-insensitive; cap từ EN 64.

**Linux**
- **C2**: dispatch IPC khoá bằng `"type":"X"` đầu frame (state key trùng tên
  message không còn hijack parsing).
- **C4**: override per-app hết hiệu lực → trở về base state (state.json/broadcast).
- **C5**: guard tràn buffer compose (text[256] OOB intra-object).
- **C6**: UTF-8 decoder chặn overlong/surrogate/>U+10FFFF.

## [0.2.29] — 2026-10-10

### Fixed — gỡ cài đặt sạch (R2-99, R2-100)
- Gỡ cài đặt (bộ cài, portable, Store) **thoát TextVN trước** mọi bước và chờ nó tắt
  hẳn — trước đây gỡ lúc TextVN đang chạy có thể sót `TextVN.exe` vì file còn bị khoá.
  Menu khay "Gỡ cài đặt" của bản cài mở trình gỡ (có hộp UAC với bản cho mọi người
  dùng) rồi tự thoát.
- Gỡ cài đặt **dọn cả danh sách ngôn ngữ/bàn phím**: ngoài bàn phím TextVN, ngôn ngữ
  mà chính TextVN đã thêm (ví dụ máy chỉ có tiếng Anh, cài TextVN thêm "Tiếng Việt")
  được bỏ khi người dùng không gắn bàn phím nào khác cho nó — không còn sót "Tiếng
  Việt" với bàn phím Windows tự gắn. Ngôn ngữ bạn có sẵn thì giữ nguyên. Ctrl + Shift
  được trả cho Windows như trước.

### Changed
- Gói `.msix` kèm bản phát hành mang identity thật của Microsoft Store
  (`23651Linhi.TextVN`) — nộp thẳng được, có chữ ký GPG/Sigstore như mọi file.

## [0.2.28] — 2026-10-10

### Added
- Workflow phát hành có ô nhập `msix_identity_name`: build lại riêng gói MSIX nộp Store
  (identity từ Partner Center) trên tag đã phát hành; chạy tay chỉ build, không đụng
  release đã công khai (`docs/release/msix-submission.md` §3). Gói `.msix` kèm release
  0.2.28 mang identity tạm — chỉ để thử, không nộp.

### Fixed — kiểm trên Windows 11 thật và rà soát đối kháng (R2-88…R2-98, chi tiết: `docs/release/code-review-2026-10-09-round2.md` §3.7)
- Gỡ bản portable/Store từng nâng cấp từ 0.2.27 nay trả lại Ctrl + Shift cho Windows
  (trước đây bản ghi Ctrl + Shift bị mất khi nâng cấp).
- Gỡ một bản TextVN (portable, bộ cài) không còn tắt hay gỡ đăng ký bộ gõ của bản
  TextVN khác đang dùng (bản cài ở thư mục khác, bản Store).
- Bỏ chọn "Khởi động cùng Windows" ở bản cài cho mọi người dùng nay có hiệu lực (trước
  đây trông như đã lưu nhưng lần đăng nhập sau TextVN vẫn tự chạy).
- Gỡ gói Store rồi cài lại trước lần đăng nhập kế: tự khởi động bật như lần cài đầu.
- File bị khoá sau khi gỡ được dọn ở lần đăng nhập kế cả khi đường dẫn dài.
- `deed`, `deeds`, `dosed` không còn thành `đê`, `đế`, `đoé` (gõ `đê` vẫn là `ddee`).
- Phát triển: `build-release.ps1` không còn đăng ký bộ gõ trỏ vào thư mục build hay đổi
  Ctrl + Shift của máy dev, và không dừng khi DLL x86 trong thư mục build đang bị app
  32-bit nạp; test gõ thử chạy được trên Notepad Windows 11; test IPC không còn nối vào
  TextVN đang chạy trên máy.

### Fixed — rà soát vòng 2: Microsoft Store, ký số, QA (chi tiết: `docs/release/code-review-2026-10-09-round2.md`)
- **Microsoft Store (MSIX) chạy thật**: bản cài từ Store chép chương trình ra ngoài gói
  (`%USERPROFILE%\.textvn`, `%LOCALAPPDATA%\Programs\TextVN-Store`) bằng tiến trình thoát
  khỏi container rồi mới đăng ký bộ gõ — trước đây mọi ghi bị Windows ảo hoá nên app khác
  không thấy TextVN. Gỡ gói Store thì lần đăng nhập kế dọn sạch đăng ký, mục khởi động,
  Ctrl + Shift và file đã chép; Store cập nhật thì tự chép lại. Bản Store **hỏi** trước khi
  dành Ctrl + Shift và không bao giờ xin quyền Administrator. CI cài thử gói thật mỗi lần.
- Gói MSIX nộp được: Version `(A+1).B.C.0` (Partner Center từ chối số đầu 0), mô tả tiếng
  Việt không còn lỗi mã hoá, ảnh 71×71 đúng, identity theo Partner Center
  (`MSIX_IDENTITY_NAME`), `tools/win/verify-msix.py` kiểm gói trước khi nộp.
- **Bảo mật Windows**: không còn đăng ký bộ gõ cho cả máy từ thư mục người dùng ghi được
  (chỉ từ Program Files); gỡ bản portable chỉ xoá đúng file TextVN, không bao giờ xoá cả thư
  mục; mọi binary link CRT tĩnh (không cần VC++ redist); bộ cài `-machine.exe` được ký khi
  bật SignPath.
- Windows: nâng cấp **giữ nguyên** kiểu gõ, tuỳ chọn và thiết lập theo app (trước đây bị
  reset mỗi bản) và không làm mất kích hoạt bộ gõ; bản cài cho mọi người dùng tự đăng ký cho
  từng tài khoản; menu "Bật tiếng Việt cho {app}" hiển thị đúng; "Từ điển EN" dùng Tab/Esc
  được; "Kiem tra he thong" không đóng ngay; "Cài & bật TSF" không còn treo Bảng điều khiển.
- Windows: bỏ "Dành Ctrl + Shift" thì TextVN không còn kéo bạn về TextVN mỗi khi Windows
  đổi bàn phím; gỡ cài đặt (bộ cài, portable, Store) trả Ctrl + Shift về **đúng giá trị
  trước đó** (cả phím đổi ngôn ngữ), không đụng lựa chọn bạn tự đặt.
- Gõ tiếng Việt: auto-restore và Tab gợi ý không còn biến từ Việt thành tiếng Anh (`thí`,
  `vơ`, `hót`, `có`+Tab); giữ `đ` trong `50.000đ`, `ĐT`, `đc`, `đ/c`.
- **Backspace xoá ký tự cuối đang hiển thị** như UniKey (`tiếng`+⌫ → `tiến`; trước đây
  hoàn tác phím cuối: `ass`+⌫ ra `á`, xoá `được` cần 8 lần ⌫).
- Tự viết hoa chỉ ở đầu câu (`. ! ?` + khoảng trắng, hoặc Enter): `google.com`, `file.txt`,
  `3.5 kg` không còn thành `google.Com`…
- VNI/VIQR gõ dấu sau cả cụm nguyên âm ra đúng (`toi6` → tôi, `nguoi72` → người); Telex `w`
  sau cụm nguyên âm đúng âm (`muaw` → mưa, `voiws` → với); Telex `w` đứng riêng → `ư`
  (`nhw` → như) như UniKey; đổi qua lại giữa dấu mũ và móc (`toow` → tơ, `awa` → â); bấm phím
  dấu lần ba gỡ dấu và gõ chữ đó (`xooong` → xoong); `d` gõ sau trong từ thành `đ` đầu từ
  (`duocjwd` → được); VNI `0` chỉ gỡ dấu thanh; Telex đơn giản gõ được ă/ơ/ư bằng `aw/ow/uw`.
- Không còn thêm dấu mũ tự động cho `iet` (`Viet`, `quiet` giữ nguyên); từ tiếng Anh như
  `sort`, `keep`, `chart`, `using`, `music` không còn bị biến thành âm tiết không tồn tại.
- Lưu ý: `w` + chữ số (`w3c`) nay ra `ư3c` như UniKey — bấm Escape để trả lại.
- macOS: chọn cách chèn chữ theo app hoạt động trở lại (trước luôn rơi về một cách);
  "Gõ không gạch chân" có hiệu lực ngay; Ctrl + Shift bật lại được khi TextVN.app không chạy;
  gõ tắt cùng luật với Windows/Linux; gỡ bản cài cho mọi người dùng hỏi quyền quản trị; ký
  Developer ID + notarize tự chạy khi có chứng chỉ Apple.
- Linux: Fcitx5 luôn thấy addon gốc của nó; IBus chạy được khi đường dẫn cài có khoảng
  trắng; `sudo ./install.sh --system` không đụng thiết lập của người dùng; cửa sổ Cài đặt
  GTK không còn mất cửa sổ Từ điển EN.
- Phát hành: ký GPG + Sigstore **bắt buộc** trong CI (thiếu khoá thì dừng); SignPath dùng
  đúng REST API, một lần duyệt cho cả bộ binary; cask Homebrew đúng sha; build `--locked`;
  thiếu VERSIONINFO thì build fail; release notes nói đúng trạng thái ký số.

### Fixed — rà soát mã nguồn chuyên sâu 2026-10-07 (chi tiết: `docs/release/code-review-2026-10-07.md`)
- **Mất chữ (P0)**: giữ phím lặp sau từ có dấu (`đẹppppp…`, > 64 phím) từng làm phím
  kế tiếp xoá lẹm chữ phía trước — engine giờ đóng từ khi chạm giới hạn, FFI từ chối
  thay vì cắt kết quả (CR-01/02). macOS: self-heal con trỏ chạy trước engine (CR-28).
- Phím tắt Ctrl/Alt/Cmd giữa từ không còn để phím kế tiếp sửa nhầm từ ở chỗ khác
  (engine, hook Windows, macOS — CR-04/13/29); macOS: Enter/Tab sau từ có dấu gửi đúng
  phím thật (Messages/Slack gửi tin, Tab chuyển ô — CR-30), phím điều hướng không chèn
  ký tự điều khiển (CR-31).
- Ô mật khẩu (role secure) luôn đi thẳng kể cả khi app quên cờ secure (CR-06).
- Windows: pipe client không cho server giả mạo impersonate (CR-09); tray không còn
  chiếm lại Ctrl + Shift mỗi lần khởi động (CR-17); gói chẩn đoán không chứa gõ tắt/từ
  điển của người dùng (CR-21); bộ cài thay/gỡ được `textvn-tsf-x86.dll` khi app 32-bit
  đang mở và dọn đúng file `.old-*` (CR-37); DLL x86 được ký cùng các binary khác (CR-36).
- Linux: client IPC không còn SIGPIPE làm sập ibus-daemon/fcitx5, không mất frame
  nhận dở dang (CR-24/25).
- macOS: lưu cài đặt không còn xoá danh sách emoji và trường `when` của gõ tắt (CR-33).
- Hướng dẫn kiểm chữ ký phát hành (`docs/release/signing.md`) dùng đúng tên `.asc` và
  workflow `release.yml` (CR-39).

## [0.2.27] — 2026-10-07

### Added (macOS) — toggle "Gõ không gạch chân" được tôn trọng (BUG-05, vòng 15)
- **BUG-05 fix**: toggle "Gõ không gạch chân (Non-preedit)" trong Bảng điều
  khiển ghi `non_preedit` vào config nhưng IMK **từng bỏ qua hoàn toàn** —
  giờ IMK đọc khoá này: bật → strategy Preedit (gạch chân) hạ xuống
  BackspaceType (không gạch chân, tương thích rộng hơn); tắt → preedit có
  gạch chân như trước. Config cũ thiếu khoá → giữ gạch chân (không đổi
  hành vi âm thầm). 3 unit test mới.
- **Ký số release tự động** (cả 3 platform): GPG detached signature
  (FPR `3921595A…`) + Sigstore keyless provenance cho **mọi asset** +
  clearsign SHA256SUMS.txt — chi tiết và lệnh verify: `docs/release/signing.md`.
- **MSIX hoàn thiện**: payload thêm `textvn-tsf-x86.dll` (app 32-bit dùng
  được sau stage-out) + DisplayName = `TextVN` khớp Partner Center.
- Audit đối chiếu: BUG-03 macOS (IMK nhận `"*"`), M-01 (menu sync didSet),
  M-03 (Swift matrix 2 arch) — **đã được xử lý sẵn từ các vòng trước**
  (finding audit dựa trên snapshot cũ); SEC-04 docs đồng bộ path mới.

## [0.2.26] — 2026-10-05

### Added (Windows) — hỗ trợ app 32-bit (Zalo/Office x86) — vòng 14
- **Forensics thật trên máy chủ repo**: `Zalo.exe` là **32-bit** (PE machine
  `0x014C`); TextVN chỉ có DLL 64-bit → tiến trình 32-bit không thể nạp
  (ERROR_BAD_EXE_FORMAT 193) → "không gõ được tiếng Việt trên Zalo" (không
  phải lỗi strategy/appdb). `HKCR\WOW6432Node\CLSID\{TIP}` xác nhận **trống**.
- **Build thêm TIP DLL x86** (`i686-pc-windows-msvc`, CRT static — không cần
  VC redist x86) + **mirror đăng ký sang view 32-bit** (WOW6432Node: COM CLSID
  → x86 DLL, CTF TIP/profile/category) cho cả 2 scope; unregister xoá mirror.
- Bộ cài/portable đóng gói `textvn-tsf-x86.dll`; gate WOW6432Node trong
  test-installer + ghost gate mở rộng.
- Zalo appdb giữ Preedit (thiết kế B2 gốc — DLL load được thì Electron xử lý
  preedit tốt như Discord/Slack; nguyên nhân thật là kiến trúc, đã sửa).

### Fixed (Windows) — gỡ cài sạch 100% key layout (vòng 13, bắt thật + dọn live trên máy chủ repo)
- Dump registry trước/sau khi gỡ 0.2.19 cho thấy **27 path còn chứa GUID TIP**:
  `CTF\Assemblies\<lang>\{34745C63…}[Default]` (bộ gõ mặc định của 2 ngôn ngữ
  — Windows tự ghi khi ActivateLanguageProfile), `InputMethodOverride`
  (default IME override), và cả cây HKLM machine registration từ đợt self-heal
  portable. Chọn vào Win+Space là TIP chết.
- `unregister` giờ xoá **hết**: quét mọi ngôn ngữ trong Assemblies, xoá value
  `Default` nếu chứa CLSID TextVN; xoá `InputMethodOverride` nếu trỏ TextVN;
  unregister user-scope cố dọn nốt HKLM best-effort.
- Bộ cài: bỏ `Check: IsAdminInstallMode` — gỡ per-user cũng thử dọn nốt HKLM
  (không elevation thì fail êm, không ảnh hưởng exit code).
- Tray: đăng ký máy trỏ file không tồn tại = ghost → coi như chưa có để repair.
- Gate tự động: test-installer quét mọi key/value chứa GUID TIP sau uninstall
  (HKCU + HKLM) — lệch một key là CI đỏ.
- Verify live trên máy chủ repo: 27 path → elevated unregister → **0 path**.

## [0.2.25] — 2026-10-05

### Added (Windows) — MSIX đúng chuẩn: bootstrap stage-out (vòng 12 audit)
- **Vấn đề thật của MSIX trước đây**: tray chạy từ `C:\Program Files  WindowsApps\<Package>_<version>_…` tự đăng ký TSF **trỏ vào DLL trong
  package** — (a) thư mục package chứa version và bị XOÁ sau mỗi lần Store
  update → đăng ký COM/CTF treo lơ lửng → mất gõ cho tới khi mở lại app;
  (b) ghi registry của tiến trình đóng gói có thể bị registry virtualization
  điều hướng vào hive riêng → đăng ký vô hình với Notepad/explorer.
- **Giải pháp**: exe trong package giờ chỉ làm một việc — stage toàn bộ payload
  (tray, CLI, TSF DLL, resources, data) ra `%LOCALAPPDATA%\Programs\TextVN`
  rồi spawn bản staged và thoát. Bản staged chạy **non-packaged** → dùng lại
  nguyên vẹn cơ chế portable (tự đăng ký TSF, UAC phạm vi máy B7, Run key, IPC).
  File bị khoá khi re-stage xử lý bằng rename-then-copy (B8).
- **Payload MSIX thiếu `resources/` + `data/`** từ trước — đã bổ sung (tray
  staged cần icon + appdb mặc định).
- 4 unit test mới cho bootstrap (nhận diện package, stage đủ file/dir, ghi đè
  khi stage lại, không relaunch ngoài WindowsApps).
- Đo thật trên máy: tiến trình thường **đọc được** file trong WindowsApps
  (READ OK) — loại trừ nghi ngờ ACL; nguyên nhân còn lại là update-fragility
  + virtualization → bootstrap xử lý cả hai.

## [0.2.24] — 2026-10-05

### Fixed (Windows) — hoàn thiện nốt entry ARP + metadata (rà dòng lần 3) + chốt bản máy cho Store
- **`UninstallDisplayIcon`**: entry ARP trước đây **thiếu value `DisplayIcon`** —
  checker/icon của Programs and Features nhìn vào sẽ thấy entry không hoàn
  chỉnh. Đã verify end-to-end bằng probe: `DisplayIcon` giờ xuất hiện đúng
  đường dẫn exe.
- **`VersionInfoTextVersion`**: chuỗi `FileVersion` của setup.exe trước đây
  **TRỐNG** (chỉ có số nội bộ) — metadata file giờ đầy đủ `0.2.24` ở cả 2 biến
  thể (verify bằng Get-Item VersionInfo).
- **`SetupLogging=yes`**: log cài đặt ghi vào %TEMP% — nếu validation vẫn fail,
  log trên VM của Microsoft là bằng chứng duy nhất ta có thể yêu cầu qua ticket.
- **Chốt theo quyết định chủ repo**: bản **machine (admin/all-users, HKLM) là
  bản Store chính thức** — MS doc cho phép UAC ("UAC prompts are allowed");
  portable giữ nguyên; GitHub users vẫn nhận bản per-user.
- 0.2.24 = gói mới cho lần nộp kế tiếp (B13g).

## [0.2.23] — 2026-10-05

### Fixed (Windows) — Publisher display name THẬT là `LinhBH.CoM` (chủ tài khoản tìm đúng trang trong account và tự sửa)
- Kết thúc chuỗi đoán định danh: **Publisher display name = `LinhBH.CoM`** —
  chủ tài khoản tìm vào account settings (trang khác với nơi hay xem) và
  **chỉnh sửa trực tiếp** thành giá trị này.
- Giải thích trọn lịch sử: 0.2.16–0.2.20 đã ghi **đúng** `LinhBH.CoM` — các
  vòng đó thua vì lý do khác (0.2.16 exit 10; 0.2.18 admin/740; 0.2.19 bẫy
  B13g "no changes" — nộp lại URL cũ nên không revalidate). 0.2.21 (`Linh βùi`)
  và 0.2.22 (`Linh Bui`) là hai lần **đọc/suy đoán sai** từ nguồn không phải
  trang publisher info.
- ARP `Publisher` = `LinhBH.CoM`; `DisplayName` = `TextVN` (khớp ✓).
- **B18 bổ sung**: Publisher display name nằm ở trang riêng trong account —
  phải vào đúng trang đó và dump codepoint trước khi tin bất kỳ chuỗi nào.
  Repo VARIABLES cập nhật theo: `STORE_PUBLISHER_NAME=LinhBH.CoM`
  (CI đối chiếu giá trị thật mỗi commit).
- 0.2.23 = gói MỚI cho lần nộp kế tiếp (B13g); kèm machine variant là release
  asset chính thức (từ 0.2.22).

## [0.2.22] — 2026-10-04

### Fixed (Windows) — ROOT CAUSE thật của 6 vòng đỏ: publisher phải là "Linh Bui" (B18)
- Chủ tài khoản xác nhận **lần 2** (sau khi audit vòng 6 chỉ ra khả năng nhầm
  font): Publisher display name trên Partner Center là **`Linh Bui`** — ASCII
  thuần. Lần trước đọc nhầm font: chữ **B** (U+0042) trông giống beta **β**
  (U+03B2). Kết luận dựa trên bằng chứng: chuỗi publisher trong ARP **chưa bao
  giờ khớp** ở bất kỳ lần nộp nào — 0.2.16-0.2.20 để `LinhBH.CoM`, 0.2.21 để
  `Linh βùi` → đúng nguyên nhân *"could not identify the app name and the
  publisher name"*.
- ARP `Publisher` = `Linh Bui`; tên sản phẩm `TextVN` giữ nguyên (đã khớp ✓).
- **B18**: định danh phải xác minh bằng **codepoint dump** từ nguồn sự thật
  (`($s.ToCharArray() | % { 'U+{0:X4}' -f [int]$_ }) -join ' '`), không tin mắt.
  Harness + simulate dùng mặc định `Linh Bui` và in codepoint khi lệch.
- Đã đặt repo VARIABLES `STORE_APP_NAME=TextVN`, `STORE_PUBLISHER_NAME=Linh
  Bui` → CI đối chiếu ARP với giá trị thật mỗi commit (hết tự-so-mình).
- Machine variant (HKLM) giờ là **release asset chính thức**: `build-release
  -MachineInstaller`; release.yml build + validate `-MachineOnly` + kèm vào
  release; publish job kiểm đúng 2 setup exe.
- Lần nộp kế tiếp: **per-user 0.2.22 trước** (ít rủi ro nhất, kiểm đúng giả
  thuyết chuỗi); nếu vẫn đỏ → machine 0.2.22 (kiểm giả thuyết HKLM); nếu vẫn
  đỏ → MSIX (`CN=1A703CAB-…` đã có, chờ `Package/Identity/Name`).

## [0.2.21] — 2026-10-04

### Fixed (Windows) — Publisher khớp ĐÚNG Partner Center (STO-03, chủ tài khoản xác nhận)
- **ARP `Publisher` = `Linh βùi`** (beta U+03B2, ù U+00F9) — chính là **Publisher
  display name** trên Partner Center; trước đây để `LinhBH.CoM` (nhãn hiệu) nên
  validator báo *"could not identify the app name and the publisher name that
  your app has added in the add or remove programs"*. Tên sản phẩm đã reserve
  là `TextVN` → `DisplayName` giữ nguyên `TextVN` (khớp ✓).
- `.iss` giữ **UTF-8 BOM** để ISCC đọc đúng ký tự đặc biệt ở mọi phiên bản Inno
  (BOM = dấu hiệu UTF-8 theo spec, không phụ thuộc auto-detect).
- **Verify end-to-end (probe riêng, AppId tạm)**: cài im lặng → đọc ARP →
  `Publisher` đúng codepoint `U+004C U+0069 U+006E U+0068 U+0020 U+03B2 U+00F9
  U+0069`, khớp tuyệt đối → gỡ cài sạch. Harness & simulate giờ dựng chuỗi kỳ
  vọng bằng `[char]` (file .ps1 ASCII-only) và **in codepoint khi lệch**.
- Kèm từ vòng 4 audit (đã có trong 0.2.20/nhánh): `/DMachineInstall=1` +
  `-MachineOnly` (bằng chứng CI run 37198638991: ARP ở HKLM PASS 5/5 trên runner
  elevated), cảnh báo MSIX identity placeholder, `B15` (VirusTotal không chặn
  release), `B16` (uninstaller Inno bất đồng bộ → harness phải POLL).

## [0.2.20] — 2026-10-04

### Fixed (Windows) — CI đỏ .iss + vòng 3 validation (B13/B14)
- **CI "Windows package" đỏ**: `textvn-setup.iss` dùng `RegDeleteKeyValue` —
  Pascal Script của Inno Setup KHÔNG có hàm này (chỉ `RegDeleteValue`). Sửa +
  ghi mã **B14**: mọi thay đổi `[Code]` phải biên dịch thật bằng ISCC trước khi
  push. Uninstaller giờ chỉ trả `Layout Hotkey` về mặc định khi giá trị = 3
  (đúng override của TextVN, giống `uninstall.ps1`; tôn trọng lựa chọn khác
  của người dùng).
- **Harness `validate-store-package.ps1` "đúng như Microsoft expected"**: thêm
  bước 0 đọc manifest exe — BẮT BUỘC `asInvoker` (exe `requireAdministrator`
  làm `CreateProcess` non-elevated của validator fail 740 TRƯỚC khi cài → cả
  3 mục đỏ; đo thật exit=2 — B13e); ARP so **từng chữ** DisplayName `TextVN` +
  Publisher `LinhBH.CoM` + có DisplayVersion (hết `-like` — B13f).
- **Bẫy "We did not find any changes in the Package or the Silent install
  parameters"** ghi thành B13g: nộp lại cùng gói/cùng URL → Partner Center
  không chạy lại validation. Mỗi lần nộp phải là phiên bản mới (0.2.20).
- `build-release.ps1 -BuildInstaller` tìm được ISCC cài per-user bằng winget
  (`%LOCALAPPDATA%\Programs\Inno Setup 6\`) — trước đó fail dù mọi bước khác
  xanh.

### Security / hardening (audit 2026-10-04, phần còn lại)
- **SEC-02 vòng 2**: tray chỉ tự nâng quyền (UAC) từ thư mục cài chuẩn —
  Program Files (gồm MSIX `WindowsApps`) và `%LOCALAPPDATA%\Programs` (bộ cài
  per-user / gói .exe Store). Thư mục tự chọn (Downloads, ổ D: portable) bị TỪ
  CHỐI (CWE-426/732: DLL planting cạnh binary sẽ chạy bằng admin) + thông báo
  MỘT lần cách cài đặt (thread riêng, không chặn `--stop`). Bước nâng quyền chỉ
  tới sau khi activation per-user thất bại thật (B7) — bản cài chuẩn tự chữa
  được như cũ.
- **SEC-05**: named pipe IPC tạo với DACL chỉ user hiện tại (+SYSTEM/
  Administrators) — hết cảnh user khác cùng máy (phiên RDP) đọc ConfigReload/
  StateUpdate và gửi Shutdown giả.
- **SEC-04**: IPC client Linux ưu tiên `$XDG_RUNTIME_DIR/TextVN/ipc.sock`,
  fallback `/tmp/textvn-<uid>/`; guard `lstat` (đối tượng phải là socket của
  chính user) trước `connect`.
- **PERF-01**: quét từ điển restore-EN lọc theo độ dài trước `to_lowercase()`
  (hết alloc thừa mỗi ranh giới từ).
- **BUG-03 / 3.2.B / 3.2.C**: ghi rõ lý do hoãn trong phụ lục roadmap — parser
  Linux `app_id:"*"` là code chết (poll chưa được gọi; sửa cùng Linux tray
  P3-0); `non_preedit` macOS và non-preedit Linux là thay đổi hành vi cần test
  thật với Chromium/Office (F3-021).

## [0.2.19] — 2026-10-04

### Fixed (Windows) — loại bỏ TỪNG blocker còn lại của silent install (B13)
- **ShowLanguageDialog=no**: `/VERYSILENT` vẫn có thể bị hộp thoại chọn ngôn
  ngữ chặn khi locale máy cài không khớp [Languages] (auto → hiện dialog khi
  không tìm được ngôn ngữ hệ thống) — cài không hoàn tất = cả 3 check Store đỏ
  cùng lúc. Giờ không còn dialog nào trong mọi trường hợp.
- **Silent = pure file copy**: bỏ gọi đăng ký TSF trong tiến trình installer
  khi silent (API TSF có thể treo trong phiên không-interactive của validator)
  — app tự đăng ký ở lần chạy đầu (tray tự đề nghị UAC một lần khi cần, 0.2.16).
- Hai entry `[Run]` `config init`/`--free-ctrl-shift` thêm `skipifsilent`.
- Per-user giữ nguyên (0.2.18 đã thử admin/HKLM — CreateProcess của validator
  fail 740 với exe requireAdministrator trước khi cài gì cả, exit=2 bắt thật).
- Harness `validate-store-package.ps1`: ghi chú ARP hai hive; đã verify 4/4
  PASS với installer mới (silent 2s exit 0 → ARP 'TextVN'|'LinhBH.CoM'|'0.2.18'
  → 1 entry → uninstall sạch).

## [0.2.18] — 2026-10-03

### Fixed (Windows) — Package validation vòng 2 (B13)
- Sau khi 0.2.17 chuyển per-user, 3 mục validation vẫn đỏ: **validator của Store
  CHỈ đọc entry Add/Remove trong `HKLM`** — bản cài HKCU bị bỏ qua
  ([Microsoft Q&A 1922205](https://learn.microsoft.com/en-us/answers/questions/1922205/)).
  Khôi phục `PrivilegesRequired=admin` (machine install → HKLM; sandbox validator
  chạy installer đã elevated nên không sinh UAC tại đó) — **vẫn giữ silent luôn
  exit 0** (fix thật của vòng 1; exit 10 của 0.2.16 là cớ fail còn lại).
- **ARP DisplayName = đúng tên sản phẩm**: `AppVerName={#MyAppName}` — entry giờ
  là "TextVN (0.2.18)"→ hiển thị khớp "TextVN" trên Partner Center từng chữ
  (trước là "TextVN version 0.2.17", dễ bị đối chiếu trượt).
- Harness `validate-store-package.ps1` **ép entry mới phải nằm ở HKLM** (đúng
  cơ chế validator; cờ `-PerUser` chỉ để test riêng nhánh per-user).
- Chuỗi ô switches của Store giữ nguyên `/VERYSILENT /SUPPRESSMSGBOXES /NORESTART`;
  KHÔNG thêm `/CURRENTUSER` (đó là đường tắt gây chính lỗi HKCU này).

## [0.2.17] — 2026-10-03

### Fixed (Windows) — Package validation của Microsoft Store (B13)
- **Bộ cài mặc định PER-USER** (`PrivilegesRequired=lowest`): validator của Store
  chạy installer trong sandbox không auto-elevate; bản cài đòi admin (0.2.16)
  làm 3 check đỏ — "Silent install check: could not identify…", "Entry in add or
  remove programs" và "Bundleware check" (không đọc được entry) → nút Submit
  mờ. Per-user không cần UAC nên silent install qua validator sạch; muốn cài
  phạm vi máy dùng `/ALLUSERS` (Inno tự xin elevation) — KHÔNG thêm vào ô
  switches của Store.
- **Silent install luôn exit 0** khi đã chép đủ file: trước đây đăng ký TSF
  lỗi trong sandbox → exit 10 → Store coi là "cài thất bại". Nay app TỰ đăng ký
  ở lần chạy đầu (0.2.16: tray tự đề nghị UAC một lần nếu Windows từ chối
  per-user) — exit 10 chỉ còn cho cài tương tác.
- **Prompt đăng ký máy của tray chạy cả khi `--autostart`**: tránh trường hợp
  máy từ chối per-user + người dùng không bao giờ mở app → gõ hỏng IM LẶNG
  (vẫn guard: một lần duy nhất + bỏ qua khi elevated).
- Theo [manual package validation của Microsoft](https://learn.microsoft.com/en-us/windows/apps/publish/publish-your-app/msi/manual-package-validation):
  đã chạy đủ 3 bước tại máy thật (silent install không tương tác → entry
  Add/Remove đúng Name/Publisher/Version → đúng 1 entry).

## [0.2.16] — 2026-10-03

### Fixed (Windows) — portable "giải nén chạy ngay" hoạt động trên Win11 24H2+
- **Tray tự đề nghị đăng ký phạm vi máy khi Windows từ chối per-user** (B7):
  phát hiện `activate` thất bại (chưa có HKLM) → hộp thoại một lần
  "Đăng ký phạm vi máy để gõ được ngay? (UAC một lần)" → chạy
  `textvn-cli register --scope machine` ELEVATED → chờ HKLM → register lại
  per-user → activate. Không hỏi khi `--autostart` (không làm phiền lúc đăng
  nhập) và bỏ qua nếu máy đã có đăng ký máy.
- **Tự bật lại chế độ TIẾNG VIỆT sau khi đăng ký máy**: bẫy phát hiện khi
  chẩn đoán live — TIP đúng + activation OK nhưng `global_enabled=false`
  (EN mode, ví dụ do người dùng bấm Ctrl+Shift thử trước đó) cũng cho ra chữ
  raw, khiến "đăng ký thành công" mà vẫn tưởng hỏng.

### Verified live trên máy thật (máy chủ repo, build 26300 — trường hợp từng fail)
- Cài portable 0.2.15 → tray mới hiện prompt → OK + UAC Yes → HKLM COM trỏ
  DLL trong thư mục portable; `ActivateProfile(VI, session) → OK`;
  HKL Notepad = `0x042A`; gõ thật `dduocj text ` → **`được text ` PASS**.
- Đây là lần đầu tiên đường portable đứng một mình gõ được trên máy này.

## [0.2.15] — 2026-10-03

### Fixed (Windows)
- **Gỡ TextVN không còn để lại ghost trong Win+Space** (B11): `unregister` chỉ
  xoá COM + CTF keys, không đụng "danh sách ngôn ngữ hiện đại" — sau khi gỡ,
  TextVN vẫn hiện trong Win+Space nhưng chọn vào là chết. Giờ
  `remove_modern_language_list()` xoá đúng entry (giữ ngôn ngữ) + broadcast
  `WM_SETTINGCHANGE("International")` chuẩn (SendMessageTimeout + lParam
  "International" thay cho PostMessage lParam=0). **Đã verify 2 chiều trên
  máy thật**: unregister → TextVN biến mất khỏi cả `vi` lẫn `en-US`;
  register → trở lại đủ.
- **Hết DLL mồ côi sau khi gỡ** (B12 — "tại sao không tắt TSF rồi xoá DLL?":
  DLL do TSF của Windows nạp vào mọi app đang mở, không phải service TextVN,
  không thể tắt; Windows cấm xoá file đang map):
  - Installer: `usPostUninstall` → `DeleteFile` trước, trượt thì ghi
    `PendingFileRenameOperations` (chuẩn Windows cho mọi installer) cho DLL +
    `*.old-*` + thư mục — không dùng `MoveFileExW` qua external import vì
    Pascal Script không có kiểu `Pointer` để truyền NULL (ISCC từ chối).
  - Sửa luôn bug `[UninstallDelete]` chứa **TAB thay vì `\`** trong pattern
    (`{app}<TAB>extvn-tsf.dll.old-*`) — chưa bao giờ khớp; thêm pattern
    `TextVN.exe.old-*`.
  - Portable: `uninstall.ps1` khi xoá trượt sẽ ghi
    `HKCU\...\RunOnce\TextVNCleanup = cmd.exe /c rmdir /s /q "<dir>"` —
    tự dọn ở lần đăng nhập kế tiếp (không cần admin). Hướng dẫn portable đã
    đổi thành "tự dọn, không cần làm gì thêm".
  - **Verify máy thật**: giữ DLL bằng `LoadLibraryEx` (mô phỏng app đang mở)
    → `uninstall.ps1` phát hiện khoá + ghi RunOnce đúng; nhả khoá + chạy đúng
    lệnh RunOnce → toàn bộ file bị xoá.

### Verified — toàn bộ luồng portable "chạy ngay" (yêu cầu chủ repo)

| Hạng mục | Kết quả |
|---|---|
| Giải nén ZIP (13 file: exe/cli/dll/scripts/hướng dẫn/report) | ✓ đủ |
| `TextVN.exe` first-run tự đăng ký | ✓ COM→folder giải nén, CTF Enable=1, TIP registry OK |
| TextVN xuất hiện trong Win+Space (cả en-US lẫn vi) | ✓ (0.2.12 fix — lỗi "mất khỏi danh sách" không tái diễn) |
| Tray + IPC + doctor | ✓ đang chạy, pipe lắng nghe |
| `uninstall.ps1` | ✓ gỡ COM/CTF sạch; ghost modern-list — đã fix trong bản này |
| `activate` (kích hoạt tự động) | ✗ E_FAIL — **B7 tái diễn đúng như tài liệu**: build 26300 từ chối per-user |
| Gõ thật trong Notepad (chọn qua Win+Space) | ✗ không lần nào ra TextVN (chỉ MS-Telex) — portable-only KHÔNG đủ trên build này; **bộ cài phạm vi máy là đường duy nhất đã chứng minh gõ được** |
| Lỗi cũ khác (ghost COM folder xoá / mất Win+Space / autostart ghost) | ✓ không tái diễn |

Hướng dẫn portable (`HUONG_DAN_SU_DUNG.txt`) đã nêu rõ: máy Win11 24H2+ nên
dùng bộ cài.

## [0.2.14] — 2026-10-03

### Fixed (Windows)
- **DPI theo màn hình — hết cắt chữ**: dialog dùng `GetDeviceCaps(LOGPIXELSX)`
  (system-DPI cũ 96) trong khi manifest PerMonitorV2 render theo DPI monitor
  thật (192 ở scaling 200%) → chữ to gấp đôi, control tràn, nhãn bị "nuốt"
  ("…gõ sa"). Giờ: `GetDpiForSystem` + sau khi tạo cửa sổ đọc
  `GetDpiForWindow` — khác thì resize đúng cỡ rồi mới layout; áp cho cả 3
  cửa sổ (Bảng điều khiển, Gõ tắt, Từ điển EN). Đã xác minh bằng ảnh chụp
  DPI-aware: 1226px đúng cho màn 200%, đủ nhãn (B10).
- **Nhãn dài không bao giờ bị cắt**: checkbox "Khôi phục từ tiếng Anh khi gõ
  sai" trở lại full bề rộng cột; nút "Từ điển EN..." chuyển xuống HÀNG NÚT
  dưới như Linux (B9 + quy tắc mới trong ui-spec §1).

### Changed — UI thống nhất 3 nền tảng (yêu cầu chủ repo: "buộc phải giống nhau")
- macOS: nhãn khớp từng chữ với Windows/Linux ("Khôi phục từ tiếng Anh khi
  gõ sai", "Gõ tắt cả khi tắt tiếng Việt", "Gõ tắt...", "Từ điển EN..."),
  cùng thứ tự tuỳ chọn; thêm toggle "Bật gõ tiếng Việt" (đọc/ghi trạng thái
  toàn cục trong AppDelegate — cùng nguồn với menu bar); nút "Từ điển EN..."
  cạnh "Gõ tắt...".
- Icon: macOS menu bar đổi tint V/E sang `systemPink`/`systemBlue` khớp hệ màu
  badge V(#C2185B)/E(#0288D1) của Windows/Linux (ui-spec §7 mới).
- Test `labels_match_linux_settings_panel` mở rộng: đối chiếu nhãn
  Windows ↔ Linux ↔ macOS (include SettingsView.swift) — CI chặn nếu lệch.

### Tests
- 20 bước preflight (thêm `ascii-ps1`); 359+ test toàn workspace.

## [0.2.13] — 2026-10-03

Bản hoàn thiện đa nền tảng cho tính năng tự xác định EN/VI (theo yêu cầu
"đã hoàn thiện cho cả Linux và macOS chưa").

### Added
- **"Từ điển EN..." trên macOS và Linux** (parity với Windows từ 0.2.9):
  - macOS: Settings → "Từ điển EN..." — sheet quản lý danh sách như bảng gõ tắt.
  - Linux: cửa sổ Cài đặt → nút "Từ điển EN..." — cửa sổ soạn thảo như "Gõ tắt...".
  - FFI mới `ime_settings_english_words_text` / `ime_settings_set_english_words_text`
    (dùng chung quy tắc chuẩn hoá trim/lowercase/ASCII/dedupe của cả 3 nền tảng),
    có test round-trip + kiểm tra header tự động.
- **CI phủ Linux adapter**: `replay corpus/shared --adapter linux` được thêm vào
  job replay (trước đây chỉ headless/tsf/mac) + vào `cargo xtask preflight`
  (19 bước) — các case EN-detect giờ regression-test cả nền tảng Linux.

### Fixed
- **macOS xoá `english_words` mỗi lần lưu config**: `ConfigModel.swift` thiếu
  trường này nên `store.persist()` ghi lại config sẽ vứt bỏ danh sách từ của
  người dùng (bắt khi đồng bộ 0.2.13). Đã thêm vào model + decode.

### Documented
- `docs/release/parity-checklist.md`: hàng "Từ điển EN" ✓ cả 3 nền tảng + vị
  trí UI từng nơi; bỏ `english_words` khỏi mục "chưa có trên UI".
- `installer/windows/tests/test-portable.ps1`: ghi chú B7 trung thực — CI chạy
  elevated nên kịch bản portable KHÔNG chứng minh được typing với đăng ký
  thuần per-user; Windows 11 24H2+ nên dùng bộ cài phạm vi máy.
- `docs/user-guide.md`: vị trí "Từ điển EN..." trên từng nền tảng.

## [0.2.12] — 2026-10-03

### Fixed (Windows)
- **Bộ cài nâng cấp không còn lỗi "DeleteFile failed; code 5"** khi
  `textvn-tsf.dll` đang được TSF nạp trong tiến trình (explorer/Notepad…):
  installer đổi tên DLL cũ thành `textvn-tsf.dll.old-<thời-gian>` trước khi
  ghi file mới (`PrepareToInstall` → `RenameLockedTsfDll`; Windows cho phép
  rename file đang map dù không cho xoá) + `[UninstallDelete]` dọn file `.old-*`.
- **TextVN không còn biến mất khỏi danh sách Win+Space**: `register` ghi profile
  vào **store ngôn ngữ hiện đại** (`HKCU\Control Panel\International\User
  Profile\<tag>`) + broadcast `WM_SETTINGCHANGE("International")` — nguyên
  nhân gốc vụ "không chọn được TextVN để gõ" sau các chu kỳ unregister/register
  (bắt thật máy chủ repo 2026-10-03).
- **Chẩn đoán activate trung thực**: `textvn-cli activate` kiểm tra profile
  ĐANG CHỌN (`GetActiveLanguageProfile`) thay vì chỉ "được phép dùng"; thử ma
  trận VI/EN × cờ; thông báo lỗi nêu đúng việc cần làm (chọn bằng Win+Space
  hoặc cài phạm vi máy).
- Tài liệu: `docs/user-guide.md` + `HUONG_DAN_SU_DUNG.txt` ghi rõ **giới hạn
  per-user trên Windows mới** (một số build 10/11 từ chối ActivateProfile cho
  đăng ký chỉ-HKCU → bản portable đơn thuần có thể gõ được sau khi chọn bằng
  Win+Space, còn muốn cắm-là-chạy nên dùng bộ cài phạm vi máy). CI luôn test
  luồng /ALLUSERS; kịch bản per-user chỉ kiểm tra file/trạng thái đăng ký.

### Known issue (ghi nhận từ máy chủ repo, 0.2.12 chưa xử lý được)
- `ActivateProfile` trả `E_FAIL` cho TIP chỉ đăng ký per-user trên Windows
  build 26300 (24H2+/Insider): không thể chuyển bộ gõ bằng API — phải chọn
  thủ công lần đầu (Win+Space) hoặc dùng bộ cài phạm vi máy. Theo dõi ở
  `docs/specs/win-test-common-errors.md` (B7).

## [0.2.11] — 2026-10-03

### Fixed
- `textvn-cli activate` (đường toggle của tray) **check-then-activate**:
  profile đang bật mà blind-call `ActivateProfile` trả E_FAIL (0x80004005)
  trên một số build Windows (bắt thật trên máy chủ repo) → giờ kiểm tra
  enabled trước, đã active = exit 0; sau lỗi còn verify lại một lần nữa.
- **Quy trình**: publish job thêm thông báo lỗi RÕ khi `RELEASE_REPORT.json`
  lệch tag/version — sự cố tag v0.2.11 đầu tiên bị push mà không bump version
  khiến publish fail im lặng (jq -e không in gì); R4 ghi vào
  `docs/release/release-process.md`.

## [0.2.10] — 2026-10-03

Bản vá theo phản hồi trực tiếp của chủ repo trên 0.2.9.

### Fixed
- **"Đã chuyển sang tiếng Anh mà vẫn gõ tiếng Việt"**: khi bấm Ctrl+Shift
  TRONG KHI bộ gõ active trong app là bàn phím khác (Microsoft Việt / US
  trong Win+Space), trước đây chỉ đổi mode + icon của TextVN — thứ người
  dùng gõ vẫn do bàn phím cũ quyết định. Giờ mỗi lần toggle bằng hotkey,
  tray chạy `textvn-cli activate` kích hoạt **profile TextVN cho phiên**:
  mode đổi → bộ gõ đổi → chữ gõ ra theo icon ngay lập tức (đúng nghĩa
  chuyển mode của UniKey).
- **State tray ↔ TIP không còn diverge**: toggle từ TIP gửi giá trị tính từ
  state cục bộ — nếu lệch với tray (bấm đôi trong 250ms, tray restart…)
  thì giá trị sai có thể "kẹt" mãi. Tray giờ trả **snapshot state chuẩn**
  cho lệnh toggle (kể cả khi bị debounce bỏ qua) và TIP nhận lại; thêm
  debounce 250ms phía TIP khớp cửa sổ phía tray.
- **Nâng cấp app mới không còn bị app cũ ảnh hưởng** (báo cáo lớn nhất):
  đổi phiên bản (ghi nhãn `last_version` trong `state.json`) kích hoạt
  migration lúc khởi động — reset mọi tuỳ chọn về mặc định, xoá per-app
  overrides, bật lại tiếng Việt, **unregister + register lại TSF** rửa sạch
  key của phiên bản cũ. GIỮ nội dung người dùng: **từ điển EN tự thêm**
  (`english_words`), gõ tắt (`macros`), emoji. Lần chạy đầu (chưa có nhãn)
  không reset gì.

### Documented
- `docs/release/store-submission.md` §6 viết lại: Partner Center giờ chỉ
  nhận gói **`.exe` / `.msi`** (không còn MSIX cho loại submission này);
  chứng thư đến từ luồng chứng nhận của Store, cert riêng (SignPath /
  mua) chỉ là tuỳ chọn cho phân phối trực tiếp.

### Tests
- Tray: `version_change_migrates_and_preserves_user_content`,
  `same_version_does_not_migrate` (3×); `toggle_global_responds_with_
  authoritative_snapshot`. TSF: `hotkey_toggle_claim_debounces` (3×).

## [0.2.9] — 2026-10-02

Bản chốt: người dùng tự mở rộng từ điển, quy tắc ưu tiên ngôn ngữ công khai,
kiểm soát release chặt hơn. Tiếp 0.2.8.

### Added
- **"Từ điển EN..." trong Bảng điều khiển**: thêm/xoá từ tiếng Anh cá nhân
  (`config.english_words`) bằng UI — từ trong danh sách thắng cả lớp bảo vệ
  âm tiết Việt thông dụng (quyết định tường minh). Editor cửa sổ riêng, DPI
  đa màn hình như bảng chính; lưu ngay → TSF reload hot.
- `cargo xtask preflight` (+ alias `cargo xtask`): **17 gate mirror CI** chạy
  một lệnh, fail-fast, exit code thật — Checklist A0 mới trong
  `docs/release/release-process.md`; bảng "bước → validate gì → sự cố thật"
  và 3 sự cố mới (R1 pipe che exit code, R2 baseline chết theo runner,
  R3 alias xtask).

### Documented
- **[language-detection.md](docs/specs/language-detection.md)**: ma trận xung
  đột ngôn ngữ đầy đủ — thứ tự ưu tiên mỗi phím (secure → chord → macro →
  mode → gợi ý → restore → Escape), nguyên tắc "mode đang bật thắng cặp mơ
  hồ", cách đổi ý từng trường hợp.
- README: mục "Điểm vượt trội so với các bộ gõ khác" (12 dòng so sánh có
  cơ sở với UniKey/EVKey/OpenKey).
- `docs/release/store-submission.md`: quy trình publish Store từng bước
  (reserv name → submission → certification) + 2 phương án tích hợp chứng
  thư số (SignPath Foundation hoặc mua riêng) và checklist sau khi ký.

### Tests
- Engine: ưu tiên user-dictionary thắng vn_common; `auto_restore_english=false`
  giữ fold kiểu UniKey. Tray: `normalize_word_list` (trim/lowercase/comment,
  khử trùng lặp, rỗng). UI smoke ×3: mở editor, mở lại vẫn 1 cửa sổ, Lưu ghi
  đúng `english_words` vào config và broadcast reload.

## [0.2.8] — 2026-10-02

Bản tính năng: xác định ngôn ngữ khi gõ, đa màn hình DPI, chuẩn bị nộp
Microsoft Store. Thông tin phát triển đổi thành **LinhBH.CoM**.

### Added
- **Tự xác định tiếng Anh / tiếng Việt** (báo cáo: "gõ tiếng Việt xong rồi gõ
  tiếng Anh bên cạnh thì sai"): từ điển EN thông dụng dựng sẵn
  (`data/en_common.txt`) chốt ở ranh giới từ — Space trả lại đúng từ EN thay
  vì fold kiểu `text`→`tẽt`, `is`→`í`, `saw`→`să`, `water`→`watẻ`… Cặp mơ hồ
  hai chiều (`cow` = cách gõ Telex của `cơ`, `sex`→`sẽ`, `queen`→`quên`…) ưu
  tiên tiếng Việt qua lưới `data/vn_common.txt` — đúng hành vi UniKey. Tắt:
  `auto_restore_english=false`.
- **Tab gợi ý hoàn tất từ EN**: từ đang gõ đã biến đổi và là tiền tố của một
  từ EN thông dụng → Tab hoàn tất thành từ đầy đủ (macro vẫn ưu tiên; từ
  chưa biến đổi nào Tab đi qua như cũ).
- **Ctrl+Z / Escape khi gõ sai**: Escape là restore thủ công sẵn có từ trước
  (giờ có case corpus riêng); Ctrl+Z vẫn là undo của ứng dụng (TextVN phát
  text thường nên undo app hoạt động tự nhiên).
- Hỗ trợ **cài im lặng cho Microsoft Store**: `PrivilegesRequiredOverridesAllowed`
  trong bộ cài Inno Setup — `/CURRENTUSER` giờ là cờ thật (không cần UAC);
  hướng dẫn nộp Store: `docs/release/store-submission.md`; CI đã chạy cả hai
  kịch bản silent (per-user + machine) từ trước.
- `PRIVACY_POLICY.txt` ở gốc repo (song ngữ EN/VI) — link cho phần khai báo
  Store, chủ repo tự cập nhật khi có thay đổi.

### Fixed
- **Dialog DPI đa màn hình**: kéo Bảng điều khiển (và cửa sổ Gõ tắt) sang màn
  hình có DPI khác giờ tự resize + re-layout + tạo lại font (`WM_DPICHANGED`
  — trước đây kích thước giữ nguyên như màn cũ → tràn/sai lệch).

### Changed
- Thông tin phát triển / publisher / CompanyName / copyright hiển thị:
  `hunglinhpt` → **`LinhBH.CoM`** (URL repo `github.com/hunglinhpt/TextVN`
  và ID `io.github.hunglinhpt.textvn` giữ nguyên).

## [0.2.7] — 2026-10-02

Bản vá theo báo cáo **Ctrl+Shift trên bản 0.2.5/0.2.6 không đổi được mode và
icon khay**.

### Fixed (Windows)
- **Ctrl+Shift hoạt động toàn cục như UniKey**: trước đây toggle chỉ xử lý
  trong TIP — khi TextVN không phải bộ gó active (user đứng ở bàn phím
  US/Microsoft Việt trong danh sách Win+Space) thì không có gì nhận tổ hợp.
  Tray giờ cài `WH_KEYBOARD_LL` **chỉ quan sát** (không ăn phím, không inject —
  mọi event đi tiếp qua `CallNextHookEx`) để dò Ctrl+Shift tap ở mọi app, đồng
  bộ icon `[V]`/`[E]` tức thì.
- **Chống toggle đôi (E11)**: một lần bấm tới tray qua hai đường (LL hook +
  TIP in-process) — `try_claim_global_toggle()` khoá cửa sổ 250ms chéo nguồn,
  nguồn sau chỉ nhận Ack + broadcast state hiện tại; cả hai nguồn tính cùng
  giá trị từ cùng state nền nên không lệch.

## [0.2.6] — 2026-10-02

Bản vá khẩn sau báo cáo **"không gõ được tiếng Việt (kể cả admin) + danh sách
bàn phím quá nhiều layout"** trên bản 0.2.5.

### Fixed (Windows)
- **Ghost registration — nguyên nhân thật của "không gõ được"**: COM
  `InprocServer32` trỏ vào thư mục portable **đã bị xoá** → TSF không nạp được
  TIP, admin cũng không cứu được (HKCU override HKLM). Chạy lại `TextVN.exe`
  từ thư mục portable **còn tồn tại** sẽ tự sửa COM sang đường dẫn mới
  (`tsf_registration_is_current` → register lại); `register status`/`doctor`
  báo `FILE MISSING` đúng chỗ.
- **Danh sách bàn phím — giữ nguyên VI + EN (thiết kế đúng)**: hai lần thử
  thay đổi trong 0.2.6-dev đều vỡ: (a) gỡ layout trước khi thêm lại làm
  Windows deactivate TIP cho phiên → gõ raw; (b) bỏ layout EN mặc định làm
  app có ngôn ngữ nhập en-US không còn nhận TextVN → gõ raw. Cả hai đã revert
  và chốt comment tại chỗ; Win+Space hiển thị 4 layout (US · VI Microsoft ·
  VI TextVN · EN TextVN) là **thiết kế**: profile EN cần cho ngữ cảnh nhập
  tiếng Anh, có thể tự ẩn bớt trong Settings → Typing nếu muốn.

## [0.2.5] — 2026-10-02

Bản vá cho **bản portable** — ba fix của 0.2.4 vận hành đủ trên bản cài nhưng
còn lỗ trên portable (đã repro thật trên máy không admin). Kèm pipeline ký số
SignPath (opt-in).

### Fixed (portable)
- **Gạch chân không tắt được trên portable**: `InstallLayoutOrTip` viết lại cây
  CTF per-user và **xoá mất toàn bộ key `Category`** ghi trước nó (repro:
  sau đăng ký chỉ còn `LanguageProfile`) — category display-attribute provider
  biến mất nên app vẫn vẽ gạch chân. Nay `RegisterCategory` qua API được thử
  **độc lập** với `RegisterProfile` (TSF thường chấp nhận non-admin), và khi
  API thất bại, category HKCU được ghi **SAU `InstallLayoutOrTip`** — verified
  live: cả 4 category (kèm `{046B8C80-…}`) sống sót sau ILOT trên tài khoản
  thường.
- Ctrl+Shift + đăng ký: dùng chung code đã sửa ở 0.2.4 (không phân biệt
  installer/portable) — test live lại trên bản portable: `register` exit 0,
  `register status` OK, không admin.

### Added
- **Pipeline ký số SignPath** (opt-in qua secrets `SIGNPATH_*`): có secret →
  binary + installer được ký tự động khi build release; không secret → giữ
  nguyên release-candidate chưa ký. Kế hoạch + so sánh các đường free
  (SignPath Foundation / Azure Artifact Signing / SSL.com / Certum):
  [docs/release/code-signing-plan.md](docs/release/code-signing-plan.md).

## [0.2.4] — 2026-10-01

Bản **release candidate chưa ký số**. Trọng tâm: bộ gõ TSF phải đăng ký và gõ
được trong bản cài Windows, đồng thời không để lại override COM hỏng khi UAC
dùng tài khoản quản trị khác. CI kiểm thử cài/gõ thật/gỡ trên Windows, IBus và
Fcitx5 trên Linux, Swift hai kiến trúc và đóng gói trên macOS.

### Fixed
- **Đăng ký TSF không cần quyền Administrator**: Sửa hậu kiểm `registration_ok()` trong `textvn-cli`
  để chấp nhận profile HKCU `Enable = 1` (ghi bởi `register_ctf_per_user` và `InstallLayoutOrTip`),
  thay vì chỉ dựa vào `IsEnabledLanguageProfile` (vốn đọc HKLM). Đăng ký đầy đủ category
  `GUID_TFCAT_DISPLAYATTRIBUTEPROVIDER` (GUID thật `{046B8C80-…}` — bản trước ghi sai `{2464BEB0-…}`
  làm fallback per-user đăng ký category rác, TSF không bao giờ nhận diện provider). Giờ đây người dùng
  chạy bản portable hoặc tài khoản tiêu chuẩn không bị báo lỗi `FAIL: hậu kiểm đăng ký TSF không đạt`
  và không bị ép chạy Administrator.
- **Tắt hoàn toàn gạch chân chữ đang gõ (Clean composition không gạch chân)** trên cả 3 hệ điều hành:
  - *Windows TSF*: Triển khai `ITfDisplayAttributeProvider`, `ITfDisplayAttributeInfo`, trả về `TF_LS_NONE`
    (không vẽ gạch chân) và gán `DISPATTR_TEXTVN` lên dải composition trong `edit_session.rs`.
  - *Linux IBus*: Loại bỏ thuộc tính `IBUS_ATTR_TYPE_UNDERLINE` trong `engine.c`.
  - *Linux Fcitx5*: Đổi cờ định dạng preedit sang `fcitx::TextFormatFlag::NoFlag` trong `engine.cpp`.
  - *macOS IMK*: Truyền `NSAttributedString` với `.underlineStyle = 0` (`NSUnderlineStyle([])`)
    thay vì chuỗi trần sang `client.setMarkedText()` trong `IMKTextTarget.swift`.
- **Sửa lỗi không đổi icon và không chuyển mode gõ khi bấm Ctrl + Shift** trên cả 3 hệ điều hành:
  - *Windows*: Tự động giải phóng `Ctrl+Shift` khỏi `HKCU\Keyboard Layout\Toggle` của hệ thống khi `TextVN.exe`
    khởi động. Tổ hợp được nhận diện **in-process trong TIP** (`ModifierToggle` + `KeyTraceSink`) — một bản
    0.2.4-dev từng cài thêm `WH_KEYBOARD_LL` trong tray khiến **một lần bấm bị toggle đôi** (TSF + hook cùng
    bắn → bấm không đổi mode/icon) và vi phạm chính sách AV A2/A3 (hook LL chỉ thuộc gói compatibility
    opt-in); hook đã bị xoá, tray nhận kết quả qua IPC để đổi icon `[V]`/`[E]` tức thì.
  - *Installer*: cài **per-user** (mặc định, không UAC) từng luôn báo "Windows từ chối đăng ký" vì chạy
    `register --scope machine` không elevation — nay nhánh per-user đăng ký per-user đúng phạm vi
    (CI `test-installer.ps1` kiểm cả 2 kịch bản `/ALLUSERS` và per-user).
  - *macOS*: Thêm bộ theo dõi trạng thái `flagsChanged` trong `TextVNInputController.swift` để nhận diện
    tổ hợp `Ctrl + Shift` tap mà không kèm phím khác; gửi IPC `ToggleViEn` sang menu bar app `TextVN.app`;
    cập nhật nút thanh menu bar hiển thị rõ chỉ báo chế độ `[V]` / `[E]`.
  - *Linux*: Triển khai `subModeIconImpl` trong Fcitx5 engine để icon khay hệ thống và submode panel
    tự động chuyển đổi mượt mà giữa `textvn_v` và `textvn_e`; đảm bảo IBus cập nhật property icon khi toggle.
- Installer Windows đăng ký COM/profile TSF ở phạm vi máy, sau đó thêm layout
  và kích hoạt trong phiên của người dùng gốc. Dọn override HKCU cũ thay vì
  tạo override mới trỏ DLL có thể bị xoá khi gỡ.
- VNI không nuốt phím `0` khi không có dấu để xoá; gõ tắt theo phím gốc hoạt
  động sau khi Telex đã biến đổi chữ hiển thị.
- IPC tray giới hạn hàng đợi/worker cho subscriber chậm; đọc frame thiếu dữ
  liệu có timeout. Sửa các nhánh `cfg` khiến Linux/macOS không biên dịch.
- EventTap macOS thoát được khi dừng sát thời điểm khởi động run loop; dùng
  API `CFRunLoopMode.defaultMode` tương thích SDK Swift hiện tại.

### Verification
- CI `ci-shared` và `ci-macos` xanh trên commit sửa code; job perf trên runner
  dùng chung chỉ là cảnh báo, không chặn release.
- Chưa có Authenticode, Developer ID/notarization, hoặc GUI smoke trên máy Mac
  thật; không gắn nhãn production.

## [0.2.3] — 2026-10-01

Bản phát hành sau 2 vòng audit chuyên sâu toàn repo (code Rust, GitHub Actions,
icon/packaging — từng dòng). **Chủ đề: icon đủ trên cả 3 nền tảng** — macOS
trước đây không có icon bundle nào (pipeline sinh .icns tồn tại sẵn nhưng thiếu
file PNG nguồn nên âm thầm tắt từ trước đến nay). Vẫn **release candidate,
chưa ký số**.

### Added
- **Icon cho macOS (đủ như Windows)**: `packaging/macos/icons/TextVN-1024.png`
  (+512) — render từ thiết kế badge `resources/icons/textvn_v.svg` bằng script
  mới `scripts/generate_app_icons.py`; `build-macos.sh` sinh `TextVN.icns` vào
  cả `TextVN-IM.app` và `TextVN.app` (Input Sources, Finder/Spotlight hết icon
  trắng mặc định); `Info-IM.plist` thêm `tsInputMethodIconFileKey` để input
  menu trên menu bar có icon.
- **Icon raster Linux cho panel cũ**: `resources/icons/textvn_v.png` /
  `textvn_e.png` 128px cài kèm SVG vào hicolor (`install.sh`, stage, manifest
  uninstall đều cập nhật); AppStream metainfo thêm `<icon type="stock">` —
  Software Center hiển thị icon thay vì ô trống.
- **Icon portable Linux**: bản chạy ngay (`textvn-portable.sh`) stage hicolor
  icons vào `$XDG_RUNTIME_DIR` + truyền `XDG_DATA_DIRS` cho daemon — engine
  panel (IBus/Fcitx5) và cửa sổ cài đặt resolve được `textvn_v` thay vì icon
  mặc định (GNOME Shell tự vẽ panel theo session — giới hạn đã ghi trong script).
- `scripts/generate_app_icons.py`: một nguồn sinh mọi PNG icon từ SVG brand
  (chạy bằng tay, PNG commit sẵn — CI không cần Pillow).

### Fixed (Windows)
- **Cửa sổ Bảng điều khiển + Gõ tắt có icon title bar/Alt-Tab** (trước đây
  dùng icon Windows mặc định): `tray.rc` nhúng icon trung tính ID 3, class
  đăng ký `hIcon`; loader `load_app_icon` tách thành module dùng chung
  `tray/src/icons.rs` (G15 — một bản cho tray và cửa sổ).
- **Installer có icon riêng** (`SetupIconFile`) thay vì icon mặc định Inno Setup.

### Fixed (đăng ký TSF — audit vòng sâu, 3 major)
- **Lỗi thiếu DLL giờ vào `register.log`**: trước đây `resolve_dll_path` fail
  chỉ in stderr (console ẩn nuốt mất) → hộp thoại tray đọc đuôi log của run
  CŨ và ghép advice sai nguyên nhân. Nay ghi header run mới + lỗi vào log
  trước khi thoát.
- **Windows Single Language không còn bị chặn đăng ký**: profile EN (0x0409)
  chuyển thành best-effort (WARN) — trước đây ILOT/hậu kiểm fail cứng trên EN
  khiến toàn bộ đăng ký báo FAIL dù VI hoạt động đầy đủ. Hậu kiểm bắt buộc VI.
- **Đăng ký `--scope machine` dọn override per-user**: key HKCU CLSID cũ (trỏ
  DLL portable đã xoá) che HKLM mới ở mức COM — xoá trước khi ghi machine;
  hậu kiểm `server_ok` dò cả 2 hive thay vì HKCU-first tuyệt đối.
- `unregister` báo thất bại (exit 1) khi còn key không xoá được; scope machine
  xoá thêm cây CTF TIP HKLM; `Enable=1` ghi lại SAU `InstallLayoutOrTip` (spike
  doc: cập nhật input list có thể reset enabled flag); `FreeLibrary` input.dll
  sau mỗi lần gọi; `doctor` tìm `data/` cạnh exe thay vì chỉ cwd; cửa sổ sửa
  Gõ tắt không còn đóng giả thành công khi không lấy được trạng thái ứng dụng
  (bảng vừa sửa bị vứt im lặng); FFI dùng hằng `IME_FIELD_SECURE` thay số ma
  thuật `10` + ghi contract pointer `ime_last_error`.

### Changed (CI — audit GitHub Actions, 5 major)
- `ci-shared.yml`: thêm `permissions: contents: read` (mọi job token chỉ đọc);
  `cancel-in-progress` chỉ trên PR (push graphify/docs sau commit code từng
  giết run CI của commit code); bỏ qua push chỉ chứa `**.md`/`docs/`/
  `graphify-out/`; **timeout-minutes cho 12/13 job** (mặc định 360′ là lãng phí
  khi cargo hang); **Swatinem/rust-cache** cho các job nặng (test/replay/clippy/
  fuzz/linux-adapters/windows-package); `persist-credentials: false` ở checkout.
- `release.yml`: **publish draft-first** — tạo draft, upload hết asset
  (`--clobber`, rerun được) rồi mới public; jq assert thêm
  `feature_profile == "tsf-only"`; job `publish` có timeout; job macOS chạy
  `swift test` TRƯỚC khi đóng gói.
- `ci-macos.yml`: bỏ `needs: engine-static` vô ích ở job swift (tự build
  staticlib per-arch) + timeout 60′; `repo-hygiene` có timeout + token chỉ đọc;
  `targets-verify` chỉ tải installer từ hostname allowlist.

### Housekeeping
- Quy trình phát hành chuẩn hoá: **`docs/release/release-process.md`** (G16
  trong `00-WORKFLOW.md`) — Checklist A (local) → Checklist B (repo/docs) bắt
  buộc cho mọi agent/contributor, dựa trên v0.2.0–v0.2.2 đã phát hành thành
  công; bảng sự cố khi phát hành (typing smoke flake B5, perf continue-on-error,
  publish draft rerun…).

## [0.2.2] — 2026-09-30

Bản vá nghiêm túc cho bản 0.2.1: **ưu tiên cao nhất** là F3-13 — khi TextVN tự
khởi động theo login item trên macOS, cửa sổ **Cài đặt không còn tự bật lên**
nữa. Gói vẫn chưa ký số, chưa có smoke GUI trên máy Mac thật nên **không phải
production**.

### Fixed (macOS — ưu tiên bản này)
- **F3-13 · login launch không mở Cài đặt**: `SMAppService` **không** truyền
  `--autostart` vào argv, nên cờ mở dialog trước đây hiểu nhầm là khởi động thủ
  công. Thêm `AutostartManager.isAutostartConfigured()` coi cả trạng thái
  `.requiresApproval` là “đã đăng ký”, cộng `config.autostart`; `NSLog` ghi rõ
  `settings/loginLaunch/showDialogOnStartup` để chẩn đoán. Trade-off đã ghi trong
  review log: mở tay sau khi bật autostart cũng không tự mở Settings.
- **F3-6 · fallback LaunchAgent thật sự hoạt động**: trước đây `setAutostart(true)`
  coi là xong khi `SMAppService.register()` trả về mà status vẫn `.requiresApproval`,
  khiến plist fallback không bao giờ được ghi → bật autostart rồi restart là mất.
  Nay đo lại `status == .enabled`, chỉ ghi plist khi SM **không** nhận.
- **F3-8 · menu bar theo `ui-spec`**: icon là SF Symbol **template** (tự đổi màu
  sáng/tối, badge `error` màu cam khi IMK crash), submenu **Dấu** đầy đủ, mục
  **Bật tiếng Việt cho {app}** đọc app foreground gần nhất, mỗi mục có đánh dấu
  trạng thái riêng, và **Sức khoẻ** in PID tiến trình IMK + tuổi heartbeat.
- **Nit F3-15/16/17/18/19/20/21**: vòng quan sát workspace được huỷ khi terminate
  (hết retain cycle), hotkey `Ctrl+Shift+Space` so **mask** nên vẫn toggle khi
  Caps Lock bật, `IMKApp` huỷ observer khi thoát, Secure Input tính lại **trước**
  khi nuốt `keyDown`, `Diagnostics` đọc Int đúng kiểu và có fallback,
  `KeyTranslator` dùng mask modifier, `setAutostart` không gọi hai lần, bỏ nhánh
  `SettingsController` chết.
- `applyReplace` escape XML đường dẫn LaunchAgent; `IpcClient` ghi log chẩn đoán
  khi socket lỗi; `ipcServer(_:didChangeEnabled:)` phát `ConfigReload` để IMK
  nạp lại `config.enabled` (trước đó bật/tắt ở menu không tới IMK).

### Fixed (Windows)
- **Thông báo lỗi attachment sai**: danh sách dò DLL trong `textvn register` lặp
  `textvn-tsf.dll` hai lần và câu lỗi ghi “(hoặc `textvn-tsf.dll`)” — tức **tên
  đúng** `textvn_win_tsf.dll` mà gói phát hành mang lại không bao giờ hiện ra
  đúng ở phần giải thích. Bỏ trùng lặp, sửa câu lỗi, và hộp thoại “Cài & bật TSF”
  giờ hiện **lý do thật** lấy từ đuôi `register.log` kèm gợi ý đúng nguyên nhân
  (thiếu quyền Administrator / `ACCESS_DENIED` khi ghi HKCU / thiếu DLL cạnh
  `textvn-cli.exe`) thay vì luôn đổ lỗi cho ACL.
- **Gợi ý lỗi đăng ký khớp log thật (triệt để hóa đợt trên)**: log CLI in lỗi
  registry chỉ dạng hex `FAIL 0x00000005` không kèm tên ký hiệu, nên nhánh gợi ý
  `ACCESS_DENIED` trong hộp thoại là **dead code** — lỗi ACL thật (sandbox, AV,
  policy chặn ghi `HKCU\Software\Classes\CLSID`) vẫn luôn nhận gợi ý generic.
  Nay mỗi dòng log registry mang đủ ngữ cảnh
  `Registry create HKCU\…\CLSID → FAIL 0x00000005 (ERROR_ACCESS_DENIED)`, dòng
  FAIL nêu đúng khoá bị chặn, và hộp thoại khớp **cả hai** định dạng log (bản
  mới có tên ký hiệu, bản 0.2.0/0.2.1 đã cài chỉ có hex). Test mới
  `lstatus_name_covers_acl_and_common_registry_errors`; `advice_matches_real_cause`
  được mở rộng với đúng chuỗi log thật thay vì chuỗi mô phỏng.

### Fixed (macOS — tiếp)
- `EventTapController.start()` là idempotent (gọi hai lần không rò tap/thread) và
  `stop()` chặn race với thread chưa gắn runloop; app foreground đọc từ **cache**
  cập nhật qua notification thay vì gọi `NSWorkspace.frontmostApplication` — vốn là
  XPC từ khoá 2ms trong callback event tap.

### Changed
- Job `perf regression` trên CI vẫn `continue-on-error` (runner dùng chung, số đo
  nhiễu). Đo trên máy local: `ime_key` p50 687 → **500 ns (−27,2%)**,
  `parse_config` 781 → 768 ns (−1,7%) — **không có hồi quy**; xem
  [báo cáo build](docs/release/build-release-report.md).

### Housekeeping
- Dọn file temp của phiên làm việc, `.gitignore` thêm `/build/` và `.vscode/`
  (artifact CMake và cấu hình IDE máy-locale trước đó lọt vào untracked).

## [0.2.1] — 2026-09-30

Release candidate bảo trì: macOS không tự bật Settings ở phiên login qua
`SMAppService`; đường dẫn LaunchAgent được XML-escape; mặc định khởi động cùng
macOS là opt-in và UI “Đặt dấu tự do” ghi đúng khoá. Windows `-BuildInstaller`
giờ dừng nếu không tìm thấy Inno Setup và không ghi đè ZIP đã tồn tại.
Gói chưa ký số và chưa có smoke GUI trên macOS nên **không phải production**.

## [0.2.0] — 2026-09-30

Mục tiêu: bản release candidate dùng được hằng ngày trên Windows, Linux và macOS (Farch-4). Kết quả kiểm thử:
[docs/release/build-release-report.md](docs/release/build-release-report.md).

### Added
- **Linux chạy được thật**: adapter IBus và Fcitx5 dựng, nạp và gõ được tiếng Việt (kiểm
  bằng ibus-daemon 1.5.29 và fcitx5 5.1.7 thật — `scripts/e2e-linux.sh`, job CI `linux-adapters`).
- **Gói Linux** `TextVN-<ver>-linux-<arch>.tar.gz`: `./install.sh` (per-user mặc định, `--system`)
  tự thêm TextVN vào danh sách bộ gõ GNOME/IBus/Fcitx5; `./textvn-portable.sh` chạy ngay từ
  thư mục giải nén (kể cả chỉ đọc); `uninstall.sh` gỡ đúng file đã cài (`--purge` xoá cấu hình).
- **Bảng điều khiển thống nhất** Windows (Win32), Linux (GTK4), macOS (SwiftUI): cùng tuỳ chọn, nhãn, bố cục
  ([ui-spec](docs/release/ui-spec.md)); trình sửa **Gõ tắt** (`gõ tắt = nội dung`, báo lỗi từng dòng).
- Engine: bảng mã xuất **Unicode tổ hợp, TCVN3 (ABC), VNI Windows** (bảng lấy từ UniKey);
  **Quick Telex**; Telex `z` xoá dấu; gõ được khi bật **Caps Lock** (`VIEETJ` → VIỆT) mà vẫn
  giữ nguyên chữ viết tắt gõ bằng Shift (`USA`, `JSON`).
- Trạng thái V/E lưu ở `state.json` trên cả hai nền tảng; phím **Ctrl+Shift** (nhấn-nhả) kiểu
  UniKey trong TSF, IBus, Fcitx5.
- Kiểm thử gói Windows trên máy Windows thật (job CI `windows-package`): `build-release.ps1`,
  kịch bản **cài đặt** (Inno Setup im lặng) và **giải nén dùng ngay** (zip), mỗi kịch bản gõ
  thật qua TSF vào Notepad/WordPad rồi gỡ sạch.
- Kiểm thử từ vựng thật `core/tests/common_words.rs` (~400 từ × Telex/VNI/kiểu cũ/`uow`/giữa
  từ/Caps Lock); corpus 113 kịch bản × 5 adapter.
- `TEXTVN_TSF_TRACE=<file>`: nhật ký chẩn đoán key sink TSF (tắt mặc định, không ghi nội dung gõ).
- Tài liệu: [hướng dẫn sử dụng](docs/user-guide.md), [hướng dẫn phát triển](docs/developer-guide.md),
  [đối chiếu bộ gõ tham chiếu và bug đã biết](docs/specs/reference-parity.md).

### Added (macOS — Farch-4)

- **macOS IMK adapter** (`adapters/macos-imk/`, Swift): `TextVN-IM.app` — IMKServer +
  `TextVNInputController` theo P2-1 (marked text lifecycle, commit-before-hide B13,
  marked ≤8 grapheme B11, SelectionReplace không-backspace B1, fail-open S4)
- **macOS CGEventTap fallback** (`adapters/macos-tap/`, Swift): tap opt-in per-app
  `engine_owner: "tap"`, marker loop-guard `TXVN`, self-disable khi chậm 2ms ×50,
  injector BackspaceType/SelectionReplace (P2-2)
- **Bảng keycode macOS → VK canonical** duy nhất `data/tables/keymap_mac.toml`
  → generate cả Rust (`core/src/keymap_mac_generated.rs`) lẫn Swift
  (`KeyMapMacGenerated.swift`) qua `cargo xtask gen-tables` — 92 phím
- **AppDB preset macOS** 20 mục (`mac.safari.url`…`mac.game.nokbd`, engine_owner
  `imk`/`tap`) trong `data/appdb.default.json`
- **Corpus macOS 114 case** `corpus/mac/` (P2-5 §2: B1/B2/B3/B8/B11/B13/secure/
  owner/imk_preedit 40/mac_bs_type 30/tap 20) — gen bằng `cargo xtask gen-mac-corpus`,
  replay `--adapter mac` pass 114/114 headless mọi OS
- **CI `ci-macos.yml`**: build staticlib 2 arch + lipo, swift build/test cả 2 package,
  replay corpus mac, ABI gates; `ci-shared` replay thêm `--adapter mac`
- Tài liệu: `docs/30-macos/IMPLEMENTATION-STATUS.md` (trạng thái trung thực),
  `docs/30-macos/env-mac.md` (MAC-001)

### Fixed
- Corpus win drift: 14 case trong `xtask/src/win_corpus_cases.rs` lệch với
  `corpus/win/*.keys` đã sửa tay (tổng `tongj`→`toongr`, `rooid`→`roofi`,
  thiếu `auto_capitalize=false`, combo `Esc`→`Escape`…) — `check-win-corpus`
  nay pass và đã vào CI replay
- `cargo xtask` TOML parser hỗ trợ hex `0x…` cho bảng keycode
- **macOS subsystem audit review round 3&4** (F2-029…F2-040):
  - Bọc con trỏ Carbon `UCKeyTranslate` (`UnsafePointer<UCKeyboardLayout>`) qua `layout.withUnsafeBytes`.
  - Dispatch trực tiếp `client.doCommand(by:)` trên `IMKTextInput` thay vì ép kiểu `NSResponder` (tránh fail trên out-of-process XPC session).
  - Khai báo mở rộng `NSRange.notFound` và `String.utf16Count`.
  - Sửa `CGEvent.tapEnable` gọi đúng `CFMachPort` thay vì proxy.
  - Thêm helper `ImeEngine.string(fromUTF32:len:)` trong `CoreBridge`.
  - Đảm bảo an toàn bộ nhớ ARM64 (Apple Silicon) bằng `loadUnaligned` khi giải mã frame IPC.
  - Hủy `retryTimer` khi `IpcClient.tearDown()`, hỗ trợ toggle toàn cục `appID.isEmpty`.
- **macOS CI fix MAC-031** (commit `f10eb1a` — 2026-09-29):
  - `adapters/macos-imk/Package.swift`: thay `URL(fileURLWithPath: #filePath)` bằng
    `String.components(separatedBy:)` thuần — `URL`/`Foundation` không khả dụng trong
    `PackageDescription` scope trên Xcode 26.6 / Swift 6.
  - `adapters/macos-imk/build-rust.sh`: thêm `PKG_DIR`/`ROOT_DIR` tuyệt đối; thay mảng
    `PROFILE=()`/`EMPTY_SAFE` bằng scalar `PROFILE_FLAG=""` — bash 3.2 macOS ném
    `unbound variable` khi expand mảng rỗng dưới `set -u`.
  - `.github/workflows/ci-macos.yml`: matrix `arch: [arm64, x86_64]` → `include` với
    `rust_target: aarch64-apple-darwin`/`x86_64-apple-darwin`; `cargo build` chạy từ
    workspace root; copy FFI header bước riêng.

### Fixed (review vòng 3 — trước tag v0.2.0)

Chi tiết: [P2-REVIEW-LOG — Round 9](docs/30-macos/P2-REVIEW-LOG.md).

- **Installer Windows kẹt 0.1.0** (blocker): `#define MyAppVersion` cứng đè `/DMyAppVersion`
  của script release → nay `#ifndef`; hết version-skew ở manifest Win32, component IBus,
  Hello IPC Linux, cask Homebrew, AppStream. Gate mới `cargo xtask check-version-sync`.
- **macOS**: bật/tắt tiếng Việt từ menu bar nay tới được IMK (quy ước `app_id = "*"` toàn
  cục chung mọi nền tảng); cửa sổ Cài đặt "Mở rộng" không còn bị cắt; TextVN-IM không còn
  có thể chết vì SIGPIPE; sửa `config.json` ngoài app có hiệu lực ngay (hot-reload
  MAC-053); config hỏng được giữ lại `config.json.corrupt-<ts>` thay vì bị ghi đè mất
  macro; IPC server đóng kết nối khi vi phạm giao thức và kiểm uid peer; tắt tự khởi động
  gỡ cả LaunchAgent fallback; gỡ cài đặt sạch cả scope hệ thống, Login Item và receipt pkg.
- **Windows tray**: mục menu "Bật tiếng Việt cho {app}" hoạt động (nhớ app đang gõ trước khi
  click khay); click đầu sau khi đóng menu không bị nuốt; ghi `state.json` lỗi không còn
  phát trạng thái sai; chống 2 instance khi `GetLastError` bị đè; vòng message thoát đúng
  khi `GetMessageW` lỗi.
- **Linux**: `60-textvn.conf` không còn sót sau khi gỡ khi `XDG_CONFIG_HOME` khác mặc định;
  gỡ bản `--system` bỏ TextVN khỏi danh sách bộ gõ; cảnh báo khi Fcitx5 sẽ không nạp addon.
- **CI xanh cả 3 nền tảng lần đầu** (MAC-032): code macOS (IMK, tap, app) nay build + test
  trên Xcode 26.6 cả arm64/x86_64 và đóng gói `.pkg`; sửa kèm lỗi thật lộ ra khi chạy:
  gõ từ dài hơn 8 ký tự ở chế độ preedit không còn mất ký tự thứ 9; tap CGEvent không rò
  bộ nhớ mỗi phím; installer Windows compile được và báo lỗi (exit 10) khi đăng ký TSF
  thất bại; `textvn-portable.sh` không rollback nhầm trên phiên chưa có ô nhập đang focus.

### Added (trước đó)
- **Tray Icon**: Icon TextVN 16/32/48px nhúng qua winresource, manifest DPI PerMonitorV2
- **CLI**: `textvn-cli register` / `textvn-cli unregister` — đăng ký/hủy TSF TIP per-user (WIN-003, WIN-010)
- **CLI**: `textvn-cli register status` — kiểm tra trạng thái đăng ký TSF
- **Windows manifest**: asInvoker (không cần admin), Windows 10/11 compatibility

### Fixed
- **Windows TSF không gõ được tiếng Việt** (`docs/specs/tsf-typing-overhaul.md`, Ftsf-1…14):
  security gate không bao giờ mở; đăng ký per-user dừng trước `InstallLayoutOrTip`; composition
  mở mới mỗi phím; app treo khi Deactivate; hotkey đảo 2 lần; Delete/F-key/mũi tên bị coi là
  chữ; `doctor` kiểm sai CLSID.
- TSF: dấu cách/dấu câu được chốt **cùng** từ; Enter/Tab/phím điều hướng ở ứng dụng Win32
  cổ điển (Notepad, WinForms… qua CUAS) được xử lý ở pha `OnKeyDown` — trước đây các phím này
  ra **trước** chữ (" được", "\nchào").
- TSF: Ctrl+Shift chuyển V/E được cả ở ứng dụng TSF-aware (Word, WordPad): phím chuyển bố cục
  của Windows nuốt Shift trước key sink, nay nhận qua `ITfKeyTraceEventSink`. Báo trạng thái
  tuyệt đối cho tray thay vì "đảo".
- Gỡ bản portable (menu khay hoặc `uninstall.ps1`) bỏ luôn mục tự khởi động trỏ vào thư mục đó.
- Ctrl+Shift "lúc được lúc không" khi ngôn ngữ của TextVN có hơn một bàn phím: phím tắt đổi bố
  cục mặc định của Windows (cũng là Ctrl+Shift) chuyển đi mất TextVN mỗi lần bấm thứ hai. Tuỳ
  chọn **Dành Ctrl + Shift cho TextVN** (bảng điều khiển, bộ cài chọn sẵn, `TextVN.exe
  --free-ctrl-shift`), `doctor` báo khi Windows còn giữ phím này.
- Đặt dấu sai chính tả: `của`→cuả, `nghĩa`→nghiã, `thuỷ`/`thủy` theo kiểu dấu, `được`→đựơc
  (kiểu cũ); dấu tự dời khi gõ thêm chữ (`hòa`+`n` → hoàn).
- `d` + nguyên âm tự thành `đ` (không gõ được dân, dạy, dưới…): `đ` giờ chỉ từ `dd` như
  UniKey/OpenKey/Bamboo. Sửa `gi`+nguyên âm (giữa, giờ), `qu`+ơ, `thuở`, `uow` → ươ.
- Gõ tắt không còn bung sau Home/End/F-key hay tổ hợp Ctrl/Alt (có thể xoá nhầm chỗ).
- Linux: engine reset mỗi lần caret đổi (không biến đổi được chữ nào), mất chữ khi Enter/focus,
  addon Fcitx5 không bao giờ nạp, IBus sai bus name, cấu hình từ bảng điều khiển không được
  đọc, bảng điều khiển ghi đè mất gõ tắt; per-user IBus không hiện sau đăng nhập lại (cache
  registry của ibus-daemon).
- Tray Windows: mất icon khi Explorer khởi động lại; lưu cấu hình làm mất khoá người dùng và
  ghi đè file hỏng; menu **Gỡ cài đặt** cho bản cài lẫn bản portable.
- Installer: thiếu bản dịch tiếng Việt của Inno Setup nên không biên dịch được; cài im lặng
  không còn bật UAC.
- Giảm bề mặt bị phần mềm diệt virus nghi ngờ: không `SendInput` trong gói mặc định,
  `input.dll` chỉ nạp từ System32, không `TerminateProcess`, pipe từ chối client từ xa.

### Changed
- Tra bảng nguyên âm trên đường phím nóng: nhánh ASCII + tìm kiếm nhị phân thay vì duyệt tuyến tính.
- Gói Windows mặc định **TSF-only**; hook tương thích chỉ có trong gói Compatibility (opt-in).

### Known limitations
- macOS: adapter IMK, CGEventTap, Menu Bar App, Settings SwiftUI và kịch bản đóng gói/cài đặt đã hoàn thiện mã nguồn và kiểm thử logic/replay (114/114 case pass); cần máy macOS vật lý để kiểm chứng giao diện đồ họa và cấp chứng chỉ Apple Developer ID.
- Bản dựng CI chưa ký số Authenticode (Windows SmartScreen sẽ cảnh báo lần đầu).

---

## [0.1.0] — 2026-09-27

### Added

#### Core
- Engine gõ tiếng Việt (Telex, VNI, VIQR, Simple Telex)
- Kiểu bỏ dấu: Chuẩn mới (`hoà`, `thuỷ`) và Cổ điển (`hòa`, `thủy`)
- Config schema v1 với JSON parser + validator
- Corpus replay system (golden test suite)

#### Windows Platform
- **TSF TIP** (`textvn-tsf.dll`): Text Input Processor đăng ký với Windows Input Framework
  - `ITfTextInputProcessorEx::Activate/Deactivate`
  - `ITfKeyEventSink`: xử lý phím gõ
  - `ITfEditSession::DoEditSession`: commit text vào ứng dụng
  - Named Pipe IPC client (kết nối tới tray)
- **System Tray** (`textvn-tray.exe`): tray app với 9-item context menu
  - Bật/Tắt tiếng Việt toàn cục
  - Chọn chế độ gõ (Telex/VNI/VIQR/Simple Telex) qua submenu
  - Chọn kiểu bỏ dấu (Chuẩn mới/Cổ điển)
  - Per-app toggle cho ứng dụng đang foreground
  - Game/Compat mode (tắt hook)
  - Health submenu (clients, version)
  - Gỡ cài đặt / Thoát
  - Single-instance mutex (`Local\TextVNTray`)
  - Named Pipe IPC server (`\\.\pipe\textvn-ipc-v1`)
  - Auto-start via HKCU Run key
- **CLI** (`textvn.exe`):
  - `replay` — chạy golden corpus test
  - `verify` — kiểm tra header C vs Rust ABI
  - `sizes` — verify struct layout (20 bytes key, 532 bytes result)
  - `config init/default/validate`
  - `doctor [--json] [--export]` — chẩn đoán môi trường (WIN-058)
  - `register [--scope user] [--dll path]`
  - `unregister`
- **Installer**: Inno Setup 6 script — cài đặt per-user, không cần admin (WIN-054, WIN-055)
- **Low-level Hook** (`textvn-hook.exe`): WH_KEYBOARD_LL hook với 2ms timebox, injection guard

#### Developer Tools
- `textvn doctor --export diag.zip` — xuất báo cáo chẩn đoán (zero-dependency ZIP)
- REUSE compliance (1006+ files)
- Graphify knowledge graph (2389 nodes)
- `docs/specs/tsf-registration-spike.md` — research findings per-user TSF registration

### Architecture
- Named Pipe IPC protocol (textvn-ipc crate)
- `IpcClient` dùng `Mutex<Option<JoinHandle>>` để `stop()` có thể gọi từ `&self`
- `IpcServer::stop()` dùng dummy connect để unblock `ConnectNamedPipe`
- Per-user registration: HKCU + `InstallLayoutOrTip(input.dll)`

---

## Versioning Policy

- **MAJOR** (x.0.0): breaking change ABI, config schema, IPC protocol
- **MINOR** (0.x.0): tính năng mới backward-compatible
- **PATCH** (0.0.x): bug fix, perf, docs, security

Bump version trong `Cargo.toml` (workspace `[workspace.package]`) và tạo Git tag:
```powershell
git tag -a v0.1.0 -m "Release 0.1.0"
git push origin v0.1.0
```

[Unreleased]: https://github.com/hunglinhpt/TextVN/compare/v0.2.32...HEAD
[0.2.36]: https://github.com/hunglinhpt/TextVN/compare/v0.2.35...v0.2.36
[0.2.35]: https://github.com/hunglinhpt/TextVN/compare/v0.2.34...v0.2.35
[0.2.34]: https://github.com/hunglinhpt/TextVN/compare/v0.2.33...v0.2.34
[0.2.33]: https://github.com/hunglinhpt/TextVN/compare/v0.2.32...v0.2.33
[0.2.32]: https://github.com/hunglinhpt/TextVN/compare/v0.2.31...v0.2.32
[0.2.31]: https://github.com/hunglinhpt/TextVN/compare/v0.2.30...v0.2.31
[0.2.30]: https://github.com/hunglinhpt/TextVN/compare/v0.2.29...v0.2.30
[0.2.29]: https://github.com/hunglinhpt/TextVN/compare/v0.2.28...v0.2.29
[0.2.28]: https://github.com/hunglinhpt/TextVN/compare/v0.2.27...v0.2.28
[0.2.27]: https://github.com/hunglinhpt/TextVN/compare/v0.2.26...v0.2.27
[0.2.26]: https://github.com/hunglinhpt/TextVN/compare/v0.2.25...v0.2.26
[0.2.25]: https://github.com/hunglinhpt/TextVN/compare/v0.2.24...v0.2.25
[0.2.24]: https://github.com/hunglinhpt/TextVN/compare/v0.2.23...v0.2.24
[0.2.23]: https://github.com/hunglinhpt/TextVN/compare/v0.2.22...v0.2.23
[0.2.22]: https://github.com/hunglinhpt/TextVN/compare/v0.2.21...v0.2.22
[0.2.21]: https://github.com/hunglinhpt/TextVN/compare/v0.2.20...v0.2.21
[0.2.20]: https://github.com/hunglinhpt/TextVN/compare/v0.2.19...v0.2.20
[0.2.19]: https://github.com/hunglinhpt/TextVN/compare/v0.2.18...v0.2.19
[0.2.18]: https://github.com/hunglinhpt/TextVN/compare/v0.2.17...v0.2.18
[0.2.17]: https://github.com/hunglinhpt/TextVN/compare/v0.2.16...v0.2.17
[0.2.16]: https://github.com/hunglinhpt/TextVN/compare/v0.2.15...v0.2.16
[0.2.15]: https://github.com/hunglinhpt/TextVN/compare/v0.2.14...v0.2.15
[0.2.14]: https://github.com/hunglinhpt/TextVN/compare/v0.2.13...v0.2.14
[0.2.13]: https://github.com/hunglinhpt/TextVN/compare/v0.2.12...v0.2.13
[0.2.12]: https://github.com/hunglinhpt/TextVN/compare/v0.2.11...v0.2.12
[0.2.11]: https://github.com/hunglinhpt/TextVN/compare/v0.2.10...v0.2.11
[0.2.10]: https://github.com/hunglinhpt/TextVN/compare/v0.2.9...v0.2.10
[0.2.9]: https://github.com/hunglinhpt/TextVN/compare/v0.2.8...v0.2.9
[0.2.8]: https://github.com/hunglinhpt/TextVN/compare/v0.2.7...v0.2.8
[0.2.7]: https://github.com/hunglinhpt/TextVN/compare/v0.2.6...v0.2.7
[0.2.6]: https://github.com/hunglinhpt/TextVN/compare/v0.2.5...v0.2.6
[0.2.5]: https://github.com/hunglinhpt/TextVN/compare/v0.2.4...v0.2.5
[0.2.4]: https://github.com/hunglinhpt/TextVN/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/hunglinhpt/TextVN/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/hunglinhpt/TextVN/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/hunglinhpt/TextVN/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/hunglinhpt/TextVN/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/hunglinhpt/TextVN/releases/tag/v0.1.0
