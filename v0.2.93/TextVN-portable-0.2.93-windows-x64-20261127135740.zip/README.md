# TextVN — Bộ gõ tiếng Việt thế hệ mới cho Windows, macOS và Linux

Tiếng Việt · English (mục [English](#english) cuối trang)

[![License: GPL-3.0-or-later](https://img.shields.io/badge/License-GPL--3.0--or--later-blue.svg)](LICENSE)
[![CI Windows](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-windows.yml?branch=main&label=CI%20Windows)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-windows.yml?query=branch%3Amain)
[![CI Linux](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-linux.yml?branch=main&label=CI%20Linux)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-linux.yml?query=branch%3Amain)
[![CI macOS](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-macos.yml?branch=main&label=CI%20macOS)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-macos.yml?query=branch%3Amain)
[![CI engine (3 OS)](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-shared.yml?branch=main&label=CI%20engine%20%283%20OS%29)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-shared.yml?query=branch%3Amain)

[![Tải TextVN trên Microsoft Store](https://get.microsoft.com/images/en-us%20dark.svg)](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)

**TextVN** là bộ gõ tiếng Việt mã nguồn mở thế hệ mới, được xây dựng trên một lõi engine **Rust** duy nhất (an toàn bộ nhớ tuyệt đối, 0 I/O trong engine, không panic qua FFI với `catch_unwind`) dùng chung cho cả ba hệ điều hành: **Windows** (Text Services Framework thuần), **macOS** (Input Method Kit native), và **Linux** (IBus & Fcitx5). TextVN mang lại tốc độ phản hồi micro-giây, độ chính xác ngữ âm tuyệt đối, triệt tiêu hoàn toàn các lỗi kinh điển của bộ gõ hook truyền thống (mất chữ, lặp chữ, gạch chân preedit), đồng thời tích hợp hệ thống dự đoán ngữ cảnh song ngữ và trợ lý ngữ pháp thông minh chạy hoàn toàn offline ngay trên máy người dùng.

---

## 4 Trụ Cột Vượt Trội Cốt Lõi

### 1. Kiến trúc In-Process thuần khiết & An toàn bộ nhớ tuyệt đối
- **Windows TSF thuần (`ITfTextInputProcessorEx`)**: Bản cài mặc định không cài global keyboard hook ăn phím, không tiêm mã DLL vào process khác, không giả lập phím bằng `SendInput` để gửi chuỗi Backspace xoá ngược ([nguyên nhân kiến trúc](docs/specs/antivirus-false-positive.md)).
- **Không mất chữ, không lặp chữ, không gạch chân preedit**: Cả từ nằm trọn vẹn trong vùng soạn thảo nội tại không đường kẻ viền (`TF_LS_NONE` trên Windows TSF; chế độ non-preedit trên macOS; không kềm gạch trên Linux). Triệt tiêu vĩnh viễn lỗi nuốt chữ, lặp chữ khi gõ nhanh trên Google Chrome, Microsoft Edge, ứng dụng Electron (VS Code, Slack, Discord), Microsoft Excel, thanh địa chỉ hay game toàn màn hình.
- **Tránh nhận diện nhầm mã độc (Anti-False-Positive)**: Hoạt động đúng chuẩn giao diện IME của hệ điều hành, tuân thủ nghiêm ngặt chính sách diệt virus của Microsoft Store và các giải pháp bảo mật doanh nghiệp.

### 2. Hệ thống Dự đoán Ngữ cảnh Song ngữ & Công thái học Dream RSI (P10)
- **Tập tri thức chuẩn mực 53.962 mục**: Bao gồm 6.669 âm tiết Việt chuẩn mực, 1.941 từ ghép Việt (`vn_compounds.txt`, 13 chuyên ngành), 3.346 từ Anh tần suất cao (`en_freq3000.txt`), 9.868 từ đơn Anh (`en_words10k.txt`), 1.957 từ ghép & cụm danh từ Anh (`en_compounds.txt`, 16 domain hiện đại: AI, Cloud, Dev, Fin, HR, Legal…), cùng 30.181 cặp câu/cụm/thành ngữ song ngữ (8.792 mẫu Việt `vn_phrases.tsv`, 10.224 mẫu Anh `en_phrases.tsv` và 11.165 mẫu câu văn phòng/thiếu số câu Anh `en_office_phrases.tsv`).
- **Đồng bộ song hành 2 chế độ (Mode VI & Mode EN)**:
  - **Mode EN (`E`)**: Hoàn tất từ đơn, từ ghép, gợi ý cụm từ tiếp theo, **chuỗi gợi ý nối tiếp bằng Tab** (nhận xong là cụm kế hiện ngay), duyệt vòng 5 ứng viên bằng Ctrl+Space, chữ mờ xem trước (ghost preview) siêu tốc 75 µs.
  - **Mode VI (`V`)**: Nhận diện thông minh từ ngữ tiếng Anh xen kẽ. Tự động phục hồi từ/cụm tiếng Anh bị gõ theo Telex mà không phải âm tiết tiếng Việt hợp lệ (ví dụ: `customer` thành `cútomer` + Tab → `customer service`; `looking forward` thành `looking fỏwad` + Tab → `looking forward to hearing from you soon`).
- **Phím tiện ích Standalone `Ctrl` Tap**: Bấm thả phím `Ctrl` đơn lẻ để chốt từ hợp lệ (`tunx` + Ctrl → chốt âm tiết `tũn`), hoặc lập tức khôi phục từ sai chính tả tiếng Việt về nguyên bản tiếng Anh (`sort` → `sỏt` + Ctrl → `sort`).
- **Công nghệ đo lường công thái học Dream RSI (P10 / G19)**: Đo lường khách quan số phím bấm thực tế tiết kiệm được. Đạt tỷ lệ tiết kiệm 22% số phím gõ trong tác vụ văn phòng thực tế; kiểm soát chống hồi quy hiệu năng nghiêm ngặt qua CI (`perf/baseline-win.json`).
- **Hồ sơ phong cách người dùng (User Style Profile P7)**: Tự động ghi nhận từ vựng riêng và cặp sửa lỗi người dùng chấp nhận, học 100% offline **trên chính máy này**, **bật mặc định** (không bao giờ học ở ô mật khẩu hay terminal; không ghi lại phím hay câu văn, G8). Tắt/bật, xem số liệu và xóa dữ liệu đã học ngay trong khung *Trợ lý ngữ pháp* của Cài đặt (3 OS), kèm số liệu **Dream RSI** (phần trăm phím tiết kiệm nhờ gợi ý) cộng dồn qua các phiên.

### 3. Trợ lý Ngữ pháp & Ngữ cảnh On-Device (Grammarly-Grade Offline)
- **Kiểm soát 15 nhóm lỗi toàn diện**: Bắt lặp từ, lặp cụm 2–4 từ, khoảng trắng quanh dấu câu, viết hoa đầu câu, sai vị trí dấu thanh ("nghiã" → "nghĩa"), **sai dấu thanh theo từ điển âm tiết dựng sẵn ("chềt" → "chết", bắt 99% lỗi dấu thanh tổng hợp, 0% báo nhầm trên corpus sạch — không cần từ điển hệ điều hành)**, phủ định kép, phẩy sau liên từ, mạo từ tiếng Anh a/an, cặp từ dễ nhầm lẫn EN, đại từ "i", chính tả EN/VI, cảnh báo ngày tháng phi lý (31/02, 32/13 — calendar-aware), số tiền phân cách hỗn loạn (1.250.00đ).
- **Cơ chế Idle 1 giây trên cả 3 hệ điều hành**: Dừng gõ 1 giây → panel trợ lý tự động xuất hiện ngay tại con trỏ (caret), gạch chân đỏ chính xác từ sai kèm tổng số lỗi; gõ tiếp → panel lập tức ẩn đi để không làm gián đoạn dòng văn bản.
- **Hai chế độ linh hoạt**: Chế độ *Chỉ gợi ý* (Mode 1) hoặc *Tự sửa lỗi an toàn* (Mode 2) tự động sửa lỗi khách quan và cho phép hoàn tác 1 chạm bằng Ctrl+Z trong vòng 5 giây.
- **Tiêu chuẩn vàng không báo nhầm (0% FPR)**: Đạt tỷ lệ 0 % câu đúng bị báo nhầm trên tập kiểm định 981 câu tiếng Việt và 295 câu tiếng Anh ([P4-12 §11](docs/50-assist/P4-12-RECALL-REAL.md)).

### 4. Di sản Chuẩn UniKey 20 Năm & Tiện ích Văn phòng Hiện đại
- **Chuẩn mực gõ dấu UniKey**: Đầy đủ các kiểu gõ Telex, VNI, VIQR, Simple Telex; hỗ trợ lựa chọn dấu cũ (`hòa`, `thủy`) hoặc dấu mới (`hoà`, `thuỷ`); chuẩn vần `uo` (`luong`/`uong` giữ nguyên, gõ `w` hoặc dấu mới thành `ươ`).
- **Tiện ích Telex thông minh**: Gõ nhanh `[` / `]` thành `ơ` / `ư` nhưng bảo vệ tuyệt đối dấu ngoặc vuông trong lập trình (`arr[0]`, Markdown `- [ ] task`); gõ `a--b` thành gạch nối dài `a—b` nhưng giữ nguyên cờ lệnh code `--force`; gõ hoa thông minh `DD` → `Đ`; dead-key passthrough (`Ctrl+'`+`e` → `é`).
- **Phím tắt chuyển mã thông minh Ctrl+Shift+F9**: Tự động chuyển đổi qua lại giữa Unicode, TCVN3, VNI, Unicode tổ hợp; tự động nhận diện bảng mã nguồn bị lỗi hiển thị (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`); tự động sửa chuỗi gõ nhầm khi quên bật tiếng Việt (`tooi ddi hocj` → `tôi đi học`) trên cả 3 hệ điều hành.
- **Bảng điều khiển đồng bộ 3 OS**: 100% nút bấm có biểu tượng và tooltip gợi ý; nút "Ẩn vào khay" và "Thoát" phân định rõ ràng; cửa sổ *Hướng dẫn* tích hợp nút **Thảo luận** (Discussions) và **Báo lỗi** (issue tracker `https://github.com/hunglinhpt/TextVN/issues`); tray tự động đăng ký TSF cho tài khoản mà không cần quyền quản trị (Admin/UAC).

---

## Điểm Vượt Trội So Với Các Bộ Gõ Khác

Bảng so sánh đối đầu trực tiếp giữa TextVN và các bộ gõ truyền thống (UniKey, EVKey, OpenKey):

| Tiêu chí so sánh | TextVN (v0.2.89) | Bộ gõ truyền thống (UniKey / EVKey / OpenKey) |
|---|---|---|
| **Cơ chế xử lý phím** | In-process TSF (Windows), native IMK (macOS), IBus/Fcitx5 (Linux) | Global keyboard hook ăn phím + `SendInput` xoá ngược |
| **Lỗi mất chữ, lặp chữ (Chrome/Excel/Electron/Dual-Mode)** | **Triệt tiêu hoàn toàn** (composition nội tại không gạch chân; gắn cờ `INJECT_TAG` + `KeyOrigin` chặn vòng lặp phím giả, giữ nguyên `"TextVN"`) | Thường xuyên gặp khi gõ nhanh, gõ từ tiếng Anh hoa/thường lẫn dấu hoặc chuyển cửa sổ |
| **Cô lập Terminal X11/SSH & Control không nhập chữ** | Tự động nhường TSF theo tiến trình con & lớp cửa sổ (`MoTTY`, `PuTTY`, `mintty`, `XWin*`), kiểm `EMPTYCONTEXT`/`READONLY` — **không còn khung mũi tên xanh góc trái `(0,0)`** | Tranh chấp với hệ thống IME của OS/X11 hoặc làm hỏng type-ahead trong Explorer |
| **Tự nhận diện EN/VI khi gõ xen kẽ** | Luật ngữ âm Việt + 103 từ dễ nhầm + 116 thuật ngữ + từ điển EN cá nhân + lưới bảo vệ 94 âm tiết: trả lại từ gốc khi gõ dấu cách | Telex áp đặt toàn bộ — `text` thành `tẽt`, `is` thành `í`; buộc phải chuyển chế độ thủ công |
| **Dự đoán từ & cụm song ngữ (Tab/Space)** | Đầy đủ từ đơn, từ ghép, cụm từ ngữ cảnh ở cả Mode VI & Mode EN; chuỗi gợi ý nối tiếp bằng Tab; 5 ứng viên Ctrl+Space; ghost preview 75 µs | Không hỗ trợ hoặc chỉ gõ tắt tĩnh |
| **Công thái học Dream RSI (P10)** | Đo lường khách quan số phím tiết kiệm (tỷ lệ tiết kiệm 22% trên văn phòng); chặn hồi quy qua CI | Không có |
| **Trợ lý ngữ pháp & chính tả on-device** | 15 loại lỗi (lặp từ, khoảng trắng, viết hoa, sai dấu, a/an, ngày tháng, tiền tệ); panel dừng gõ 1 giây trên 3 OS; 0% báo nhầm; Ctrl+Z 5s | Không có |
| **Khôi phục phím Standalone Ctrl Tap** | `tunx` + Ctrl → `tũn` (chốt âm tiết); `sort` → `sỏt` + Ctrl → `sort` (khôi phục từ sai) | Không có |
| **Escape khôi phục nguyên phím đã gõ** | Nhấn Escape trả lại đúng chuỗi ký tự gốc tức thì | Không có hoặc chỉ hỗ trợ xoá cả câu |
| **Chuyển đổi V/E toàn cục (Ctrl+Shift)** | Bộ dò tap chỉ quan sát (không ăn phím) + debounce chống lật đôi giữa tray và engine | Dễ xung đột lật đôi trạng thái hoặc bị Antivirus chặn |
| **Tiện ích lập trình & soạn thảo** | Phím `[` `]` thành `ơ`/`ư` thông minh (bảo vệ `arr[0]`); `a--b` thành `a—b` (bảo vệ `--flag`); `DD` → `Đ` | Biến đổi mù quáng làm hỏng mã nguồn và cú pháp Markdown |
| **Chuyển mã thông minh (Ctrl+Shift+F9)** | Tự động đoán mã nguồn lỗi (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`), sửa lỗi gõ sai khi tắt IME (`tooi ddi hocj` → `tôi đi học`) | Chỉ chuyển mã clipboard thủ công cơ bản |
| **Quyền cài đặt & UAC** | Per-user HKCU, portable giải nén chạy ngay, không cần Admin/UAC | Đa số yêu cầu quyền Admin hoặc cài đặt vào Program Files |
| **Tự sửa lỗi đăng ký (Ghost Registration)** | Tự phát hiện và cập nhật đường dẫn khi di chuyển thư mục | Báo lỗi hoặc phải gỡ ra cài lại thủ công |
| **Chính sách riêng tư (G8)** | **100% Offline**, zero keylogging, không telemetry; tự tắt ở ô mật khẩu; mã nguồn mở minh bạch | Nhiều bộ gõ đóng mã nguồn, không có cam kết riêng tư minh bạch |

---

## Tính Năng Đầy Đủ (Tích luỹ đến 0.2.90)

### 0. Universal Scientific, Engineering & Math Engine (mới ở 0.2.83 — crate `textvn-math`)
- **Chord FSM đa lớp**: Leader-Key one-shot (`` ` `` khi Math Mode active), priority chain deterministic, double-leader escape, timeout/OnKillFocus reset, map mnemonic Hy Lạp + cấu trúc (`/ \frac{}{}`, `q \sqrt{}`, `i \int`, `S \sum`, `8 ∞` …) với `cursor_left_steps` chính xác cho từng output mode.
- **Smart Formula Clipboard**: tự nhận diện công thức trong clipboard (chống false-positive: path, `$50`, URL, JSON, prose), chuyển đổi hai chiều LaTeX ↔ Presentation MathML (Word/MathType) ↔ Unicode ↔ Typst, worker latest-wins không block luồng UI/TSF, tôn trọng privacy marker của OS.
- **Lexicon 6 ngành + alias tiếng Việt** (`\can`, `\phanso`, `\tichphan`, `\ohm` …), **template động** (`\mat3x3`, `\hpt2`), **inline evaluator** `= expr =` an toàn, **auto-bypass** trong `$...$`/`\text{...}` và code token (`0xFF`, `CAN_FD`).
- Hướng dẫn chi tiết song ngữ: [docs/MATH_SCIENCE_GUIDE.md](docs/MATH_SCIENCE_GUIDE.md).

### 1. Công thái học Dream RSI & Kiểm chuẩn Hiệu năng (P10 / G19)
- Tích hợp công nghệ đo lường công thái học Dream RSI: 4 chỉ số cốt lõi (`keys_typed`, `accepts`, `chars_saved`, `savings_rate_pct`).
- Phân tích hiệu quả gợi ý theo thời gian thực: tiết kiệm 22% số phím gõ trong tác vụ văn phòng thực tế (36 lượt nhận / 72 phím tiết kiệm trên corpus benchmark chuẩn).
- 6 đường nhận diện gợi ý: Tab hoàn tất tiếng Việt, Tab hoàn tất tiếng Anh/style-word, Space nhận từ, duyệt ứng viên (cycle), gợi ý cụm từ tiếp theo (next-phrase), chuỗi gợi ý nối tiếp (Tab ngay sau khi nhận — R2-173).
- Chặn hồi quy tự động trong CI: mọi cải tiến gợi ý bắt buộc phải duy trì hoặc tăng tỷ lệ tiết kiệm phím so với baseline (`perf/baseline-win.json`).

### 2. Mô hình Dự đoán Ngữ cảnh P6 & Hồ sơ Phong cách P7 (Corpora 53.952 mục)
- **Tập dữ liệu tri thức 53.952 mục** song ngữ chất lượng tương đương:
  - 6.669 âm tiết Việt chuẩn mực + 1.941 từ ghép Việt (`vn_compounds.txt`, 13 domain chuyên ngành).
  - 3.346 từ Anh tần suất cao (`en_freq3000.txt`) + 9.868 từ đơn Anh (`en_words10k.txt`) + 1.957 từ ghép & cụm danh từ Anh (`en_compounds.txt`, 16 domain chuyên sâu).
  - 30.181 cặp câu/cụm/thành ngữ (8.792 mẫu Việt `vn_phrases.tsv` + 10.224 mẫu Anh `en_phrases.tsv` + 11.165 mẫu câu văn phòng Anh `en_office_phrases.tsv` — câu thật chia mọi ranh giới từ, thành ngữ thật, mẫu câu công sở theo vai trò: báo cáo cấp trên, điều phối cấp dưới, kỹ thuật, nghiệp vụ & trộn Việt-Anh).
- Hoạt động đồng bộ ở **cả 2 chế độ**:
  - **Mode EN (`E`)**: Hoàn tất từ đơn/từ ghép, chuỗi gợi ý nối tiếp bằng Tab, duyệt vòng 5 ứng viên bằng Ctrl+Space, đoán câu tiếp theo, ghost preview 75 µs, học từ Dream RSI.
  - **Mode VI (`V`)**: Tự động nhận diện từ/câu tiếng Anh kể cả khi bị Telex fold (ví dụ: `customer` → `cútomer` + Tab → `customer service`; `looking forward` → `looking fỏwad` + Tab → `looking forward to hearing from you soon`).
- **User Style Profile (P7)**: Tự học từ cá nhân & cặp sửa lỗi, bật mặc định (tắt/xóa được trong Cài đặt), 100% offline, giới hạn an toàn 200 từ / 50 cặp; hiển thị Dream RSI cộng dồn.
- Tra cứu cấu trúc Trie + Frecency tốc độ micro-giây, xếp hạng mở rộng đúng nghĩa ngữ cảnh.

### 3. Kiểu Gõ & Biến Đổi Âm Vị Học Chuẩn Mực
- Vần `uo` chuẩn UniKey 20 năm: `luong`/`uong`/`truong.giap` giữ nguyên khi không dấu; chỉ khi có biến đổi VN hoặc gõ `w`/dấu chủ động mới thành `ươ` (`luonwg`, `tuowi`, `tuowng`, `duongf` → `dường`).
- Chống xung đột 2 bộ gõ & cô lập Terminal (E46/E49): nhường TSF theo cả tiến trình con (`MoTTY.exe`, `XWin_MobaX.exe`, `XWin*`, `vcxsrv.exe`, `Xming.exe`) lẫn lớp cửa sổ (`MoTTY`, `PuTTY`, `mintty`, `KiTTY`, `MSCTFIME UI`, `cygwin/x*`), kiểm `EMPTYCONTEXT`/`KEYBOARD_DISABLED`/`READONLY` và dọn composition khi chuyển focus — loại bỏ khung góc trái `(0,0)`; trên app dùng hook, chuẩn hoá `LLKHF_INJECTED` + `INJECT_TAG` (`KeyOrigin`), đồng bộ `auto_capped` và tách chuỗi phím undo hiệu lực (`fold_effective_caps` + khóa identifier E50) đảm bảo `"TextVN"` và chuỗi sửa nhanh `"TexxtVN"` không lặp phím hay mất chữ hoa (E48/E50).
- Khôi phục dead-key Windows (`Ctrl+'`+`e` → `é`) trên bàn phím quốc tế.
- Chặn hoàn tất token ID/username: không bao giờ tự động hoàn tất qua ranh giới dấu chấm, gạch ngang, email (`truong.giap`, `t.ho`).
- Đầy đủ Telex, VNI, TCVN3 (VIQR đọc được), Quick Telex (cc→ch, gg→gi…), gõ tự do (free marking).
- 3 bảng mã xuất: Unicode dựng sẵn, TCVN3, VNI (+ Unicode tổ hợp) — chuyển đổi qua lại giữ nguyên chữ.
- Kiểu dấu cũ/mới chọn được (`hoà`/`hòa`, `thuỷ`/`thủy`) — toàn bộ dữ liệu dự đoán tự động khớp theo kiểu đã chọn.
- Chữ hoa thông minh: `DD` → `Đ`, Caps Lock/Shift từng phím, tự viết hoa đầu câu (tắt được).
- Escape khôi phục nguyên chuỗi phím đã gõ ở mọi thời điểm.
- Chống vòng lặp phím (E28): gõ lặp dấu không sinh chu kỳ vô tận trên cả Telex, VNI và VIQR.
- Gõ tắt (macro) theo kiểu chữ (HD→HỢP ĐỒNG), hoạt động được cả khi tắt tiếng Việt.
- **Bảng chọn Emoji nhẹ chuẩn HĐH / MS Teams / iOS (`Ctrl+Alt+E`) & gõ nhanh `:shortcode:` (P12)**: ~280 emoji quen thuộc chia 8 nhóm (Gần đây MRU + 7 danh mục), tìm kiếm song ngữ Việt–Anh không dấu (`cười`/`cuoi`/`fire`/`tim`), tự mở rộng `:smile:`, `:fire:`, `:camon:` ngay khi gõ (kể cả chế độ Telex & EN, tự chặn ở ô mật khẩu/terminal/URL/công thức toán); render emoji màu thật cực nhẹ bằng Direct2D/DirectWrite (Windows, không cướp focus), `NSPanel` Apple Color Emoji (macOS), và `IBusLookupTable`/`CommonCandidateList` (Linux X11 + Wayland).
- **Math & Science trên mọi editor (`Ctrl+Shift+M` / `Ctrl+Alt+M`, [MATH_SCIENCE_GUIDE.md](docs/MATH_SCIENCE_GUIDE.md))**: bật là dùng ngay trên Notepad, Word, VS Code, Overleaf, Chrome, Teams, terminal (cả Mode VI lẫn EN) — gõ leader chords (`` `a ``→`α`, `` `/ ``→`\frac{}{}` tự đặt con trỏ vào `{}`, chuỗi mũ/chỉ số `x²`/`xⁿ`/`x⁻¹`/`H₂SO₄`/`SO₄²⁻`/`aₙ` ngay ở mode Normal), alias toán-lý-hóa (`\can`, `\voimoi`, `\in`, `\infty`, `\h2o`, `\h2so4`, `\Fe2+`), tính nhanh chuẩn xác `=0.1+0.2=`→`0.3` (không treo Telex với dấu `=` lẻ trong bài văn), tự tạm dừng tiếng Việt trong `$...$`/`\(...\)`/môi trường toán `\begin{align*}` và giữ tiếng Việt trong `\begin{document}`/`\section{...}`/`\text{...}`/`\intertext{...}`.
- Số tiền `=1.550.00đ` → chữ Việt; bảo vệ công thức Excel và định danh lập trình.

### 4. Trợ Lý Ngữ Pháp Câu & Từ Ngữ Cảnh On-Device
- 15 loại lỗi phát hiện tự động: lặp từ, lặp cụm 2–4 từ, khoảng trắng quanh dấu câu, chữ thường đầu câu, sai dấu thanh, phủ định kép, phẩy cuối câu, phẩy sau liên từ, a/an, cặp từ dễ nhầm EN, đại từ "i", chính tả EN (OS spell), chính tả VI (từ điển âm tiết dựng sẵn), ngày tháng vô lý (31/02, 32/13), số tiền phân cách hỗn loạn (1.250.00đ).
- Panel gợi ý khi **dừng gõ 1 giây** (cả 3 hệ điều hành): mọi phím gõ chữ/dấu câu/xoá hẹn lại đồng hồ, gõ tiếp là ẩn ngay, dừng đủ 1 s mới kiểm tra từ + câu rồi hiện (cả chế độ gợi ý lẫn sửa lỗi an toàn, kể cả sau `.` `,`); giữa từ đang gõ chỉ Windows hiện (Linux/macOS đợi từ chốt).
- Panel hỗ trợ chuột bấm, Alt+1…3, Enter áp "Sửa tất cả".
- Chế độ 1 chỉ gợi ý / Chế độ 2 tự sửa lỗi khách quan — hoàn tác Ctrl+Z trong 5 giây.
- Kiểm tra theo vùng bôi đen (Shift+mũi tên → popup + Sửa tất cả) và kiểm tra câu dài.
- Tuỳ chọn tắt riêng từng ứng dụng (per-app); tự tắt ở ô mật khẩu; 0% báo nhầm (FPR) trên tập kiểm thử 2.739 câu chuẩn mực.

### 5. Tiện Ích Chuyển Mã & Văn Phòng Đột Phá (P5)
- Ctrl+Shift+F9 chuyển mã vùng bôi đen: TCVN3/VNI/Unicode tổ hợp → Unicode dựng sẵn, tự nhận diện bảng mã (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`), gõ lại chữ gõ nhầm khi quên bật (`tooi ddi hocj` → `tôi đi học`) trên cả 3 hệ điều hành.
- Khôi phục tiếng Anh thông minh: luật ngữ âm Việt + 103 từ Anh dễ nhầm + 116 thuật ngữ EN chuyên ngành + từ điển cá nhân.
- Cơ chế bảo vệ: bảo vệ định danh camelCase, chuỗi nguyên văn trong ngoặc kép.

### 6. Kiến Trúc Hệ Thống, Điều Khiển & Riêng Tư Tuyệt Đối
- Phím nóng: Ctrl+Space sửa/dự đoán · Ctrl+Shift gạt VN/EN (nhớ trạng thái) · Ctrl+Shift+F9 chuyển mã.
- Bảng cài đặt native từng OS: Windows khay hệ thống (7 nút có icon + tooltip, phân định Ẩn vào khay/Thoát, tích hợp nút **[Chẩn đoán & xuất log]** và **[Cài & bật TSF]** dạng Command Link rõ ràng trong cửa sổ *Hướng dẫn*), Linux GTK4/GTK3 tự động, macOS menu bar SwiftUI; cửa sổ **Hướng dẫn** trên cả 3 OS tích hợp nút 1 chạm **[Chẩn đoán & xuất log]** (ẩn PII, 0 keylogging theo G8/S2), **Math & Science**, **Thảo luận** (`https://github.com/hunglinhpt/TextVN/discussions`) và **Báo lỗi** (`https://github.com/hunglinhpt/TextVN/issues`).
- Offline 100%, không gửi dữ liệu ra mạng, không lưu nội dung phím gõ; tự ngắt khi gặp trường mật khẩu; chính sách bảo mật công khai trong repo.
- **Chẩn đoán & hỗ trợ 1 chạm, an toàn riêng tư (E69/E70)**: `textvn-cli --check-env` / `--diagnose` / `--export-log` (Linux: `textvn …`), nút **[Chẩn đoán & xuất log]** ngay đầu cửa sổ *Hướng dẫn* trên cả 3 OS và ngay cấp 1 menu khay Windows / menu bar macOS kèm **[Mở thư mục tệp ZIP]** (macOS tự mở Finder chọn sẵn tệp), **[Copy tóm tắt lỗi]** (đã ẩn tên người dùng) + **[Mở trang báo lỗi]**; gói ZIP có `git_sha`, target, loại bản (installer/portable/store), `panic.log` chỉ ghi vị trí mã nguồn & ký hiệu backtrace (không bao giờ ghi thông điệp động); tự phát hiện xung đột UniKey/EVKey/OpenKey/GoTiengViet/VietKey, **Microsoft Vietnamese Telex/VNI**, **Apple Vietnamese** và `ibus-unikey`/`bamboo`/`fcitx5-unikey`/dual daemon kèm cách thoát cụ thể — xem **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**.

---

## Tải và Cài Đặt

Bản mới nhất: **[GitHub Release v0.2.93](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.93)** — **Gợi ý nối tiếp gợi ý: nhận một gợi ý bằng Tab là cụm kế tiếp hiện ngay bằng chữ mờ, Tab nhận tiếp thành chuỗi (`phát`+Tab+Tab → `phát triển phần mềm`; Ctrl+Space đổi ứng viên) — chữ mờ luôn đúng là chữ Tab chèn, Space sau khi nhận cũng gợi ý tiếp, thêm cụm cho lời chào/chúc/văn phòng; Windows: ô tìm kiếm Start, Calculator, ứng dụng Store (sandbox AppContainer/LPAC) gõ đúng kiểu gõ và nút V/E nhờ bản sao cấu hình đã lọc + pipe sandbox hạn chế, kiểm bằng tiến trình AppContainer và LPAC thật** (release candidate do CI build và kiểm thử tự động: `cargo xtask preflight` 25/25 bước, toàn bộ test workspace pass 100%, cổng perf xanh, Dream RSI 22% không đổi, clippy `-D warnings` sạch trên Windows + Linux). **Mọi file phát hành đều có chữ ký GPG (`.asc`) và Sigstore (`.cosign.sig` + `.cosign.cert`)**, file kiểm tra `SHA256SUMS.txt` được clearsign — hướng dẫn kiểm tra: [signing.md](docs/release/signing.md). *Lưu ý: Windows chưa ký Authenticode (chờ SignPath Foundation duyệt) và macOS chưa notarization ([signing-status-mac.md](docs/release/signing-status-mac.md)).*

| Nền tảng | Cài đặt chính thức | Dùng ngay không cần cài đặt |
|---|---|---|
| **Windows 10/11 x64 (Home / Pro / Enterprise / LTSC)** | `TextVN-setup-<ver>-windows-x64.exe` (cho tài khoản cá nhân, không cần quyền admin/UAC)<br>`TextVN-setup-<ver>-windows-x64-machine.exe` (cho mọi người dùng máy, Program Files, UAC một lần — khuyên dùng cho Windows 10/11 Enterprise) | `TextVN-portable-<ver>-windows-x64-*.zip` → giải nén chạy ngay `TextVN.exe` (tương thích toàn dải Win10 1507–22H2 & Win11 21H2–24H2; có nút **[Cài & bật TSF]** trong Hướng dẫn) |
| **Windows Microsoft Store** | ✅ **[TextVN trên Microsoft Store](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)** (miễn phí, Store ID `9NV2R7JNNFGK`) — tự động cập nhật, gói do Microsoft ký số xác thực. Cài nhanh qua terminal: `winget install --id 9NV2R7JNNFGK -s msstore`. *(Gói `.msix` trên GitHub Release là bản nộp Store chưa ký)* | — |
| **macOS 13+ (Apple Silicon & Intel)** | **Homebrew (khuyên dùng): `brew install --cask hunglinhpt/tap/textvn`** — tự động cài bộ gõ vào `~/Library/Input Methods` và ứng dụng thanh menu vào `/Applications`; nâng cấp qua `brew upgrade`.<br>Hoặc dùng file gói `TextVN-mac-v<ver>.pkg` (cài đặt per-user, không cần quyền root/sudo) | `TextVN-macos-universal-v<ver>.zip` (chứa `TextVN-IM.app` + `TextVN.app` universal binary) — xem [Hướng dẫn sử dụng macOS](docs/user-guide.md) |
| **Linux (8 dòng distro doanh nghiệp & phổ thông · IBus / Fcitx5)** | **Tarball đa distro duy nhất** (`glibc ≥ 2.28`, tự chọn GTK 4 / GTK 3, hỗ trợ KDE Fcitx5-only): `tar xzf TextVN-<ver>-linux-x86_64.tar.gz` → `./install.sh` (per-user) hoặc `sudo ./install.sh --system` (khuyên dùng trên RHEL 8/9, SLES 15 Enterprise).<br>**Arch Linux (AUR)**: `paru -S textvn` · **Ubuntu/Debian PPA**: `ppa:hunglinhpt/textvn` | Chạy trực tiếp từ tarball giải nén: `./textvn-portable.sh` (hỗ trợ live-register trên GNOME Wayland không khởi động lại `ibus-daemon`) |

Chi tiết cài đặt, gỡ bỏ, hướng dẫn sử dụng và khắc phục sự cố: **[Tài liệu Hướng dẫn sử dụng](docs/user-guide.md)** · bảng mã lỗi, xung đột bộ gõ, phụ thuộc theo distro, lưu ý doanh nghiệp/portable: **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**.

> [!NOTE]
> **Lưu ý Windows 11 (23H2/24H2+ & Enterprise)**: Một số bản cập nhật hoặc cấu hình Windows 11 Enterprise từ chối kích hoạt bộ gõ chỉ đăng ký trong phạm vi tài khoản per-user (mã lỗi B7 / E65). Bản cài đặt tài khoản và bản portable của TextVN **không bao giờ đòi hỏi UAC** — nếu chưa gõ được, mở **Bảng điều khiển → [Hướng dẫn] → [Cài & bật TSF]** để đăng ký lại và xem nguyên nhân chi tiết (`register.log`), hoặc cài bản `-machine.exe` (Program Files, HKLM một lần).

---

## Bản Phát Hành Gần Đây

Chi tiết đầy đủ lịch sử phát triển: [CHANGELOG.md](CHANGELOG.md).

| Phiên bản | Điểm nhấn tính năng |
|---|---|
| [0.2.93](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.93) | **Gợi ý nối tiếp gợi ý (R2-173) + ô tìm kiếm Start/ứng dụng Store theo cấu hình (R2-26)**: sau khi nhận bằng Tab, còn cụm nối tiếp khoá ≥ 2 từ thì chữ mờ hiện ngay và Tab nhận tiếp (`Kính gửi`+Tab+Tab → `Kính gửi quý khách hàng tiềm năng`), khoá 1 từ vẫn duyệt vòng, Ctrl+Space luôn duyệt vòng; bất biến "chữ mờ = đúng chữ Tab chèn" kiểm trên Mode VI + EN; Dream RSI đếm đúng từng cụm; Windows vẽ chữ mờ sau Space ở key-up (E79); thêm cụm `xin chào`/`chúc bạn`/`phát sinh`. Sandbox Windows: bản sao `%APPDATA%\TextVN\sandbox\` (DACL bảo vệ, danh sách cho phép — không gõ tắt/emoji/từ tự thêm/từ đã học), pipe sandbox nhãn Low chỉ cho đọc trạng thái + Ctrl+Shift + bộ đếm Dream RSI, không lộ override app khác, trần 32 kết nối · 40 frame/s; `textvn-cli doctor` dòng `Sandbox`/`W_SANDBOX_MIRROR`; test chạy tiến trình AppContainer + LPAC thật ([sandbox-appcontainer.md](docs/specs/sandbox-appcontainer.md)). |
| [0.2.92](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.92) | **Linux bền vững theo đối chiếu Ngó Sen · OpenKey · ibus-bamboo · x-unikey + 10 bộ gõ khác (R2-165…R2-172)**: `lc_edit_batch` dùng chung IBus/Fcitx5 — mỗi phím ≤ 1 xoá + 1 commit (text-input-v3/mutter chỉ giữ lệnh cuối; trước đây trợ lý tự sửa câu mất từ và xoá lẹm trên GNOME Wayland); commit trước → đóng preedit sau (ibus-bamboo #574 lặp từ cuối sau Enter); Math `Left` nhấn + nhả + keycode thật, `W_MUTTER_FORWARD_KEY_BUG`; engine: chữ số dính liền trả phím (`Sose2026`), vần `oo` chỉ khép `ng`/`c` (`booots` → `boots`, giữ `Thoòng`/`voọc`), âm đầu `dz`; tự viết hoa sau Enter cả khi GTK reset (fcitx5-lotus #597); gõ được `Đắk Lắk`, `Krông Búk` (xkey #135); 423/423 từ thông dụng khớp, x-unikey lệch `huơ`; giới hạn Linux đã biết trong [TROUBLESHOOTING](docs/TROUBLESHOOTING.md), báo cáo đầy đủ [P3-8](docs/40-linux/P3-8-COMPETITOR-BUG-AUDIT-2026-11.md). |
| [0.2.91](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.91) | **Chẩn đoán & xuất log 1 chạm nổi bật 3 OS (Popup Hướng dẫn + Cấp 1 Menu Khay)**: Windows chuyển popup *Hướng dẫn TextVN* sang Command Links dọc (`TDF_USE_COMMAND_LINKS \| TDF_SIZE_TO_CONTENT`, đặt **[Chẩn đoán & xuất log]** ở vị trí #1 trên **[Cài & bật TSF]**, hết tràn/cắt nút mọi DPI) + nút **[Mở thư mục tệp ZIP]** (`explorer /select`); Linux GTK4/GTK3 tách hàng 1 nổi bật `suggested-action` + hiện phát hiện lỗi inline + **[Mở thư mục tệp ZIP]**; đưa **Chẩn đoán & xuất log...** lên cấp 1 menu chuột phải khay Windows, menu bar macOS và menu IBus/Fcitx5 (`textvn-settings --diagnose`) · preflight 25/25, Dream RSI 22%, CI xanh 7/7 workflow |
| [0.2.90](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.90) | **E70 Chẩn đoán & xung đột 3 OS · Sửa hồi quy perf 0.2.83**: `panic.log` an toàn riêng tư (vị trí + ký hiệu backtrace, không ghi thông điệp động) cho tray/CLI/hook; phát hiện Microsoft Vietnamese Telex/VNI (`W_CONFLICT_VI_TIP`) & Apple Vietnamese (`W_CONFLICT_APPLE_VI_IM`); `--check-env`/`--diagnose`/`--export-log`; `version.json` có `git_sha`/target/loại bản; khay Windows báo xung đột khi khởi động + *Sức khỏe › Xuất log chẩn đoán* + **[Copy tóm tắt lỗi]**; `parse_config` 10,4 → 2,17 µs, hotkey Math bảo vệ không phân biệt hoa/thường; smoke Ubuntu 20.04 / Debian 11; [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) · preflight 25/25, 2272 test, Dream RSI không đổi |
| [0.2.89](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.89) | **E69 Tự động cài phụ thuộc Linux (`ibus`/`fcitx5`/`gtk`) · Phát hiện xung đột bộ gõ cũ 3 OS · Xuất log chẩn đoán 1 chạm**: tự nhận diện `apt`/`dnf`/`yum`/`zypper`/`pacman` để cài gói thiếu & kiểm lại ABI (`--install-deps` hoặc hỏi `[Y/n]`); phát hiện xung đột IME kèm mã lỗi & lệnh thoát cụ thể trên Linux (`ibus-daemon`+`fcitx5`, `fcitx` v4/`xvnkb`, `ibus-unikey`/`bamboo`, `fcitx5-unikey`, lệch `GTK_IM_MODULE`), Windows (`UniKey`/`EVKey`/`OpenKey`/`GoTiengViet`/`VietKey`), macOS; `textvn doctor --report` / `--export auto` (`report_summary.md`, `install-diag.log`, `register.log`, ẩn PII) + nút **[Xuất log chẩn đoán]** trong cửa sổ Hướng dẫn trên cả 3 OS · 57 test `cli`, 88 test `tray`, `unit_e69_deps_conflicts_diag`, Dream RSI 22%, CI xanh 7/7 workflow |
| [0.2.88](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.88) | **E65 Win11 Enterprise Portable + `[Cài & bật TSF]` · E66 Toàn dải Win10/11 · E67 RHEL 8.10 · E68 8-Distro Enterprise Linux**: khắc phục đăng ký TSF non-admin & đưa nút `[Cài & bật TSF]` kèm `register.log` vào Hướng dẫn; nạp động DPI & nạp lười D2D1/DWrite/DWM chạy mượt mọi bản Win10 (1507–22H2) & Win11 (21H2–24H2) cài lẫn portable; một tarball Linux duy nhất (dual-baseline EL8 `glibc 2.28` + GTK 3 & Ubuntu 22.04 `glibc 2.35`/`GLIBCXX 3.4.30` + GTK 4 + Fcitx5 5.0), hỗ trợ KDE Fcitx5-only, KWin Wayland, `~/.xprofile` X11/LightDM, GNOME Wayland live-register, SELinux `restorecon`, `textvn doctor` Linux · Kiểm E2E thật đủ 8 dòng distro (RHEL 8/9, SLES 15, Ubuntu 22.04/24.04, Debian 12, Fedora 41, Arch), Dream RSI 22%, CI xanh 7/7 workflow |
| [0.2.87](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.87) | **E61 UniKey Undo · E62 Universal Math · P12 Native Emoji Picker · E63 4-Expert Audit · E64 Ubuntu 22.04 Terminal/IBus Hardening**: sửa triệt để hoàn tác UniKey (`Sirr`→`Sir`, `Eulerr`→`Euler`); Math & Science hoạt động mọi editor 3 OS (`cursor_left`, mũ/chỉ số `xⁿ`/`SO₄²⁻`, LaTeX/Typst, máy tính khử nhiễu IEEE-754); bảng Emoji `Ctrl+Alt+E` + `:shortcode:` bản địa siêu nhẹ; bảo vệ terminal Ubuntu 22.04 GNOME Wayland & đồng tồn tại `ibus-unikey` · 942 test `textvn-math`, Dream RSI 22%, CI xanh 7/7 workflow |
| [0.2.86](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.86) | **E59 Zero-Python Native & Audit cuốn chiếu 3 lượt**: port toàn bộ 18 script Python sang `cargo xtask` (Rust thuần `std`) + `e2e_fcitx5.c` (C/libdbus), thêm gate `no-python`/`check-en-office`; gia cố DEFLATE/ZIP64 chống zip-bomb, XML 1.0 namespace, PE32/PE32+ delay-load & CMake tùy chọn `dbus-1` · Hội tụ 0 lỗi, 91 test `xtask`, CI xanh 7/7 workflow |
| [0.2.85](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.85) | **Audit cuốn chiếu khép sạch Math Engine**: E57 (word-buffer/boundary đồng bộ Backspace/caret/HOME/END qua core hook, off-by-one delete_chars, `=expr=` là command, chốt span khi eval fail), E58 (22 lỗi thật dưới `#[ignore]`: AST `}`/`\frac{}{}`, eval pi/e/`^` right-assoc/unary, classifier LaTeX/MathML + Unicode sub/sup, lexicon 1504 entry) + un-ignore 560 test `si_group!` — 927 test math, 0 ignored · Test: 75 suite workspace pass 100%, clippy stable+nightly 0 warning, CI xanh cả 5 workflow |
| [0.2.84](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.84) | **Audit-fix loop triệt để**: E55 (keys_typed double-count khi math pass-through + reset state khi toggle OFF), E56 (FCA bung alias/template/inline-eval ở boundary qua word_buf thật), R2-162 (dọn dep thừa, 0 warning manifest cả 4 target), R2-163 (vá parity gap ci-macos: thêm `math/**`), needless_bool cho CI clippy 1.100 · Test: 73 suite workspace pass 100%, clippy 0 warning Linux+windows-msvc+darwin, CI xanh cả 5 workflow |
| [0.2.83](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.83) | **Universal Scientific, Engineering & Math Engine (crate `textvn-math`)**: chord FSM đa lớp, smart formula clipboard (LaTeX↔Presentation MathML↔Unicode↔Typst, chống false-positive, tôn trọng privacy marker), lexicon 6 ngành + alias Việt, template động, inline evaluator, auto-bypass `$...$`/`\text{...}`/code token · Test: 347 pass ở `textvn-math`, 71 suite workspace · Hướng dẫn: `docs/MATH_SCIENCE_GUIDE.md` |
| [0.2.82](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.82) | **E50 audit hoàn chỉnh**: bổ sung 6 test edge-case kiểm chứng logic "sau auto-restore thì skip rule Unikey" không hồi quy (restore từ EN liên tiếp, gõ không space, từ Việt sau restore, Unikey `dd`→`đ`, không restore khi không cần) · File test: `core/tests/e50_audit_edge.rs` |
| [0.2.81](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.81) | **Fix triệt để E50**: lỗi "đang định gõ đất → ra đata, space ra ddat / Task space ra Tassk" do cờ `restored` trong Word bị `clear()` xóa ngay — chuyển sang `Engine::last_word_was_restored`, skip rule Unikey sau auto-restore để phục vụ thói quen người dùng Unikey lâu năm · 4 regression test `e50_unikey_restore.rs` |
| [0.2.79](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.79) | Windows: nhường TSF cả theo tiến trình con MobaXterm (`MoTTY.exe`, `XWin*`, `vcxsrv`, `Xming`) lẫn lớp cửa sổ X11/TTY và kiểm `EMPTYCONTEXT`/`READONLY` trước `KeyEditSession` (E49); sửa triệt để lỗi lặp chữ & mất hoa `"TextVN" → "Texxtvn"` bằng `LLKHF_INJECTED` + `INJECT_TAG`/`KeyOrigin` và guard `auto_capped` (E48) · Đưa nút **Thảo luận** & **Báo lỗi** (`GitHub Discussions`) vào cửa sổ *Hướng dẫn* trên cả 3 OS · Bổ sung **1.447** regression test |
| [0.2.78](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.78) | Sửa rơi phím lạ khi Backspace giữa từ rồi Space/ESC trả chuỗi gốc (E47) · Bổ sung 7.913+ test cases phòng ngừa hồi quy (dual-mode matrix, rapid origin/case, TSF state) |
| [0.2.77](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.77) | Windows: MobaXterm (và PuTTY, mintty, Xshell, SecureCRT…) cùng thanh tác vụ **không còn hiện khung nhỏ mũi tên xanh ở góc trái** khi click vào rồi gõ phím (sau khi cài: đăng xuất/đăng nhập lại để explorer nạp bản mới) |
| [0.2.76](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.76) | Cài đặt: dòng mô tả dưới ô **Chế độ** của Trợ lý ngữ pháp rút gọn về **một dòng** gọn dễ đọc trên cả 3 OS |
| [0.2.75](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.75) | Windows: bấm vào thư mục (Explorer) hoặc chỗ không nhập được rồi gõ phím **không còn hiện khung nhỏ ở góc trái màn hình**; phím tới app đúng (gõ để nhảy tới mục) · ô nhập không bị ảnh hưởng · Trợ lý ngữ pháp chỉ còn **một** lựa chọn Chế độ (bỏ ô "Tự động sửa"), UI sắp lại |
| [0.2.74](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.74) | **Tự học & Dream RSI bật mặc định** và có nút trong Cài đặt (cả 3 OS): công tắt, số liệu "Đã học: N từ · M cặp sửa | Dream RSI: tiết kiệm X% số phím", nút Xóa dữ liệu đã học; Dream RSI lưu bền qua các phiên · lọc rác bàn phím khi học · không học ở ô mật khẩu/terminal |
| [0.2.73](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.73) | Trợ lý ngữ pháp **bắt lỗi dấu thanh** ("chềt" → "chết") bằng từ điển âm tiết dựng sẵn trên cả 3 OS — không cần từ điển hệ điều hành, 99% lỗi dấu thanh tổng hợp được bắt, 0% báo nhầm trên corpus sạch; "Sửa tất cả" bỏ qua gợi ý mơ hồ · sửa nhầm lặp từ láy còn sót |
| [0.2.72](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.72) | Bảng điều khiển: toàn bộ nút bấm có **biểu tượng + gợi ý tooltip** (cả 3 OS); Windows đổi nút thành **"Ẩn vào khay"/"Thoát"** để tránh nhầm lẫn đóng là tắt ứng dụng, bỏ nút "Cài & bật TSF" (tray tự động đăng ký) · Cập nhật README chính xác tính năng và số liệu thật |
| [0.2.71](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.71) | Linux (IBus/Fcitx5) và macOS: danh sách gợi ý của trợ lý **hiện khi dừng gõ 1 giây**, ẩn ngay khi gõ tiếp — đạt đồng bộ hoàn toàn với hành vi Windows 0.2.70; phím kết câu tự sửa ngay ở chế độ sửa lỗi an toàn |
| [0.2.70](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.70) | Windows: bảng trợ lý ngữ pháp **hiện lại khi dừng gõ 1 giây** (kể cả giữa từ, sau dấu chấm phẩy; chế độ gợi ý lẫn sửa lỗi an toàn) · "Sửa tất cả"/Alt+1…3 giữa từ không cắt đôi từ · Kiểm thử E2E thật trên Microsoft Edge 18/18 |
| [0.2.69](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.69) | Audit toàn bộ tính năng mới (R2-140…R2-153, DFMEA/DRBFM): đồng bộ 3 OS — dự đoán Mode EN, `Ctrl` đơn, tự học lưu được trên macOS/Linux · nhận diện terminal Windows/Linux (giữ Tab cho shell, không học mật khẩu) · Telex không còn phá code/Markdown (`arr[0]`, `--force`) · trợ lý không sửa oan 40 mẫu câu đúng · `peek_completion` 225 → 75 µs · savings-rate 22% |
| [0.2.68](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.68) | Âm vị học `sort` → `sỏt` khôi phục đúng · tiện ích Telex `[ ]`, `Ctrl`, `a--b` · dự đoán tiếng Anh 2 chế độ, từ ghép và mẫu câu Anh |
| [0.2.67](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.67) | P10 Dream RSI (G19): đo lường tiết kiệm phím (22% savings-rate trên corpus văn phòng) · Gate chống hồi quy `perf/baseline-win.json` · Chuẩn hoá `keys_typed` 3 OS · Hoàn thiện pipeline tự học P7 (IPC broadcast `ConfigReload`, opt-in consent G8, FFI `catch_unwind` an toàn) |
| [0.2.66](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.66) | Tự học P7 hoàn chỉnh qua phím thật (drain cap 200 từ/50 cặp, IPC merge, live reload) · P9 debounce 1s cho word-trigger · Dead-key armed disarm |
| [0.2.65](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.65) | Chuẩn UniKey vần uo ("luong"/"uong" plain, `luonwg`/`tuowi`/`tuowng`) · Hook swallow-and-unicode chống xung đột OS-IME (MobaXterm) · Dead-key Windows (`Ctrl+'`+`e`→`é`) · Chặn hoàn tất username/id (`truong.giap`) |
| [0.2.60–0.2.64](CHANGELOG.md) | Corpora 41.313 mục · 13 domain từ ghép mới · User Style Profile · Cảnh báo ngày vô lý (31/02) · Tối ưu hiệu năng tuyến tính O(n) |
| [0.2.50–0.2.59](CHANGELOG.md) | Ngữ pháp câu EN + SVA · Lặp cụm 2–4 từ · Chuyển mã thông minh Ctrl+Shift+F9 · Ghost preview 3 OS · Gõ tắt kiểu chữ |

---

## Trạng Thái & Hỗ Trợ Nền Tảng

| Nền tảng | Trạng thái phát hành |
|---|---|
| **Windows 10/11 x64 (TSF)** | ✅ Release candidate — gõ thật qua TSF được kiểm thử liên tục trong CI trên Windows (bộ cài, portable, MSIX cài thử). **Đã phát hành trên [Microsoft Store](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)** (gói MSIX chính thức). Ô tìm kiếm Start, Calculator, ứng dụng Store (sandbox AppContainer/LPAC) gõ theo đúng cấu hình và nút V/E (0.2.93, [sandbox-appcontainer.md](docs/specs/sandbox-appcontainer.md)). Chữ ký Authenticode trực tiếp đang chờ SignPath Foundation duyệt. |
| **macOS 13+ (Apple Silicon & Intel)** | ✅ Release candidate — bộ gõ IMK + app thanh menu + gói cài đặt `.pkg` per-user (không cần sudo); CI tự động build 2 kiến trúc (arm64 + x86_64) và chạy `swift test`. Chữ ký Apple Developer ID / Notarization đang chờ duyệt ([signing-status-mac.md](docs/release/signing-status-mac.md)). |
| **Linux (8 dòng distro · IBus / Fcitx5)** | ✅ Release candidate — một tarball đa distro duy nhất (`glibc ≥ 2.28`, tự chọn GTK 4 hoặc GTK 3, hỗ trợ KDE Fcitx5-only), cài đặt per-user / `--system` / portable live-register; CI kiểm thử E2E container thật trên toàn bộ **8 dòng distro** (RHEL 8.10 / AlmaLinux 8, RHEL 9 / AlmaLinux 9, SLES 15 / openSUSE Leap 15.6, Ubuntu 22.04 / Mint 21, Debian 12, Ubuntu 24.04, Fedora 41, Arch) + smoke container thật trên **Ubuntu 20.04 LTS** và **Debian 11** (ldd sạch, CLI chẩn đoán, cài/gỡ per-user). Phân phối thêm qua AUR (`paru -S textvn`) và PPA Ubuntu/Debian (`ppa:hunglinhpt/textvn`). |

Báo cáo kiểm thử chi tiết của bản phát hành: [build-release-report.md](docs/release/build-release-report.md).

---

## Dựng Từ Mã Nguồn

```powershell
# Windows: Cần Rust stable + Visual Studio 2022 Build Tools (C++) + Inno Setup 6.5+
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-release.ps1 -BuildInstaller -MachineInstaller
```

```bash
# macOS 13+: Cần Xcode Command Line Tools 15+, rustup target aarch64-apple-darwin & x86_64-apple-darwin
cd adapters/macos-imk
./build-rust.sh                   # Dựng engine FFI + Swift build + tạo TextVN-IM.app
./build-rust.sh --lib-only        # Chỉ dựng libtextvn_ffi.a (phục vụ swift test)
./build-rust.sh --release         # Dựng bản tối ưu phát hành

# Đóng gói phân phối macOS (chạy từ thư mục gốc)
scripts/build-macos.sh            # Đóng gói Universal zip
scripts/package-macos-pkg.sh      # Tạo file cài đặt .pkg per-user
```

```bash
# Linux (Ubuntu/Debian / Fedora / Arch)
scripts/install_linux.sh          # Dựng mã nguồn và cài đặt cho tài khoản hiện tại
scripts/build-linux.sh            # Tạo tarball phát hành hoàn chỉnh
```

Kiến trúc, kiểm thử, chuẩn mã và quy trình phát hành: xem **[Hướng dẫn phát triển](docs/developer-guide.md)** · Dọn `target/` & tối ưu Cargo dev/test ([Cargo.toml](Cargo.toml)): chạy `scripts/clean-target.ps1` (chi tiết trong [CONTRIBUTING.md](CONTRIBUTING.md)).

---

## Cấu Trúc Dự Án

```
core/              Engine xử lý ngữ âm cốt lõi (Rust) — không I/O, không phụ thuộc hệ điều hành
config/  ffi/      Đặc tả cấu hình config.v1 · C ABI và shim an toàn cho các adapter
adapters/          windows-tsf (TSF thuần) · windows-hook (gói tương thích ứng dụng legacy)
                   macos-imk (Input Method Kit) · macos-app (SwiftUI menu bar) · macos-tap
                   linux-ibus · linux-fcitx5 · linux-common · linux-settings (GTK4/GTK3)
tray/  cli/        Khay hệ thống & bảng cài đặt Windows · textvn-cli (đăng ký TSF, doctor, replay)
corpus/            Hơn 230 kịch bản gõ *.keys (shared · win · mac) chạy qua bộ mô phỏng adapter trong CI
installer/  packaging/  scripts/    Kịch bản đóng gói Inno Setup, MSIX, PKGBUILD, Homebrew Cask, Debian PPA
docs/              Tài liệu đặc tả kiến trúc (10-shared, 20-windows, 30-macos, 40-linux), specs, release
```

---

## Đóng Góp & Giấy Phép

- Đóng góp phát triển: xem [CONTRIBUTING.md](CONTRIBUTING.md) và [SECURITY.md](SECURITY.md).
- Khi báo lỗi gõ phím: vui lòng ghi rõ chuỗi phím đã bấm, kết quả thực tế, kết quả mong đợi, tên ứng dụng và phiên bản hệ điều hành.
- **Giấy phép**: [GPL-3.0-or-later](LICENSE) © 2026 LinhBH.CoM

---

# English

Tiếng Việt · English

[![License: GPL-3.0-or-later](https://img.shields.io/badge/License-GPL--3.0--or--later-blue.svg)](LICENSE)
[![CI Windows](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-windows.yml?branch=main&label=CI%20Windows)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-windows.yml?query=branch%3Amain)
[![CI Linux](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-linux.yml?branch=main&label=CI%20Linux)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-linux.yml?query=branch%3Amain)
[![CI macOS](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-macos.yml?branch=main&label=CI%20macOS)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-macos.yml?query=branch%3Amain)
[![CI engine (3 OS)](https://img.shields.io/github/actions/workflow/status/hunglinhpt/TextVN/ci-shared.yml?branch=main&label=CI%20engine%20%283%20OS%29)](https://github.com/hunglinhpt/TextVN/actions/workflows/ci-shared.yml?query=branch%3Amain)

[![Get TextVN on Microsoft Store](https://get.microsoft.com/images/en-us%20dark.svg)](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)

**TextVN** is a next-generation open-source Vietnamese input method built upon a single, unified **Rust** engine (strictly memory-safe, zero I/O inside core, zero panics across FFI via `catch_unwind`) shared across all three platforms: **Windows** (pure Text Services Framework), **macOS** (native Input Method Kit), and **Linux** (IBus & Fcitx5). TextVN delivers microsecond-level responsiveness, uncompromising phonotactic accuracy, and completely eliminates the classic flaws of legacy hook-based IMEs (lost keystrokes, duplicated letters, and preedit underlines), while integrating an on-device contextual bilingual prediction system and an intelligent offline grammar assistant.

---

## 4 Core Pillars of Excellence

### 1. Pure In-Process Architecture & Uncompromising Memory Safety
- **Pure Windows TSF (`ITfTextInputProcessorEx`)**: The default package installs no global keyboard hook to eat keys, injects no DLLs into foreign processes, and never simulates fake keys via `SendInput` backspace sequences ([architectural rationale](docs/specs/antivirus-false-positive.md)).
- **No Lost Keys, No Doubled Letters, No Preedit Underline**: The entire word remains inside an internal composition range without any underline (`TF_LS_NONE` on Windows TSF; non-preedit mode on macOS; no underline on Linux). Permanently eliminates key eating, character duplication, and caret jumping in Google Chrome, Microsoft Edge, Electron apps (VS Code, Slack, Discord), Microsoft Excel, browser address bars, and full-screen games.
- **Antivirus False-Positive Immunity**: Operates strictly within official OS IME architecture boundaries, complying with Microsoft Store certification standards and enterprise antivirus policies.

### 2. Contextual Bilingual Prediction & Dream RSI Ergonomics (P10)
- **53,962-entry Curated Bilingual Knowledge Base**: Includes 6,669 standard Vietnamese syllables, 1,941 Vietnamese compounds (`vn_compounds.txt`, 13 specialized domains), 3,346 high-frequency English words (`en_freq3000.txt`), 9,868 English single words (`en_words10k.txt`), 1,957 English compounds & collocations (`en_compounds.txt`, 16 modern domains: AI, Cloud, Dev, Finance, HR, Legal…), and 30,181 context→phrase pairs (8,792 Vietnamese in `vn_phrases.tsv`, 10,224 English in `en_phrases.tsv`, and 11,165 English workplace sentences in `en_office_phrases.tsv`).
- **Synchronous Dual-Mode Parity (Mode VI & Mode EN)**:
  - **Mode EN (`E`)**: Single-word & compound completion, next-phrase prediction, **chained suggestions with Tab** (the next phrase appears right after an accept), 5-candidate cycling with Ctrl+Space, and ultra-fast 75 µs ghost preview.
  - **Mode VI (`V`)**: Intelligent mixed English detection. Automatically rescues English words/phrases mistransformed by Telex rules when they do not form valid Vietnamese syllables (e.g., `customer` typed as `cútomer` + Tab → expands to `customer service`; `looking forward` typed as `looking fỏwad` + Tab → `looking forward to hearing from you soon`).
- **Standalone `Ctrl` Tap Utility**: Tap and release standalone `Ctrl` to lock valid syllables (`tunx` + Ctrl → commits `tũn`), or instantly restore mistyped Vietnamese words to their original English form (`sort` → `sỏt` + Ctrl → `sort`).
- **Dream RSI Ergonomic Measurement (P10 / G19)**: Objectively measures physical keystrokes saved. Delivers a 22% keystroke savings rate on realistic office corpora; strictly guarded against performance regressions via automated CI gates (`perf/baseline-win.json`).
- **User Style Profile (P7)**: Automatically learns personal vocabulary and accepted correction pairs, 100% offline **on this machine only**, **on by default** (never learns in password fields or terminals; never records keystrokes or sentences, G8). Switch it off/on, see the numbers and wipe the learned data right in the *Grammar Assistant* group of Settings (all 3 OSes), together with the cumulative **Dream RSI** figure (percentage of keystrokes saved by suggestions) across sessions.

### 3. On-Device Grammar & Context Assistant (Grammarly-Grade Offline)
- **Comprehensive 15-Category Issue Detection**: Detects word repeats, 2–4-word phrase repeats, punctuation spacing, sentence capitalization, misplaced tone marks ("nghiã" → "nghĩa"), **wrong tone marks via a built-in syllable dictionary ("chềt" → "chết", 99% of synthetic tone errors caught, 0% false positives on the clean corpus — no OS dictionary needed)**, double negatives, post-conjunction commas, English a/an articles, easily-confused English pairs, lowercase pronoun "i", English/Vietnamese spelling, calendar-aware invalid dates (31/02, 32/13), and inconsistent money grouping (1.250.00đ).
- **1-Second Idle Trigger Across All 3 OSes**: Pause typing for 1 second → assistant panel appears at the caret, with red underlines on errors and total issue count; resume typing → panel instantly dismisses without disrupting focus.
- **Two Flexible Operating Modes**: *Suggest-Only* (Mode 1) for unobtrusive assistance or *Safe Auto-Fix* (Mode 2) for automatic correction of clear-cut errors with a 1-step Ctrl+Z undo window for 5 seconds.
- **Zero False-Positive Standard (0% FPR)**: Verified 0 % false alarms on a curated benchmark of 981 Vietnamese and 295 English clean sentences ([P4-12 §11](docs/50-assist/P4-12-RECALL-REAL.md)).

### 4. 20-Year UniKey Heritage Standard & Modern Office Utilities
- **UniKey Standard Tone Placement**: Comprehensive support for Telex, VNI, VIQR, and Simple Telex; old-style (`hòa`, `thủy`) vs new-style (`hoà`, `thuỷ`) diacritics; standard `uo` rhyme (`luong`/`uong` plain by default, explicit `w` produces `ươ`).
- **Smart Telex Conveniences**: Fast `[` / `]` for `ơ` / `ư` with full protection for programming code brackets (`arr[0]`, Markdown `- [ ] task`); fast `a--b` for em-dash `a—b` while preserving CLI flags (`--force`); smart uppercase `DD` → `Đ`; dead-key passthrough (`Ctrl+'`+`e` → `é`).
- **Smart Transcoding Shortcut Ctrl+Shift+F9**: Lossless bidirectional conversion between Unicode, TCVN3, VNI, and decomposed Unicode; automatic source charset detection (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`); automatic retyping of mistyped text when the IME was off (`tooi ddi hocj` → `tôi đi học`) across all 3 platforms.
- **Unified 3-OS Settings Panel**: Every button features an icon + hint tooltip; explicit "Hide to tray" vs "Quit" options; the *Help ("Hướng dẫn")* dialog integrates **Thảo luận** (Discussions) and **Báo lỗi** (Report Issue → issue tracker `https://github.com/hunglinhpt/TextVN/issues`); tray automatically self-registers TSF without requiring administrator privileges (Admin/UAC).

---

## Highlights Over Traditional Vietnamese IMEs

Direct head-to-head comparison between TextVN and legacy input engines (UniKey, EVKey, OpenKey):

| Comparison Criteria | TextVN (v0.2.89) | Traditional IMEs (UniKey / EVKey / OpenKey) |
|---|---|---|
| **Input Processing Engine** | In-process TSF (Windows), native IMK (macOS), IBus/Fcitx5 (Linux) | Global keyboard hook + `SendInput` backspace replay |
| **Lost & Duplicated Letters (Chrome/Excel/Electron/Dual-Mode)** | **Completely eliminated** (clean composition, no underline; `INJECT_TAG` + `KeyOrigin` prevents synthetic loops and preserves `"TextVN"`) | Common occurrence during rapid typing, mixed-case English words, or window switching |
| **X11/SSH Terminal & Non-Text Isolation** | Automatically yields TSF by child exe & window class (`MoTTY`, `PuTTY`, `mintty`, `XWin*`), checks `EMPTYCONTEXT`/`READONLY` — **no `(0,0)` green-arrow popup** | Conflicts with OS/X11 IME sub-systems or breaks Explorer type-ahead |
| **Automatic EN/VI Detection in Mixed Text** | Vietnamese phonotactics + 103 confused words + 116 terms + personal dictionary + 94-syllable protection grid: restored on Space | Telex applies indiscriminately — `text` becomes `tẽt`, `is` becomes `í`; requires manual toggle |
| **Bilingual Word & Phrase Prediction (Tab/Space)** | Full single-word, compound, and contextual phrase prediction in both Mode VI & Mode EN; chained suggestions with Tab; 5 candidates with Ctrl+Space; 75 µs ghost preview | Not supported or limited to static text macros |
| **Dream RSI Ergonomics (P10)** | Objectively measures physical keystrokes saved (22% savings rate on office workloads); CI regression gates | Not supported |
| **On-Device Grammar & Spell Assistant** | 15 issue types (word repeats, spacing, caps, misplaced tones, a/an, dates, money); 1s idle popup on 3 OSes; 0% FPR; Ctrl+Z 5s | Not supported |
| **Standalone Ctrl Tap Restore** | `tunx` + Ctrl → `tũn` (syllable lock); `sort` → `sỏt` + Ctrl → `sort` (phonotactic restore) | Not supported |
| **Raw Keystroke Restore (Escape)** | Pressing Escape immediately restores raw original keystrokes | Not supported or limited to full-sentence deletion |
| **Global Mode Toggle (Ctrl+Shift)** | Observer-only modifier tap detector + debounce prevents double-toggling between tray and engine | Prone to double-toggle glitches or antivirus interception |
| **Coding & Markdown Conveniences** | Smart `[` `]` for `ơ`/`ư` (protects `arr[0]`); `a--b` for `a—b` (protects `--flag`); `DD` → `Đ` | Blind transformation corrupts source code and Markdown syntax |
| **Smart Transcoding (Ctrl+Shift+F9)** | Auto-detects broken charsets (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`), fixes text typed with IME off (`tooi ddi hocj` → `tôi đi học`) | Basic manual clipboard transcoding only |
| **Installation Permissions & UAC** | Per-user HKCU, portable extract-and-run, zero Admin/UAC required | Mostly requires Admin privileges or Program Files installer |
| **Ghost Registration Auto-Repair** | Automatically repairs registry paths when the executable folder is moved | Crashes, fails silently, or requires manual reinstall |
| **Privacy Policy & Telemetry (G8)** | **100% Offline**, zero keylogging, zero telemetry; auto-off in password fields; transparent open-source code | Many closed-source tools lack clear, verifiable privacy audits |

---

## Full Feature Set (Accumulated Through 0.2.90)

### 0. Universal Scientific, Engineering & Math Engine (new in 0.2.83 — `textvn-math` crate)
- **Multi-layer chord FSM**: one-shot Leader-Key (`` ` `` in Math Mode), deterministic priority chain, double-leader escape, timeout/OnKillFocus reset, mnemonic Greek + structure map (`/ \frac{}{}`, `q \sqrt{}`, `i \int`, `S \sum`, `8 ∞` …) with exact `cursor_left_steps` per output mode.
- **Smart Formula Clipboard**: auto-detects formulas in the clipboard (anti-false-positive: paths, `$50`, URLs, JSON, prose), bidirectional LaTeX ↔ Presentation MathML (Word/MathType) ↔ Unicode ↔ Typst conversion, latest-wins worker that never blocks the UI/TSF thread, honors OS privacy markers.
- **6-discipline lexicon + Vietnamese aliases** (`\can`, `\phanso`, `\tichphan`, `\ohm` …), **parametric templates** (`\mat3x3`, `\hpt2`), **safe inline evaluator** `= expr =`, **auto-bypass** inside `$...$`/`\text{...}` and code tokens (`0xFF`, `CAN_FD`).
- Full bilingual guide: [docs/MATH_SCIENCE_GUIDE.md](docs/MATH_SCIENCE_GUIDE.md).

### 1. Dream RSI Ergonomic Metrics & Performance Benchmarks (P10 / G19)
- Integrated Dream RSI ergonomic measurement: 4 core metrics (`keys_typed`, `accepts`, `chars_saved`, `savings_rate_pct`).
- Real-time keystroke reduction analysis: achieves a 22% keystroke savings rate on realistic office workloads (36 accepts / 72 keys saved on benchmark corpus).
- 6 prediction accept pathways: Vietnamese word completion, English/style completion, Space-accept, candidate cycling, multi-word next-phrase prediction, and chained suggestions (Tab right after an accept — R2-173).
- Automated CI anti-regression gate: all prediction improvements must maintain or increase the keystroke savings rate against the baseline (`perf/baseline-win.json`).

### 2. Contextual Prediction Model P6 & User Style Profile P7 (53,952-Entry Corpora)
- **Curated 53,952-entry knowledge base** with complete bilingual parity:
  - 6,669 standard Vietnamese syllables + 1,941 Vietnamese compounds (`vn_compounds.txt`, 13 specialized domains).
  - 3,346 high-frequency English words (`en_freq3000.txt`) + 9,868 English general vocabulary (`en_words10k.txt`) + 1,957 English compounds & collocations (`en_compounds.txt`, 16 modern domains).
  - 30,181 context→phrase pairs (8,792 Vietnamese rows in `vn_phrases.tsv` + 10,224 English rows in `en_phrases.tsv` + 11,165 English workplace rows in `en_office_phrases.tsv` — real sentences split at all word boundaries, idioms, role-based workplace patterns: upward reporting, downward management, tech, business ops & Viet-Eng code-switching).
- Seamless dual-mode operation:
  - **Mode EN (`E`)**: Single-word and compound completion, chained suggestions with Tab, 5-candidate cycling with Ctrl+Space, next-phrase prediction, 75 µs ghost text preview, Dream RSI personal learning.
  - **Mode VI (`V`)**: Automatic English word and phrase detection even when Telex-folded (e.g., `customer` → `cútomer` + Tab → `customer service`; `looking forward` → `looking fỏwad` + Tab → `looking forward to hearing from you soon`).
- **User Style Profile (P7)**: Personal vocabulary and correction pair learning, on by default (switch off / wipe in Settings), 100% offline, safe memory cap (200 words / 50 pairs); shows cumulative Dream RSI.
- Microsecond lookups via Trie + Frecency structures, meaningful-extension contextual ranking.

### 3. Typing Engines & Phonotactic Transformation Standard
- 20-year UniKey-standard `uo` rhyme: `luong`/`uong`/`truong.giap` remain unaccented by default; only explicit `w` or tone keys produce `ươ` (`luonwg`, `tuowi`, `tuowng`, `duongf` → `dường`).
- Dual-IME anti-conflict & Terminal isolation (E46/E49): yields TSF on both child processes (`MoTTY.exe`, `XWin_MobaX.exe`, `XWin*`, `vcxsrv.exe`, `Xming.exe`) and terminal/X11 window classes (`MoTTY`, `PuTTY`, `mintty`, `KiTTY`, `MSCTFIME UI`, `cygwin/x*`), guards `EMPTYCONTEXT`/`KEYBOARD_DISABLED`/`READONLY` contexts, and cleans composition on focus switches — eliminating `(0,0)` popup artifacts; in hook-backed apps, exact `LLKHF_INJECTED` + `INJECT_TAG` (`KeyOrigin`), `auto_capped` guards, and effective undo-key stripping (`fold_effective_caps` + locked identifier protection E50) keep `"TextVN"` and quick undo sequences like `"TexxtVN"` free of duplication and case loss (E48/E50).
- Windows dead-key passthrough (`Ctrl+'`+`e` → `é`) on international keyboard layouts.
- Identifier & username boundary gate: Space and Tab never complete across dots, dashes, or email addresses (`truong.giap`, `t.ho`).
- Full support for Telex, VNI, TCVN3 (VIQR readable), Quick Telex (cc→ch, gg→gi…), free marking.
- 3 output character sets: Pre-composed Unicode, TCVN3, VNI (+ decomposed Unicode) with lossless round-trip transcoding.
- Old vs new diacritic style options (`hoà`/`hòa`, `thuỷ`/`thủy`) — all prediction datasets automatically adjust to the selected style.
- Smart capitalization: `DD` → `Đ`, per-key Caps Lock/Shift, auto-capitalize sentence starts (optional).
- Escape key immediately restores raw original keystrokes at any point.
- Anti-key-loop protection (E28): repeated tone keys never produce infinite cycles across Telex, VNI, and VIQR.
- Text macros with case style awareness (HD → HỢP ĐỒNG), functional even when Vietnamese typing is toggled off.
- **Ultra-lightweight OS / MS Teams / iOS-style Emoji Picker (`Ctrl+Alt+E`) & inline `:shortcode:` expansion (P12)**: ~280 familiar emojis across 8 categories (MRU Recent + 7 tabs), diacritic-insensitive bilingual Vietnamese/English search (`cười`/`cuoi`/`fire`/`tim`), instant `:smile:`, `:fire:`, `:camon:` expansion in both Telex and EN modes (auto-blocked in passwords, terminals, URLs, and math spans); native color-emoji rendering with Direct2D/DirectWrite (Windows, non-activating), Apple Color Emoji `NSPanel` (macOS), and `IBusLookupTable`/`CommonCandidateList` (Linux X11 + Wayland).
- **Universal Math & Science across every editor (`Ctrl+Shift+M` / `Ctrl+Alt+M`, [MATH_SCIENCE_GUIDE.md](docs/MATH_SCIENCE_GUIDE.md))**: works immediately upon enabling in Notepad, Word, VS Code, Overleaf, Chrome, Teams, and terminals (both VI and EN modes) — leader chords (`` `a ``→`α`, `` `/ ``→`\frac{}{}` with automatic caret placement inside `{}`, superscript/subscript chains `x²`/`xⁿ`/`x⁻¹`/`H₂SO₄`/`SO₄²⁻`/`aₙ` right in Normal mode), math/physics/chemistry aliases (`\can`, `\voimoi`, `\in`, `\infty`, `\h2o`, `\h2so4`, `\Fe2+`), clean precision quick-calc `=0.1+0.2=`→`0.3` (lone `=` in prose never blocks Telex), automatic Vietnamese suspension inside `$...$`/`\(...\)`/math environments `\begin{align*}` while keeping Vietnamese active in `\begin{document}`/`\section{...}`/`\text{...}`/`\intertext{...}`.
- `=1.550.00đ` currency to Vietnamese words; Excel formula and programming identifier protection.

### 4. On-Device Grammar & Context Assistant
- 15 issue types: word repeats, 2–4-word phrase repeats, punctuation spacing, sentence-case, diacritic typos, double negatives, end-of-sentence commas, post-conjunction commas, a/an articles, easily-confused English words, lowercase pronoun "i", English spelling (OS spell), Vietnamese spelling (built-in syllable dictionary), impossible dates (31/02, 32/13), inconsistent money grouping (1.250.00đ).
- Suggestion panel on **1-second typing pause** across all 3 platforms: every keystroke/punctuation/backspace resets the timer, typing resumes hides it immediately, only a full 1-second pause checks the word + sentence and displays the panel (suggestion and safe auto-fix modes alike, including after `.` `,`); mid-word display is supported on Windows (Linux/macOS wait for the word to be finalized).
- Mouse-clickable UI, Alt+1…3 shortcuts, Enter to apply "Fix All".
- Mode 1 suggest-only / Mode 2 safe auto-fix with a 5-second Ctrl+Z undo window.
- Selection checking (Shift+arrow keys → popup + Fix All) and long-sentence checks.
- Per-application disable list; auto-off in password fields; verified 0% false alarms (FPR) on 2,739 clean benchmark sentences.

### 5. Smart Transcoding & Office Utilities (P5)
- Ctrl+Shift+F9 selection transcoding: converts TCVN3/VNI/decomposed Unicode → Pre-composed Unicode with automatic source charset detection (`Tiáº¿ng Viá»‡t` → `Tiếng Việt`), re-types text typed with IME off (`tooi ddi hocj` → `tôi đi học`) across all 3 platforms.
- Smart English restore: Vietnamese phonotactics + 103 confused English words + 116 technical terms + personal dictionary.
- Protection mechanisms: camelCase identifiers, quoted strings preserved verbatim.

### 6. System Architecture, Control & Total Privacy
- Hotkeys: Ctrl+Space fix/predict · Ctrl+Shift VI/EN toggle (state remembered) · Ctrl+Shift+F9 transcode.
- Native settings per OS: Windows system tray (7 buttons with icons + tooltips, explicit Hide to tray / Quit, plus prominent **[Chẩn đoán & xuất log]** and **[Cài & bật TSF]** Command Links inside *Help ("Hướng dẫn")*), Linux auto-selected GTK4/GTK3, macOS SwiftUI menu bar; the **Help ("Hướng dẫn")** dialog on all 3 OSes embeds a prominent 1-click **[Chẩn đoán & xuất log]** (*diagnose & export log*, PII-redacted, zero keylogging per G8/S2), **Math & Science**, **Thảo luận** (Discussions, `https://github.com/hunglinhpt/TextVN/discussions`), and **Báo lỗi** (Report Issue, `https://github.com/hunglinhpt/TextVN/issues`).
- 100% offline, zero telemetry, no network calls; auto-off in password fields; public in-repo privacy policy.
- **1-click, privacy-safe diagnostics & support (E69/E70)**: `textvn-cli --check-env` / `--diagnose` / `--export-log` (Linux: `textvn …`), a prominent **[Chẩn đoán & xuất log]** (*diagnose & export log*) button at the top of *Help* on all 3 OSes and directly at the top level of the Windows tray / macOS menu bar with **[Mở thư mục tệp ZIP]** (*open ZIP folder*, macOS reveals the file in Finder), **[Copy tóm tắt lỗi]** (*copy error summary*, user name redacted) + **[Mở trang báo lỗi]** (*open bug-report page*); the ZIP carries `git_sha`, target and distribution type (installer/portable/store), and `panic.log` records only source locations & backtrace symbols (never dynamic messages); automatic detection of UniKey/EVKey/OpenKey/GoTiengViet/VietKey, **Microsoft Vietnamese Telex/VNI**, **Apple Vietnamese** and `ibus-unikey`/`bamboo`/`fcitx5-unikey`/dual-daemon conflicts with exact exit steps — see **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**.

---

## Download & Installation

Latest release: **[GitHub Release v0.2.93](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.93)** — **Suggestion after suggestion: accept a suggestion with Tab and the next phrase appears at once as ghost text, Tab accepts it too as a chain (`phát`+Tab+Tab → `phát triển phần mềm`; Ctrl+Space picks another candidate) — the ghost text is always exactly what Tab inserts, Space after an accept keeps suggesting, greetings/wishes/office phrases gained continuations; Windows: the Start search box, Calculator and Store apps (AppContainer/LPAC sandbox) follow your input method and the V/E toggle via a filtered configuration copy + a restricted sandbox pipe, tested with real AppContainer and LPAC processes** (release candidate built and tested automatically by CI: `cargo xtask preflight` 25/25 steps, all workspace tests pass 100%, perf gate green, Dream RSI 22% unchanged, clippy `-D warnings` clean on Windows + Linux). **Every release artifact carries a GPG signature (`.asc`) and a Sigstore signature (`.cosign.sig` + `.cosign.cert`)**; `SHA256SUMS.txt` is clear-signed — verification guide: [signing.md](docs/release/signing.md). *Note: Windows installers are not yet Authenticode-signed (awaiting SignPath Foundation approval) and macOS bundles are not yet notarized ([signing-status-mac.md](docs/release/signing-status-mac.md)).*

| Platform | Official Installer | Run Without Installing (Portable) |
|---|---|---|
| **Windows 10/11 x64 (Home / Pro / Enterprise / LTSC)** | `TextVN-setup-<ver>-windows-x64.exe` (current user, no admin/UAC required)<br>`TextVN-setup-<ver>-windows-x64-machine.exe` (all users, Program Files, one UAC prompt — recommended for Windows 10/11 Enterprise) | `TextVN-portable-<ver>-windows-x64-*.zip` → extract and run `TextVN.exe` directly (full Win10 1507–22H2 & Win11 21H2–24H2 compatibility; includes **[Cài & bật TSF]** inside Help) |
| **Windows Microsoft Store** | ✅ **[TextVN on Microsoft Store](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)** (free, Store ID `9NV2R7JNNFGK`) — automatic updates, package verified and signed by Microsoft. CLI: `winget install --id 9NV2R7JNNFGK -s msstore`. *(The `.msix` file on GitHub Release is the unsigned Store submission package)* | — |
| **macOS 13+ (Apple Silicon & Intel)** | **Homebrew (recommended): `brew install --cask hunglinhpt/tap/textvn`** — installs input method to `~/Library/Input Methods` and menu bar app to `/Applications`; updates via `brew upgrade`.<br>Or use the `TextVN-mac-v<ver>.pkg` installer (per-user installation, no root/sudo required) | `TextVN-macos-universal-v<ver>.zip` (universal binary with `TextVN-IM.app` + `TextVN.app`) — see [macOS User Guide](docs/user-guide.md) |
| **Linux (8 Enterprise & Mainstream Distro Families · IBus / Fcitx5)** | **Single universal tarball** (`glibc ≥ 2.28`, auto-selects GTK 4 / GTK 3, KDE Fcitx5-only ready): `tar xzf TextVN-<ver>-linux-x86_64.tar.gz` → `./install.sh` (per-user) or `sudo ./install.sh --system` (recommended on RHEL 8/9, SLES 15 Enterprise).<br>**Arch Linux (AUR)**: `paru -S textvn` · **Ubuntu/Debian PPA**: `ppa:hunglinhpt/textvn` | Run directly from extracted tarball: `./textvn-portable.sh` (supports GNOME Wayland live-register without restarting `ibus-daemon`) |

Full installation, uninstallation, usage instructions and troubleshooting: **[User Guide](docs/user-guide.md)** · error-code table, IME conflicts, per-distro dependencies, enterprise/portable notes: **[TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)**.

> [!NOTE]
> **Windows 11 (23H2/24H2+ & Enterprise) Note**: Recent Windows 11 updates or Enterprise policies may refuse to activate input methods registered solely in per-user scope (issues B7 / E65). TextVN's per-user installer and portable package **never prompt for UAC** — if Vietnamese input does not activate, open **Control Panel → [Hướng dẫn] → [Cài & bật TSF]** to re-register and view exact diagnostics (`register.log`), or install the `-machine.exe` installer (Program Files, one-time HKLM registration).

---

## Recent Release Highlights

Full development history: [CHANGELOG.md](CHANGELOG.md).

| Version | Key Highlights |
|---|---|
| [0.2.93](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.93) | **Suggestion after suggestion (R2-173) + Start search/Store apps follow your settings (R2-26)**: after a Tab accept, a continuation keyed by ≥ 2 words shows as ghost text at once and Tab accepts it too (`Kính gửi`+Tab+Tab → `Kính gửi quý khách hàng tiềm năng`), one-word keys still cycle, Ctrl+Space always cycles; the "ghost text = exactly what Tab inserts" invariant is tested on Mode VI + EN; Dream RSI counts each phrase correctly; Windows draws the ghost text after Space on key-up (E79); added `xin chào`/`chúc bạn`/`phát sinh` continuations. Windows sandbox: a copy in `%APPDATA%\TextVN\sandbox\` (protected DACL, allow-list — no macros/emoji/added words/learned words), a Low-label sandbox pipe that only allows reading state + Ctrl+Shift + Dream RSI counters, never reveals other apps' overrides, capped at 32 connections · 40 frames/s; `textvn-cli doctor` `Sandbox` line/`W_SANDBOX_MIRROR`; tests run real AppContainer + LPAC processes ([sandbox-appcontainer.md](docs/specs/sandbox-appcontainer.md)). |
| [0.2.92](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.92) | **Linux robustness audited against Ngó Sen · OpenKey · ibus-bamboo · x-unikey + 10 more IMEs (R2-165…R2-172)**: shared `lc_edit_batch` for IBus/Fcitx5 — every key sends ≤ 1 delete + 1 commit (text-input-v3/mutter keep only the last edit; the grammar auto-fix used to lose words and over-delete on GNOME Wayland); commit first → hide preedit after (ibus-bamboo #574 repeated last word after Enter); Math `Left` press + release + real keycode, `W_MUTTER_FORWARD_KEY_BUG`; engine: glued digits keep the keys (`Sose2026`), vowel `oo` closes only with `ng`/`c` (`booots` → `boots`, `Thoòng`/`voọc` kept), `dz` onset; auto-capitalize after Enter even when GTK resets (fcitx5-lotus #597); `Đắk Lắk`, `Krông Búk` type (xkey #135); 423/423 common words match, x-unikey differs on `huơ`; known Linux limitations in [TROUBLESHOOTING](docs/TROUBLESHOOTING.md), full report [P3-8](docs/40-linux/P3-8-COMPETITOR-BUG-AUDIT-2026-11.md). |
| [0.2.91](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.91) | **Prominent 1-Click Diagnose & Export Log across 3 OSes (Help Popup + Top-Level Tray Menus)**: Windows upgrades *Help ("Hướng dẫn TextVN")* to vertical Command Links (`TDF_USE_COMMAND_LINKS \| TDF_SIZE_TO_CONTENT`, placing **[Chẩn đoán & xuất log]** at #1 above **[Cài & bật TSF]**, zero DPI clipping) + **[Mở thư mục tệp ZIP]** (`explorer /select`); Linux GTK4/GTK3 adds a dedicated top `suggested-action` row + inline findings + **[Mở thư mục tệp ZIP]**; promotes **Chẩn đoán & xuất log...** to top level of the Windows tray menu, macOS menu bar, and Linux IBus/Fcitx5 indicator menus (`textvn-settings --diagnose`) · preflight 25/25, Dream RSI 22%, 7/7 CI workflows green |
| [0.2.90](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.90) | **E70 3-OS Diagnostics & Conflicts · 0.2.83 Perf Regression Fix**: privacy-safe `panic.log` (location + backtrace symbols, never dynamic messages) for tray/CLI/hook; detects Microsoft Vietnamese Telex/VNI (`W_CONFLICT_VI_TIP`) & Apple Vietnamese (`W_CONFLICT_APPLE_VI_IM`); `--check-env`/`--diagnose`/`--export-log`; `version.json` with `git_sha`/target/distribution; Windows tray startup conflict notice + *Health › Export diagnostic log* + **[Copy tóm tắt lỗi]**; `parse_config` 10.4 → 2.17 µs, case-insensitive protected Math hotkeys; Ubuntu 20.04 / Debian 11 smoke; [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) · preflight 25/25, 2272 tests, Dream RSI unchanged |
| [0.2.89](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.89) | **E69 Automatic Linux Dependency Installer (`ibus`/`fcitx5`/`gtk`) · 3-OS Conflicting IME Detector · 1-Click Diagnostic Export**: auto-detects `apt`/`dnf`/`yum`/`zypper`/`pacman` to install missing packages & re-verify ABI (`--install-deps` or interactive `[Y/n]`); detects conflicting IMEs with explicit error codes & exit commands on Linux (`ibus-daemon`+`fcitx5`, `fcitx` v4/`xvnkb`, `ibus-unikey`/`bamboo`, `fcitx5-unikey`, `GTK_IM_MODULE` mismatch), Windows (`UniKey`/`EVKey`/`OpenKey`/`GoTiengViet`/`VietKey`), and macOS; `textvn doctor --report` / `--export auto` (`report_summary.md`, `install-diag.log`, `register.log`, PII-redacted) + 1-click **[Xuất log chẩn đoán]** button in Help across all 3 OSes · 57 `cli` tests, 88 `tray` tests, `unit_e69_deps_conflicts_diag`, Dream RSI 22%, 7/7 CI workflows green |
| [0.2.88](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.88) | **E65 Win11 Enterprise Portable + `[Cài & bật TSF]` · E66 Full Win10/11 · E67 RHEL 8.10 · E68 8-Distro Enterprise Linux**: fixed non-admin TSF registration & added `[Cài & bật TSF]` with `register.log` inside Help; dynamically loaded DPI APIs & lazy-loaded D2D1/DWrite/DWM across all Win10 (1507–22H2) & Win11 (21H2–24H2) installer/portable builds; single universal Linux tarball (dual-baseline EL8 `glibc 2.28` + GTK 3 & Ubuntu 22.04 `glibc 2.35`/`GLIBCXX 3.4.30` + GTK 4 + Fcitx5 5.0) supporting KDE Fcitx5-only, KWin Wayland protection, X11/LightDM `~/.xprofile`, GNOME Wayland live-register, SELinux `restorecon`, Linux `textvn doctor` · Real E2E verified on all 8 distro families (RHEL 8/9, SLES 15, Ubuntu 22.04/24.04, Debian 12, Fedora 41, Arch), Dream RSI 22%, 7/7 CI workflows green |
| [0.2.87](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.87) | **E61 UniKey Undo · E62 Universal Math · P12 Native Emoji Picker · E63 4-Expert Audit · E64 Ubuntu 22.04 Terminal/IBus Hardening**: fixed UniKey repeat-key undo (`Sirr`→`Sir`, `Eulerr`→`Euler`); universal Math & Science across all editors on 3 OSes (`cursor_left`, sup/sub chains `xⁿ`/`SO₄²⁻`, LaTeX/Typst, IEEE-754 clean calc); ultra-lightweight native Emoji Picker `Ctrl+Alt+E` + `:shortcode:`; Ubuntu 22.04 GNOME Wayland terminal protection & `ibus-unikey` coexistence · 942 `textvn-math` tests, Dream RSI 22%, 7/7 CI workflows green |
| [0.2.86](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.86) | **E59 Zero-Python Native & 3-pass rolling audit**: ported all 18 Python scripts to zero-dependency `cargo xtask` (pure-std Rust) + `e2e_fcitx5.c` (C/libdbus), added `no-python`/`check-en-office` gates; hardened DEFLATE/ZIP64 against zip-bombs, XML 1.0 namespaces, PE32/PE32+ delay-load imports & optional `dbus-1` CMake gating · Converged to 0 defects, 91 `xtask` tests, 7/7 CI workflows green |
| [0.2.85](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.85) | **Rolling audit fully closes the Math Engine**: E57 (word-buffer/boundary synced with Backspace/caret/HOME/END through the core hook, delete_chars off-by-one, `=expr=` recognized as a command, failed eval closes the span), E58 (22 real bugs under `#[ignore]`: AST `}`/`\frac{}{}`, evaluator pi/e/right-assoc `^`/unary minus, classifier LaTeX/MathML floors + Unicode sub/sup ranges, lexicon at 1504 entries) + un-ignored 560 `si_group!` tests — 927 math tests, 0 ignored · Tests: 75 workspace suites pass 100%, clippy stable+nightly 0 warnings, CI green on all 5 workflows |
| [0.2.84](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.84) | **Thorough audit-fix loop**: E55 (keys_typed double-count on math pass-through + state reset when toggle OFF), E56 (FCA expanding aliases/templates/inline-eval at boundaries via a real word_buf), R2-162 (unused-dep cleanup, 0 manifest warnings on all 4 targets), R2-163 (close the ci-macos parity gap: add `math/**`), needless_bool for CI clippy 1.100 · Tests: 73 workspace suites pass 100%, clippy 0 warnings on Linux+windows-msvc+darwin, CI green on all 5 workflows |
| [0.2.83](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.83) | **Universal Scientific, Engineering & Math Engine (`textvn-math` crate)**: multi-layer chord FSM, smart formula clipboard (LaTeX↔Presentation MathML↔Unicode↔Typst, anti-false-positive, honors privacy markers), 6-discipline lexicon + Vietnamese aliases, parametric templates, inline evaluator, auto-bypass in `$...$`/`\text{...}`/code tokens · Tests: 347 pass in `textvn-math`, 71 workspace suites · Guide: `docs/MATH_SCIENCE_GUIDE.md` |
| [0.2.82](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.82) | **E50 audit complete**: adds 6 edge-case tests verifying "skip Unikey rule after auto-restore" has no regressions (consecutive EN restores, typing without space, Vietnamese after restore, Unikey `dd`→`đ`, no restore when unneeded) · Test file: `core/tests/e50_audit_edge.rs` |
| [0.2.81](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.81) | **E50 fixed thoroughly**: the "typing đất → đata, space → ddat / Task space → Tassk" bug was caused by the `restored` flag in Word being cleared immediately by `clear()` — moved to `Engine::last_word_was_restored`, skip Unikey rule after auto-restore to preserve long-time Unikey user habits · 4 regression tests in `e50_unikey_restore.rs` |
| [0.2.79](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.79) | Windows: yields TSF by both MobaXterm child executables (`MoTTY.exe`, `XWin*`, `vcxsrv`, `Xming`) and X11/TTY window classes plus `EMPTYCONTEXT`/`READONLY` guards before `KeyEditSession` (E49); fixes `"TextVN" → "Texxtvn"` duplication & case loss via `LLKHF_INJECTED` + `INJECT_TAG`/`KeyOrigin` and `auto_capped` guard (E48) · Moves **Thảo luận** & **Báo lỗi** (`GitHub Discussions`) buttons inside the Help (*Hướng dẫn*) window across all 3 OSes · Adds **1,447** regression tests |
| [0.2.78](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.78) | Fixes mid-word Backspace leaking synthetic keystrokes on Space/ESC raw restore (E47) · Adds 7,913+ regression test cases (dual-mode matrix, rapid origin/case, TSF state) |
| [0.2.77](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.77) | Windows: MobaXterm (and PuTTY, mintty, Xshell, SecureCRT…) and the taskbar **no longer pop the small green-arrow box in the top-left corner** when you click in and type (after installing: sign out and back in so explorer loads the new build) |
| [0.2.76](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.76) | Settings: the hint under the Grammar Assistant **Mode** box is now a short **single line** on all 3 OSes |
| [0.2.75](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.75) | Windows: clicking a folder (Explorer) or any non-input area and then typing **no longer pops a small box in the top-left corner of the screen**; keys reach the app (type-to-jump works) · text inputs unaffected · Grammar Assistant has a **single** Mode choice ("Auto-fix" dropdown removed), UI reordered |
| [0.2.74](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.74) | **Self-learning & Dream RSI are on by default** and have a switch in Settings (all 3 OSes): toggle, live "Learned: N words · M pairs | Dream RSI: X% keystrokes saved", a Wipe learned data button; Dream RSI persists across sessions · junk typing is not learned · never learns in password fields/terminals |
| [0.2.73](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.73) | Grammar assistant **catches wrong tone marks** ("chềt" → "chết") with a built-in syllable dictionary on all 3 OSes — no OS dictionary needed, 99% of synthetic tone errors caught, 0% false positives on the clean corpus; "Fix all" skips ambiguous suggestions · leftover reduplication false positives fixed |
| [0.2.72](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.72) | Control panel: all buttons equipped with **icons + hint tooltips** (all 3 OSes); Windows renames to **"Hide to tray"/"Quit"** to prevent accidental exits, drops the "Install & enable TSF" button (tray registers automatically) · Complete README overhaul matching actual capabilities |
| [0.2.71](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.71) | Linux (IBus/Fcitx5) and macOS: assistant suggestion list **appears on 1-second typing pause**, dismisses on typing — 100% parity with Windows 0.2.70; sentence-ending keys auto-fix instantly in safe mode |
| [0.2.70](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.70) | Windows: grammar assistant panel **re-appears on 1-second typing pause** (including mid-word, after punctuation; suggestion and safe modes) · "Fix All"/Alt+1…3 mid-word no longer splits words · Real-world E2E Edge 18/18 tests |
| [0.2.69](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.69) | Full audit of new features (R2-140…R2-153, DFMEA/DRBFM): 3-OS parity — Mode EN prediction, standalone `Ctrl`, persisted self-learning on macOS/Linux · terminal detection (Tab preserved for shell, passwords unlearned) · Telex code/Markdown safety (`arr[0]`, `--force`) · 0 false flags on 40 clean patterns · `peek_completion` 225 → 75 µs · 22% savings rate |
| [0.2.68](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.68) | Phonotactic restore `sort` → `sỏt` fixed · Telex conveniences `[ ]`, `Ctrl`, `a--b` · English prediction in both modes, English compounds and phrases |
| [0.2.67](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.67) | P10 Dream RSI (G19): keystroke savings measurement (22% savings rate on office corpus) · Anti-regression gate in `perf/baseline-win.json` · Normalized 3-OS `keys_typed` · Completed P7 self-learning pipeline (IPC broadcast `ConfigReload`, opt-in consent G8, safe FFI `catch_unwind`) |
| [0.2.66](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.66) | Full P7 self-learning from real keystrokes (drain cap 200 words / 50 pairs, IPC merge, live reload) · P9 1s debounce on word triggers · Dead-key armed disarm |
| [0.2.65](https://github.com/hunglinhpt/TextVN/releases/tag/v0.2.65) | UniKey-standard `uo` rhyme (`luong` plain, `luonwg`/`tuowng`) · Hook swallow-and-unicode fixes OS-IME conflict (MobaXterm) · Windows dead-key restored · Username/ID punctuation gate |
| [0.2.60–0.2.64](CHANGELOG.md) | 41,313-entry corpora · 13 new compound domains · User Style Profile · Impossible-date warnings (31/02) · Linear O(n) performance optimizations |
| [0.2.50–0.2.59](CHANGELOG.md) | Full EN grammar + SVA · 2–4-word phrase repeats · Smart Ctrl+Shift+F9 transcoding · 3-OS ghost preview · Case-aware text macros |

---

## Platform Support & Status

| Platform | Release Status |
|---|---|
| **Windows 10/11 x64 (TSF)** | ✅ Release candidate — real TSF typing is CI-verified on Windows (installer, portable, MSIX trial install). **Officially published on the [Microsoft Store](https://apps.microsoft.com/store/detail/9NV2R7JNNFGK?cid=DevShareMCLPCB)** (MSIX package). The Start search box, Calculator and Store apps (AppContainer/LPAC sandbox) follow your settings and the V/E toggle (0.2.93, [sandbox-appcontainer.md](docs/specs/sandbox-appcontainer.md)). Direct Authenticode signature awaiting SignPath Foundation approval. |
| **macOS 13+ (Apple Silicon & Intel)** | ✅ Release candidate — IMK input method + menu bar app + per-user `.pkg` installer (no sudo); CI automatically builds both architectures (arm64 + x86_64) and runs `swift test`. Apple Developer ID / Notarization awaiting review ([signing-status-mac.md](docs/release/signing-status-mac.md)). |
| **Linux (8 Distro Families · IBus / Fcitx5)** | ✅ Release candidate — single universal multi-distro tarball (`glibc ≥ 2.28`, auto-selects GTK 4 or GTK 3, KDE Fcitx5-only ready), supports per-user / `--system` / portable live-register; real container E2E verified in CI across all **8 distro families** (RHEL 8.10 / AlmaLinux 8, RHEL 9 / AlmaLinux 9, SLES 15 / openSUSE Leap 15.6, Ubuntu 22.04 / Mint 21, Debian 12, Ubuntu 24.04, Fedora 41, Arch) + real container smoke tests on **Ubuntu 20.04 LTS** and **Debian 11** (clean ldd, diagnostic CLI, per-user install/uninstall). Also distributed via AUR (`paru -S textvn`) and Ubuntu/Debian PPA (`ppa:hunglinhpt/textvn`). |

Detailed release test report: [build-release-report.md](docs/release/build-release-report.md).

---

## Build from Source

```powershell
# Windows: Requires Rust stable + Visual Studio 2022 Build Tools (C++) + Inno Setup 6.5+
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-release.ps1 -BuildInstaller -MachineInstaller
```

```bash
# macOS 13+: Requires Xcode Command Line Tools 15+, rustup targets aarch64-apple-darwin & x86_64-apple-darwin
cd adapters/macos-imk
./build-rust.sh                   # Build FFI engine + Swift build + assemble TextVN-IM.app
./build-rust.sh --lib-only        # Build libtextvn_ffi.a only (for swift test)
./build-rust.sh --release         # Build optimized release binaries

# Package macOS releases (run from repo root)
scripts/build-macos.sh            # Package Universal zip
scripts/package-macos-pkg.sh      # Create per-user .pkg installer
```

```bash
# Linux (Ubuntu/Debian / Fedora / Arch)
scripts/install_linux.sh          # Build from source and install for current user
scripts/build-linux.sh            # Produce complete release tarball
```

Architecture, testing, code conventions and release process: see the **[Developer Guide](docs/developer-guide.md)** · Target cleanup & compact Cargo dev/test profiles ([Cargo.toml](Cargo.toml)): run `scripts/clean-target.ps1` (details in [CONTRIBUTING.md](CONTRIBUTING.md)).

---

## Project Structure

```
core/              Core phonetic & linguistic engine (Rust) — zero I/O, OS-independent
config/  ffi/      Config specification config.v1 · Safe C ABI and shims for adapters
adapters/          windows-tsf (pure TSF) · windows-hook (legacy app compatibility package)
                   macos-imk (Input Method Kit) · macos-app (SwiftUI menu bar) · macos-tap
                   linux-ibus · linux-fcitx5 · linux-common · linux-settings (GTK4/GTK3)
tray/  cli/        Windows tray & settings UI · textvn-cli (TSF registration, doctor, replay)
corpus/            230+ typing scenarios (*.keys) executed across adapter simulations in CI
installer/  packaging/  scripts/    Inno Setup, MSIX, PKGBUILD, Homebrew Cask, Debian PPA packaging scripts
docs/              Architecture specs (10-shared, 20-windows, 30-macos, 40-linux), specs, release
```

---

## Contributing & License

- Contributing guidelines: see [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md).
- Reporting typing bugs: please include the exact keystroke sequence, actual result, expected result, application name, and OS version.
- **License**: [GPL-3.0-or-later](LICENSE) © 2026 LinhBH.CoM
